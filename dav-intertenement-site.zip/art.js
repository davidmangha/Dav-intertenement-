/* ==========================================================================
   DAV_ART (1/3) : icônes, logo, favicon, illustrations « vide »
   Tout est dessiné en SVG, sans image : léger et recolorable.
   Les couleurs viennent des variables CSS --a1 à --a6 (voir styles).
   ========================================================================== */
(function () {
  'use strict';
  var A = window.DAV_ART = window.DAV_ART || {};
  A.keys = A.keys || {};
  var uid = 0;

  /* ---------- Icônes (grille 24×24, trait currentColor) ---------- */
  var I = {
    /* domaines */
    web: '<circle cx="11" cy="11" r="8"/><path d="M3 11h16M11 3c2.6 2.4 2.6 13.6 0 16M11 3c-2.6 2.4-2.6 13.6 0 16"/><path d="M15 15l6 2.2-2.6 1.2-1.2 2.6z"/>',
    mobile: '<rect x="7" y="2.5" width="10" height="19" rx="2.5"/><path d="M10.5 18.5h3"/>',
    software: '<rect x="3" y="4" width="18" height="16" rx="2.5"/><path d="M3 9h18M9.5 12.5l-2 2 2 2M14.5 12.5l2 2-2 2"/>',
    network: '<circle cx="12" cy="5" r="2.3"/><circle cx="5" cy="19" r="2.3"/><circle cx="19" cy="19" r="2.3"/><path d="M12 7.3v4.2M12 11.5H5V16.7M12 11.5h7v5.2"/>',
    security: '<path d="M12 3l7.5 3v5.5c0 4.5-3.2 8-7.5 9.5-4.3-1.5-7.5-5-7.5-9.5V6z"/><path d="M8.7 12l2.4 2.4 4.3-4.6"/>',
    cctv: '<path d="M3.5 12a8.5 8.5 0 0 1 17 0z"/><circle cx="12" cy="8.6" r="2.1"/><path d="M12 12v3M9 18.5h6M12 15v3.5"/>',
    hardware: '<rect x="6.5" y="6.5" width="11" height="11" rx="2"/><rect x="9.5" y="9.5" width="5" height="5" rx="1"/><path d="M9.5 3v3.5M14.5 3v3.5M9.5 17.5V21M14.5 17.5V21M3 9.5h3.5M3 14.5h3.5M17.5 9.5H21M17.5 14.5H21"/>',
    power: '<rect x="2.5" y="7.5" width="17" height="9" rx="2"/><path d="M21.5 11v2M11.5 9.5l-2.2 3h3.4l-2.2 3"/>',
    cloud: '<path d="M18 10h-1.26A8 8 0 1 0 9 20h9a5 5 0 0 0 0-10z"/><path d="M12 17.5v-5M9.8 14.6l2.2-2.2 2.2 2.2"/>',
    data: '<path d="M3.5 20.5h17"/><rect x="5" y="12" width="3.2" height="6.5" rx=".8"/><rect x="10.4" y="7" width="3.2" height="11.5" rx=".8"/><rect x="15.8" y="3.5" width="3.2" height="15" rx=".8"/>',
    design: '<path d="M12 3l5.5 9.5L12 21l-5.5-8.5z"/><circle cx="12" cy="12.5" r="1.6"/><path d="M12 14.1V21"/>',
    media: '<path d="M4 7.5h3l1.6-2.5h6.8L17 7.5h3a1.5 1.5 0 0 1 1.5 1.5v9a1.5 1.5 0 0 1-1.5 1.5H4A1.5 1.5 0 0 1 2.5 18V9A1.5 1.5 0 0 1 4 7.5z"/><circle cx="12" cy="13" r="3.6"/>',
    marketing: '<path d="M4 10v4h3l9 5V5L7 10z"/><path d="M19.5 9.5a4 4 0 0 1 0 5M7.5 14l1.5 5h2.5l-1-4.5"/>',
    fintech: '<rect x="4.5" y="3" width="9.5" height="18" rx="2.4"/><circle cx="17" cy="15" r="4.2"/><circle cx="17" cy="15" r="1.5"/>',
    messaging: '<path d="M4 5.5h16a1.5 1.5 0 0 1 1.5 1.5v9a1.5 1.5 0 0 1-1.5 1.5H11l-4.5 3.5V17.5H4A1.5 1.5 0 0 1 2.5 16V7A1.5 1.5 0 0 1 4 5.5z"/><path d="M7 9.5h10M7 13h6"/>',
    training: '<path d="M2 9l10-5 10 5-10 5z"/><path d="M6 11.5V16c0 1.5 3 3 6 3s6-1.5 6-3v-4.5M22 9v6"/>',
    consulting: '<rect x="5" y="4.5" width="14" height="17" rx="2"/><path d="M9 4.5V3.5h6v1M8.5 12.5l2 2 3.8-4M8.5 18h7"/>',
    support: '<path d="M4 14v-2a8 8 0 0 1 16 0v2"/><rect x="2.5" y="13.5" width="4.5" height="6" rx="1.8"/><rect x="17" y="13.5" width="4.5" height="6" rx="1.8"/><path d="M19.2 19.5c0 1.5-1.8 2-4.7 2"/>',
    iot: '<circle cx="12" cy="12" r="2.2"/><path d="M7.8 7.8a6 6 0 0 0 0 8.4M16.2 7.8a6 6 0 0 1 0 8.4M4.9 4.9a10 10 0 0 0 0 14.2M19.1 4.9a10 10 0 0 1 0 14.2"/>',
    gis: '<path d="M3 6.5l6-2.5 6 2.5 6-2.5v13l-6 2.5-6-2.5-6 2.5z"/><path d="M9 4v13M15 6.5v13"/>',
    docs: '<path d="M6 3h8l4.5 4.5V21H6z"/><path d="M14 3v4.5h4.5M9 12h6M9 15.5h6M9 18.5h3.5"/>',
    gaming: '<path d="M7 7.5h10a4.5 4.5 0 0 1 4.4 5.4l-.8 3.8a2.4 2.4 0 0 1-4.2.8L14.5 15h-5l-1.9 2.5a2.4 2.4 0 0 1-4.2-.8l-.8-3.8A4.5 4.5 0 0 1 7 7.5z"/><path d="M7.5 10.5v3M6 12h3"/><circle cx="15.5" cy="11" r=".8" fill="currentColor"/><circle cx="17.5" cy="13" r=".8" fill="currentColor"/>',
    emerging: '<path d="M12 3l7 4v8l-7 4-7-4V7z"/><path d="M12 11l7-4M12 11L5 7M12 11v8"/>',
    print: '<path d="M7 9V3.5h10V9"/><rect x="3" y="9" width="18" height="8" rx="2"/><path d="M7 14h10v6.5H7z"/><circle cx="17.5" cy="11.8" r=".7" fill="currentColor"/>',
    /* secteurs */
    school: '<path d="M3 10l9-5 9 5"/><path d="M5 10v9.5h14V10M9.5 19.5v-5h5v5M12 5V2.5"/>',
    health: '<rect x="3.5" y="3.5" width="17" height="17" rx="4"/><path d="M12 8v8M8 12h8"/>',
    retail: '<path d="M5 8h14l-1 12.5H6z"/><path d="M9 8V6.5a3 3 0 0 1 6 0V8"/>',
    hotel: '<path d="M3 18.5V6M3 14h18v4.5M21 14v-2.5a3 3 0 0 0-3-3h-7V14"/><circle cx="7" cy="10.5" r="1.8"/>',
    bank: '<path d="M3 9.5L12 4l9 5.5zM5.5 12v6M10 12v6M14 12v6M18.5 12v6M3.5 20.5h17"/>',
    ngo: '<path d="M12 20s-7.5-4.5-7.5-10A4.3 4.3 0 0 1 12 7.4 4.3 4.3 0 0 1 19.5 10c0 5.5-7.5 10-7.5 10z"/>',
    church: '<path d="M12 2.5v5M9.8 4.7h4.4"/><path d="M12 7.5l6 4.5v9H6v-9z"/><path d="M10.2 21v-4.5a1.8 1.8 0 0 1 3.6 0V21"/>',
    gov: '<path d="M6 21V3.5"/><path d="M6 4.5h11l-2.5 3.5 2.5 3.5H6"/><path d="M3.5 21h8"/>',
    transport: '<path d="M2.5 6.5h11v10.5h-11zM13.5 10h4l3 3.2V17h-7z"/><circle cx="7" cy="18" r="2"/><circle cx="17" cy="18" r="2"/>',
    mining: '<path d="M5 15.5a7 7 0 0 1 14 0"/><path d="M12 4v5M2.5 15.5h19v3h-19z"/>',
    agri: '<path d="M12 21v-9"/><path d="M12 12C12 7.5 8.5 5 4 5c0 4.5 3 7 8 7zM12 14c0-4 3-6.5 8-6.5 0 4-3 6.5-8 6.5z"/>',
    events: '<rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5.5 11.5a6.5 6.5 0 0 0 13 0M12 18v3M8.5 21h7"/>',
    sme: '<rect x="3" y="7.5" width="18" height="12.5" rx="2.2"/><path d="M8.5 7.5V5.5A1.5 1.5 0 0 1 10 4h4a1.5 1.5 0 0 1 1.5 1.5v2M3 13h18"/>',
    /* interface */
    search: '<circle cx="11" cy="11" r="6.5"/><path d="M16 16l4.5 4.5"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    minus: '<path d="M5 12h14"/>',
    check: '<path d="M4.5 12.5l5 5 10-11"/>',
    close: '<path d="M6 6l12 12M18 6L6 18"/>',
    menu: '<path d="M4 7h16M4 12h16M4 17h16"/>',
    cart: '<path d="M2.5 3.5h3l2.2 11h10.6l2-8H6.5"/><circle cx="9.5" cy="19.5" r="1.4"/><circle cx="17" cy="19.5" r="1.4"/>',
    user: '<circle cx="12" cy="8" r="4"/><path d="M4 20.5c.8-4 4-6 8-6s7.2 2 8 6"/>',
    sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2.5v2.2M12 19.3v2.2M2.5 12h2.2M19.3 12h2.2M5.3 5.3l1.6 1.6M17.1 17.1l1.6 1.6M18.7 5.3l-1.6 1.6M6.9 17.1l-1.6 1.6"/>',
    moon: '<path d="M20 14.5A8.5 8.5 0 0 1 9.5 4 8.5 8.5 0 1 0 20 14.5z"/>',
    lang: '<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c3 3 3 15 0 18M12 3c-3 3-3 15 0 18"/>',
    phone: '<path d="M6.5 3h3l1.5 4.5-2 1.3a11 11 0 0 0 5.2 5.2l1.3-2 4.5 1.5v3A2.5 2.5 0 0 1 17.5 19C10 19 5 14 5 6.5A2.5 2.5 0 0 1 6.5 3z"/>',
    whatsapp: '<path d="M12 3.5a8.5 8.5 0 0 0-7.3 12.9L3.5 20.5l4.2-1.1A8.5 8.5 0 1 0 12 3.5z"/><path d="M9.2 8.3c-.3.5-.4 1.3.3 2.6.8 1.4 2 2.5 3.4 3.1 1 .4 1.6.2 2-.4l.3-.8-1.8-.9-.7.6c-.9-.4-1.7-1.2-2.1-2.1l.6-.7-.8-1.8z"/>',
    mail: '<rect x="3" y="5" width="18" height="14" rx="2.5"/><path d="M3.5 7l8.5 6.5L20.5 7"/>',
    pin: '<path d="M12 21.5s7-6 7-11.5a7 7 0 0 0-14 0c0 5.5 7 11.5 7 11.5z"/><circle cx="12" cy="10" r="2.5"/>',
    clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5.5l3.5 2"/>',
    calendar: '<rect x="3.5" y="5" width="17" height="15.5" rx="2.5"/><path d="M3.5 10h17M8 3v4M16 3v4"/>',
    chevronDown: '<path d="M6 9.5l6 6 6-6"/>',
    chevronRight: '<path d="M9.5 6l6 6-6 6"/>',
    chevronLeft: '<path d="M14.5 6l-6 6 6 6"/>',
    trash: '<path d="M4 7h16M9.5 7V4.5h5V7M6.5 7l1 13h9l1-13M10 11v6M14 11v6"/>',
    copy: '<rect x="8.5" y="8.5" width="12" height="12" rx="2.5"/><path d="M15.5 8.5V6A2.5 2.5 0 0 0 13 3.5H6A2.5 2.5 0 0 0 3.5 6v7A2.5 2.5 0 0 0 6 15.5h2.5"/>',
    share: '<circle cx="6" cy="12" r="2.5"/><circle cx="18" cy="6" r="2.5"/><circle cx="18" cy="18" r="2.5"/><path d="M8.2 10.8l7.6-3.6M8.2 13.2l7.6 3.6"/>',
    upload: '<path d="M12 16V4M7.5 8.5L12 4l4.5 4.5M4 15v3.5A1.5 1.5 0 0 0 5.5 20h13a1.5 1.5 0 0 0 1.5-1.5V15"/>',
    download: '<path d="M12 4v12M7.5 11.5L12 16l4.5-4.5M4 15v3.5A1.5 1.5 0 0 0 5.5 20h13a1.5 1.5 0 0 0 1.5-1.5V15"/>',
    star: '<path d="M12 3.5l2.6 5.4 5.9.8-4.3 4.1 1 5.9L12 17l-5.2 2.7 1-5.9L3.5 9.7l5.9-.8z"/>',
    starFill: '<path fill="currentColor" d="M12 3.5l2.6 5.4 5.9.8-4.3 4.1 1 5.9L12 17l-5.2 2.7 1-5.9L3.5 9.7l5.9-.8z"/>',
    arrowUp: '<path d="M12 19.5v-15M6 10.5l6-6 6 6"/>',
    arrowRight: '<path d="M4.5 12h15M13.5 6l6 6-6 6"/>',
    send: '<path d="M21 3L10.5 13.5M21 3l-6.5 18-4-7.5L3 9.5z"/>',
    info: '<circle cx="12" cy="12" r="9"/><path d="M12 11v5.5M12 7.8h.01"/>',
    alert: '<path d="M12 3.5l9.5 16.5h-19z"/><path d="M12 10v4.5M12 17.2h.01"/>',
    lock: '<rect x="4.5" y="10.5" width="15" height="10" rx="2.5"/><path d="M8 10.5V7.5a4 4 0 0 1 8 0v3M12 14.5v2.5"/>',
    logout: '<path d="M9.5 4H6A2 2 0 0 0 4 6v12a2 2 0 0 0 2 2h3.5M15 8l4 4-4 4M19 12H9.5"/>',
    eye: '<path d="M2.5 12S6 5.5 12 5.5 21.5 12 21.5 12 18 18.5 12 18.5 2.5 12 2.5 12z"/><circle cx="12" cy="12" r="2.8"/>',
    eyeOff: '<path d="M4 4l16 16M9.8 6A9.6 9.6 0 0 1 12 5.5c6 0 9.5 6.5 9.5 6.5a16 16 0 0 1-3 3.8M6.3 7.8A15.8 15.8 0 0 0 2.5 12S6 18.5 12 18.5a9 9 0 0 0 4-1M10 10a2.8 2.8 0 0 0 3.9 3.9"/>',
    filter: '<path d="M3.5 5.5h17l-6.5 7.5v6l-4-2v-4z"/>',
    tag: '<path d="M3.5 12.5v-8a1 1 0 0 1 1-1h8l8 8-8.5 8.5z"/><circle cx="8" cy="8" r="1.4"/>',
    external: '<path d="M14 4h6v6M20 4l-9 9M18 14v5a1.5 1.5 0 0 1-1.5 1.5h-11A1.5 1.5 0 0 1 4 19V8a1.5 1.5 0 0 1 1.5-1.5H10"/>',
    grid: '<rect x="4" y="4" width="7" height="7" rx="1.5"/><rect x="13" y="4" width="7" height="7" rx="1.5"/><rect x="4" y="13" width="7" height="7" rx="1.5"/><rect x="13" y="13" width="7" height="7" rx="1.5"/>',
    list: '<path d="M9 6h11M9 12h11M9 18h11M4.5 6h.01M4.5 12h.01M4.5 18h.01"/>',
    truck: '<path d="M2.5 6.5h11v10.5h-11zM13.5 10h4l3 3.2V17h-7z"/><circle cx="7" cy="18" r="2"/><circle cx="17" cy="18" r="2"/>',
    wallet: '<path d="M4 7.5A2.5 2.5 0 0 1 6.5 5H18v3"/><rect x="3" y="8" width="18" height="12" rx="2.5"/><circle cx="16.5" cy="14" r="1.2" fill="currentColor"/>',
    receipt: '<path d="M6 3h12v18l-3-2-3 2-3-2-3 2z"/><path d="M9 8h6M9 12h6"/>',
    facebook: '<path d="M14 21v-8h2.7l.5-3.2H14V7.7c0-1 .4-1.7 1.8-1.7h1.5V3.2A18 18 0 0 0 15 3c-2.6 0-4.2 1.6-4.2 4.4v2.4H8V13h2.8v8z"/>',
    instagram: '<rect x="3.5" y="3.5" width="17" height="17" rx="5"/><circle cx="12" cy="12" r="4"/><circle cx="17" cy="7" r=".7" fill="currentColor"/>',
    linkedin: '<rect x="3.5" y="3.5" width="17" height="17" rx="3"/><path d="M8 10.5V16M8 7.8h.01M11.5 16v-5.5M11.5 13c0-1.5 1-2.6 2.5-2.6s2.5 1 2.5 2.6V16"/>',
    tiktok: '<path d="M14 3v11.5a3.5 3.5 0 1 1-3.5-3.5M14 3c.3 2.6 2 4.3 4.5 4.5"/>',
    youtube: '<rect x="2.5" y="5.5" width="19" height="13" rx="4"/><path d="M10 9.2v5.6l5-2.8z"/>',
    x: '<path d="M4.5 4l15 16M19.5 4l-15 16"/>',
    file: '<path d="M6 3h8l4.5 4.5V21H6z"/><path d="M14 3v4.5h4.5"/>',
    pause: '<path d="M8.5 5v14M15.5 5v14"/>',
    play: '<path d="M8 4.8l11 7.2-11 7.2z"/>',
    image: '<rect x="3.5" y="4.5" width="17" height="15" rx="2.5"/><circle cx="9" cy="10" r="1.6"/><path d="M4 18l5-5 4 4 2.5-2.5 4.5 4.5"/>'
  };

  A.icon = function (key, o) {
    o = o || {};
    var s = o.size || 24, sw = o.sw || 1.7, t = o.title;
    var body = I[key] || '<circle cx="12" cy="12" r="8"/>';
    return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="' + s + '" height="' + s + '" fill="none" stroke="currentColor" stroke-width="' + sw + '" stroke-linecap="round" stroke-linejoin="round"' +
      (o.cls ? ' class="' + o.cls + '"' : '') +
      (t ? ' role="img" aria-label="' + t + '"><title>' + t + '</title>' : ' aria-hidden="true" focusable="false">') + body + '</svg>';
  };
  A.keys.icons = Object.keys(I);

  /* ---------- Logo ---------- */
  var D_OUT = 'M14 11h10a13 13 0 0 1 0 26H14z', D_IN = 'M20.5 17H24a7 7 0 0 1 0 14h-3.5z';
  A.logo = function (o) {
    o = o || {};
    var s = o.size || 48, head = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 48" width="' + s + '" height="' + s + '" class="art art-logo" aria-hidden="true" focusable="false">';
    if (o.mono) {
      return head + '<path fill="currentColor" fill-rule="evenodd" d="M12 0h24a12 12 0 0 1 12 12v24a12 12 0 0 1-12 12H12A12 12 0 0 1 0 36V12A12 12 0 0 1 12 0zM12.5 11h10a13 13 0 0 1 0 26h-10zM19 17h3.5a7 7 0 0 1 0 14H19zM38 6.8a3.2 3.2 0 1 1 0 6.4 3.2 3.2 0 0 1 0-6.4z"/></svg>';
    }
    return head + '<rect width="48" height="48" rx="12" fill="var(--a1)"/><g transform="translate(-1.5 0)"><path fill="var(--a4)" fill-rule="evenodd" d="' + D_OUT + D_IN + '"/></g><circle cx="38" cy="10" r="3.2" fill="var(--a2)"/></svg>';
  };
  A.faviconSvg = function () {
    return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 48" width="64" height="64"><rect width="48" height="48" rx="12" fill="#1A6FE0"/><g transform="translate(-1.5 0)"><path fill="#FFFFFF" fill-rule="evenodd" d="' + D_OUT + D_IN + '"/></g><circle cx="38" cy="10" r="3.2" fill="#F2B705"/></svg>';
  };

  /* ---------- Illustrations « vide » (160×120) ---------- */
  function star(cx, cy, r, fill) {
    var p = [], i, a;
    for (i = 0; i < 10; i++) { a = -Math.PI / 2 + i * Math.PI / 5; p.push((cx + Math.cos(a) * (i % 2 ? r * 0.45 : r)).toFixed(1) + ',' + (cy + Math.sin(a) * (i % 2 ? r * 0.45 : r)).toFixed(1)); }
    return '<polygon points="' + p.join(' ') + '" fill="' + fill + '" stroke-linejoin="round"/>';
  }
  var wash = '<circle cx="80" cy="62" r="48" fill="var(--a6)"/><circle cx="80" cy="62" r="48" fill="var(--a1)" opacity=".08"/>';
  var shadow = function (inner) { return '<g transform="translate(3 4)" fill="var(--a3)" opacity=".14">' + inner + '</g>'; };
  var E = {
    search: function () {
      var card = '<rect x="40" y="24" width="64" height="74" rx="9"/>';
      return wash + shadow(card) + '<rect x="40" y="24" width="64" height="74" rx="9" fill="var(--a4)" stroke="var(--a5)" stroke-opacity=".5" stroke-width="1.5"/>' +
        '<g fill="var(--a5)" opacity=".55"><rect x="50" y="38" width="30" height="5" rx="2.5"/><rect x="50" y="50" width="44" height="5" rx="2.5"/><rect x="50" y="62" width="36" height="5" rx="2.5"/></g>' +
        '<circle cx="100" cy="80" r="17" fill="var(--a4)" fill-opacity=".75" stroke="var(--a1)" stroke-width="5"/><path d="M112 92l14 14" stroke="var(--a3)" stroke-width="7" stroke-linecap="round"/><circle cx="94" cy="74" r="3.5" fill="var(--a2)"/>';
    },
    cart: function () {
      var b = '<path d="M42 54h76l-9 42H51z"/>';
      return wash + shadow(b) + '<path d="M42 54h76l-9 42H51z" fill="var(--a4)" stroke="var(--a5)" stroke-opacity=".5" stroke-width="1.5" stroke-linejoin="round"/>' +
        '<path d="M58 54l9-22M102 54l-9-22" fill="none" stroke="var(--a3)" stroke-width="5" stroke-linecap="round"/>' +
        '<g stroke="var(--a5)" stroke-opacity=".6" stroke-width="3" stroke-linecap="round"><path d="M64 66v18M80 66v18M96 66v18"/></g>' + star(118, 34, 8, 'var(--a2)');
    },
    success: function () {
      return wash + shadow('<circle cx="80" cy="60" r="32"/>') + '<circle cx="80" cy="60" r="32" fill="var(--a1)"/><path d="M65 61l11 11 20-23" fill="none" stroke="var(--a4)" stroke-width="7" stroke-linecap="round" stroke-linejoin="round"/>' +
        '<g><circle cx="34" cy="34" r="4" fill="var(--a2)"/><rect x="126" y="30" width="8" height="8" rx="2" fill="var(--a1)" opacity=".6" transform="rotate(20 130 34)"/><circle cx="128" cy="86" r="3.5" fill="var(--a5)"/><rect x="26" y="82" width="7" height="7" rx="2" fill="var(--a5)" opacity=".7" transform="rotate(-18 30 86)"/><circle cx="112" cy="20" r="2.5" fill="var(--a5)"/><circle cx="48" cy="102" r="2.5" fill="var(--a1)" opacity=".6"/></g>';
    },
    calendar: function () {
      return wash + shadow('<rect x="36" y="26" width="88" height="74" rx="10"/>') + '<rect x="36" y="26" width="88" height="74" rx="10" fill="var(--a4)" stroke="var(--a5)" stroke-opacity=".5" stroke-width="1.5"/>' +
        '<path d="M36 46v-10a10 10 0 0 1 10-10h68a10 10 0 0 1 10 10v10z" fill="var(--a1)"/><path d="M56 20v12M104 20v12" stroke="var(--a3)" stroke-width="5" stroke-linecap="round"/>' +
        '<g fill="var(--a5)" opacity=".6"><circle cx="54" cy="62" r="3"/><circle cx="72" cy="62" r="3"/><circle cx="90" cy="62" r="3"/><circle cx="108" cy="62" r="3"/><circle cx="54" cy="78" r="3"/><circle cx="72" cy="78" r="3"/><circle cx="108" cy="78" r="3"/><circle cx="54" cy="92" r="3"/><circle cx="72" cy="92" r="3"/></g><circle cx="90" cy="78" r="9" fill="var(--a2)"/>';
    },
    account: function () {
      return wash + shadow('<rect x="30" y="34" width="96" height="58" rx="10"/>') + '<rect x="30" y="34" width="96" height="58" rx="10" fill="var(--a4)" stroke="var(--a5)" stroke-opacity=".5" stroke-width="1.5"/>' +
        '<circle cx="58" cy="56" r="10" fill="var(--a1)"/><path d="M42 82c2-9 8-12 16-12s14 3 16 12z" fill="var(--a1)" opacity=".75"/>' +
        '<g fill="var(--a5)" opacity=".55"><rect x="82" y="48" width="32" height="5" rx="2.5"/><rect x="82" y="60" width="24" height="5" rx="2.5"/><rect x="82" y="72" width="30" height="5" rx="2.5"/></g>' +
        '<g transform="translate(104 86)"><circle cx="8" cy="8" r="8" fill="var(--a2)"/><circle cx="8" cy="8" r="3" fill="var(--a4)"/><path d="M14 13l16 12M24 21l-3 4M29 25l-3 4" stroke="var(--a2)" stroke-width="4" stroke-linecap="round" fill="none"/></g>';
    },
    reviews: function () {
      var bub = '<path d="M44 30h72a12 12 0 0 1 12 12v32a12 12 0 0 1-12 12H84l-18 16V86H44a12 12 0 0 1-12-12V42a12 12 0 0 1 12-12z"/>';
      return wash + shadow(bub) + '<path d="M44 30h72a12 12 0 0 1 12 12v32a12 12 0 0 1-12 12H84l-18 16V86H44a12 12 0 0 1-12-12V42a12 12 0 0 1 12-12z" fill="var(--a4)" stroke="var(--a5)" stroke-opacity=".5" stroke-width="1.5" stroke-linejoin="round"/>' +
        star(60, 58, 11, 'var(--a1)') + star(80, 58, 11, 'var(--a1)') + star(100, 58, 11, 'var(--a2)');
    },
    offline: function () {
      var c = 'M104 84H58a18 18 0 0 1-3-35.7A26 26 0 0 1 105 44a20 20 0 0 1-1 40z';
      return wash + shadow('<path d="' + c + '"/>') + '<path d="' + c + '" fill="var(--a4)" stroke="var(--a5)" stroke-opacity=".6" stroke-width="2"/>' +
        '<path d="M46 98L116 30" stroke="var(--a3)" stroke-width="6" stroke-linecap="round"/><circle cx="116" cy="86" r="5" fill="var(--a2)"/>';
    }
  };
  A.empty = function (key) {
    var f = E[key] || E.search;
    return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 160 120" class="art art-empty" aria-hidden="true" focusable="false">' + f() + '</svg>';
  };
  A.keys.empty = Object.keys(E);
  A._uid = function () { return ++uid; };
})();
/* ==========================================================================
   DAV_ART (2/3) : boîte à outils de dessin partagée + enveloppes des scènes et produits
   ========================================================================== */
(function () {
  'use strict';
  var A = window.DAV_ART = window.DAV_ART || {};
  A.keys = A.keys || {};
  var N = 0;
  var RIM = ' stroke="var(--a5)" stroke-opacity=".4" stroke-width="1.5"';

  function f(v) { return Math.round(v * 10) / 10; }
  function at(fill) { return fill ? ' fill="' + fill + '"' : ''; }
  function R(x, y, w, h, r, fill, ex) { return '<rect x="' + x + '" y="' + y + '" width="' + w + '" height="' + h + '" rx="' + (r || 0) + '"' + at(fill) + (ex || '') + '/>'; }
  function C(x, y, r, fill, ex) { return '<circle cx="' + x + '" cy="' + y + '" r="' + r + '"' + at(fill) + (ex || '') + '/>'; }
  function P(d, fill, ex) { return '<path d="' + d + '"' + at(fill) + (ex || '') + '/>'; }
  function L(d, stroke, w, ex) { return '<path d="' + d + '" fill="none" stroke="' + stroke + '" stroke-width="' + (w || 2) + '" stroke-linecap="round" stroke-linejoin="round"' + (ex || '') + '/>'; }
  function G(t, inner) { return '<g transform="' + t + '">' + inner + '</g>'; }
  /* ombre portée douce (la forme reçue ne doit pas porter de fill) */
  function sh(inner) { return '<g transform="translate(4 5)" fill="var(--a3)" opacity=".14">' + inner + '</g>'; }
  /* corps d'appareil : ombre + fond marine + liseré clair */
  function B(x, y, w, h, r) { return sh(R(x, y, w, h, r)) + R(x, y, w, h, r, 'var(--a3)', RIM); }
  /* carte claire (fenêtre, papier) */
  function K(x, y, w, h, r) { return sh(R(x, y, w, h, r)) + R(x, y, w, h, r, 'var(--a4)', RIM); }
  function ln(x, y, w, fill, op) { return R(x, y, w, 5, 2.5, fill || 'var(--a5)', ' opacity="' + (op || '.55') + '"'); }
  function mon(x, y, w, h, ui) {
    return B(x, y, w, h, 8) + R(x + 5, y + 5, w - 10, h - 14, 4, 'var(--a4)') + (ui || '') +
      R(x + w / 2 - 4, y + h, 8, 9, 0, 'var(--a3)') + sh(R(x + w / 2 - 17, y + h + 8, 34, 5, 2.5)) + R(x + w / 2 - 17, y + h + 8, 34, 5, 2.5, 'var(--a3)', RIM);
  }
  function ph(x, y, w, h, ui) {
    return B(x, y, w, h, 9) + R(x + 3.5, y + 3.5, w - 7, h - 7, 6, 'var(--a4)') + (ui || '') + R(x + w / 2 - 5, y + 5.5, 10, 2.4, 1.2, 'var(--a3)');
  }
  function lap(x, y, w, ui) {
    var h = f(w * 0.6);
    return B(x, y, w, h, 6) + R(x + 4, y + 4, w - 8, h - 8, 3, 'var(--a4)') + (ui || '') +
      sh(R(x - 9, y + h, w + 18, 7, 3.5)) + R(x - 9, y + h, w + 18, 7, 3.5, 'var(--a3)', RIM);
  }
  /* baie de serveurs : n unités, led = index de l'unité dont la LED est l'accent (-1 = aucune) */
  function rack(x, y, w, n, led) {
    var s = B(x, y, w, n * 20 + 10, 6), i;
    for (i = 0; i < n; i++) {
      s += R(x + 6, y + 6 + i * 20, w - 12, 14, 3, 'var(--a4)', ' opacity=".16"') + C(x + 14, y + 13 + i * 20, 2.6, i === led ? 'var(--a2)' : 'var(--a1)') + R(x + 24, y + 11 + i * 20, w - 38, 4, 2, 'var(--a4)', ' opacity=".4"');
    }
    return s;
  }
  function cloud(x, y, s, fill) {
    return '<g transform="translate(' + x + ' ' + y + ') scale(' + s + ')"' + at(fill) + '><circle cx="-18" cy="4" r="14"/><circle cx="2" cy="-6" r="19"/><circle cx="22" cy="4" r="14"/><rect x="-32" y="4" width="68" height="14" rx="7"/></g>';
  }
  function gear(x, y, r, fill, hole) {
    var p = [], k, a, q, t, qs = [[-15, 0.78], [-10, 1], [10, 1], [15, 0.78]];
    for (k = 0; k < 8; k++) {
      a = k * 45;
      for (q = 0; q < 4; q++) { t = (a + qs[q][0]) * Math.PI / 180; p.push(f(x + Math.cos(t) * r * qs[q][1]) + ',' + f(y + Math.sin(t) * r * qs[q][1])); }
    }
    return '<polygon points="' + p.join(' ') + '"' + at(fill) + '/>' + (hole ? C(x, y, f(r * 0.34), hole) : '');
  }
  function bars(x, y, w, h, vals, fill) {
    var n = vals.length, g = w / n, bw = f(g * 0.62), s = '', i, bh;
    for (i = 0; i < n; i++) { bh = f(h * vals[i]); s += R(f(x + i * g + (g - bw) / 2), f(y + h - bh), bw, bh, 2.5, fill || 'var(--a1)'); }
    return s;
  }
  function shield(x, y, s, fill) {
    return '<path transform="translate(' + x + ' ' + y + ') scale(' + s + ')" d="M0-24L21-16V3C21 15 11 22 0 27C-11 22-21 15-21 3V-16Z"' + at(fill) + '/>';
  }
  function star(cx, cy, r, fill) {
    var p = [], i, a, rr;
    for (i = 0; i < 10; i++) { a = -Math.PI / 2 + i * Math.PI / 5; rr = i % 2 ? r * 0.45 : r; p.push(f(cx + Math.cos(a) * rr) + ',' + f(cy + Math.sin(a) * rr)); }
    return '<polygon points="' + p.join(' ') + '"' + at(fill) + ' stroke-linejoin="round"/>';
  }
  function hex(cx, cy, r, fill, ex) {
    var p = [], i, a;
    for (i = 0; i < 6; i++) { a = -Math.PI / 2 + i * Math.PI / 3; p.push(f(cx + Math.cos(a) * r) + ',' + f(cy + Math.sin(a) * r)); }
    return '<polygon points="' + p.join(' ') + '"' + at(fill) + ' stroke-linejoin="round"' + (ex || '') + '/>';
  }
  function qr(x, y, s, fill) {
    var rows = ['1110111', '1010101', '1110101', '0001011', '1101110', '0111001', '1010111'], o = '', r, c;
    for (r = 0; r < 7; r++) for (c = 0; c < 7; c++) if (rows[r].charAt(c) === '1') o += R(f(x + c * s), f(y + r * s), f(s - 0.8), f(s - 0.8), 1, fill);
    return o;
  }

  A._k = { R: R, C: C, P: P, L: L, G: G, sh: sh, B: B, K: K, ln: ln, mon: mon, ph: ph, lap: lap, rack: rack, cloud: cloud, gear: gear, bars: bars, shield: shield, star: star, hex: hex, qr: qr, f: f, RIM: RIM };

  /* ---------- enveloppes ---------- */
  A._scenes = A._scenes || {};
  A._products = A._products || {};
  var NS = 'xmlns="http://www.w3.org/2000/svg"';
  function cubeInner(cx, cy) {
    return sh(hex(cx, cy, 30)) + hex(cx, cy, 30, 'var(--a1)') + L('M' + cx + ' ' + cy + 'L' + f(cx + 26) + ' ' + f(cy - 15) + 'M' + cx + ' ' + cy + 'L' + f(cx - 26) + ' ' + f(cy - 15) + 'M' + cx + ' ' + cy + 'V' + f(cy + 30), 'var(--a4)', 2.5);
  }
  A.scene = function (id) {
    var u = 'dg' + (++N), fn = A._scenes[id], inner = fn ? fn() : cubeInner(160, 92);
    return '<svg ' + NS + ' viewBox="0 0 320 180" preserveAspectRatio="xMidYMid slice" class="art art-scene" aria-hidden="true" focusable="false">' +
      '<defs><pattern id="' + u + '" width="14" height="14" patternUnits="userSpaceOnUse"><circle cx="2" cy="2" r="1" fill="var(--a5)" opacity=".4"/></pattern></defs>' +
      '<rect width="320" height="180" rx="16" fill="var(--a6)"/><rect width="320" height="180" rx="16" fill="url(#' + u + ')"/>' +
      '<circle cx="160" cy="92" r="70" fill="var(--a1)" opacity=".13"/>' + inner + '</svg>';
  };
  A.product = function (key) {
    var fn = A._products[key], inner = fn ? fn() : cubeInner(100, 72);
    return '<svg ' + NS + ' viewBox="0 0 200 150" class="art art-product" aria-hidden="true" focusable="false">' +
      '<circle cx="100" cy="72" r="58" fill="var(--a6)"/><circle cx="100" cy="72" r="58" fill="var(--a1)" opacity=".1"/>' +
      '<ellipse cx="100" cy="130" rx="50" ry="6" fill="var(--a3)" opacity=".12"/>' + inner + '</svg>';
  };
  /* ---------- Images réalistes (rendus 3D des appareils) ----------
     Les fichiers img/s-<domaine>.webp (scènes) et img/p-<produit>.webp (produits) remplacent les dessins vectoriels.
     Si un fichier est absent, le dessin vectoriel s’affiche à sa place (voir l’écouteur d’erreur plus bas).
     Réglage dans config.js : images.bundled (true = images réalistes, false = dessins vectoriels). */
  var vecScene = A.scene, vecProduct = A.product;
  A.sceneVec = vecScene; A.productVec = vecProduct;
  function realOn() { var c = (window.DAV_CONFIG && window.DAV_CONFIG.images) || {}; return c.bundled !== false; }
  function has(list, k) { return !!list && list.indexOf(k) >= 0; }
  function real(kind, key, w, h) {
    return '<img class="art art-real art-' + kind + '" src="img/' + (kind === 'scene' ? 's-' : 'p-') + key + '.webp" width="' + w + '" height="' + h + '" alt="" loading="lazy" decoding="async" data-art="' + kind + '" data-key="' + key + '">';
  }
  A.scene = function (id) { return realOn() && has(A.keys.scenes, id) ? real('scene', id, 800, 600) : vecScene(id); };
  A.product = function (key) { return realOn() && has(A.keys.products, key) ? real('product', key, 640, 480) : vecProduct(key); };
  if (typeof document !== 'undefined') document.addEventListener('error', function (e) {
    var im = e.target;
    if (!im || im.tagName !== 'IMG' || !im.getAttribute('data-art') || !im.parentNode) return;
    var box = document.createElement('div'), kind = im.getAttribute('data-art'), key = im.getAttribute('data-key');
    box.innerHTML = kind === 'scene' ? vecScene(key) : vecProduct(key);
    if (box.firstChild) im.parentNode.replaceChild(box.firstChild, im);
  }, true);
  A.keys.scenes = ['web', 'mobile', 'software', 'network', 'security', 'cctv', 'hardware', 'power', 'cloud', 'data', 'design', 'media', 'marketing', 'fintech', 'messaging', 'training', 'consulting', 'support', 'iot', 'gis', 'docs', 'gaming', 'emerging', 'print'];
  A.keys.products = ['laptop', 'desktop', 'allinone', 'minipc', 'server', 'phone', 'tablet', 'powerbank', 'router', 'accesspoint', 'switch', 'cable', 'modem4g', 'repeater', 'camera', 'camkit', 'solarcam', 'fingerprint', 'doorlock', 'alarm', 'ups', 'battery', 'solarpanel', 'solarkit', 'stabilizer', 'surge', 'printer', 'mfp', 'scanner', 'cardprinter', 'toner', 'hdd', 'ssd', 'usb', 'sdcard', 'monitor', 'keyboardmouse', 'headset', 'webcam', 'projector', 'pos', 'barcode', 'thermal', 'cashdrawer', 'license', 'antivirus'];
})();
/* DAV_ART (3/3) : scènes illustrées, domaines 1 à 8 */
(function () {
  'use strict';
  var K = window.DAV_ART._k, S = window.DAV_ART._scenes;
  var R = K.R, C = K.C, P = K.P, L = K.L, G = K.G, ln = K.ln, i, r, c;

  S.web = function () {
    var s = K.K(60, 32, 200, 116, 10) + P('M60 42a10 10 0 0 1 10-10h180a10 10 0 0 1 10 10v12H60z', 'var(--a1)') +
      C(74, 43, 3, 'var(--a4)', ' opacity=".9"') + C(85, 43, 3, 'var(--a4)', ' opacity=".7"') + C(96, 43, 3, 'var(--a4)', ' opacity=".5"');
    s += C(115, 100, 34, 'var(--a1)', ' opacity=".14"') + '<circle cx="115" cy="100" r="34" fill="none" stroke="var(--a1)" stroke-width="2.4"/>' +
      L('M81 100h68M115 66c14 12 14 56 0 68M115 66c-14 12-14 56 0 68', 'var(--a1)', 2.2);
    s += ln(166, 72, 72) + ln(166, 86, 54) + ln(166, 100, 64, 'var(--a1)', '.6');
    s += R(198, 114, 50, 24, 7, 'var(--a2)') + L('M208 122h4l3 8h13l3-6h-17', 'var(--a3)', 2.2) + C(219, 133, 1.8, 'var(--a3)') + C(230, 133, 1.8, 'var(--a3)');
    return s + P('M134 114l26 10-11 3-5 11z', 'var(--a3)');
  };

  S.mobile = function () {
    var grid = '', chat;
    for (r = 0; r < 4; r++) for (c = 0; c < 3; c++) grid += R(94 + c * 20, 46 + r * 20, 15, 15, 4, (r * 3 + c) % 4 === 0 ? 'var(--a1)' : 'var(--a5)', ' opacity="' + ((r * 3 + c) % 4 === 0 ? 1 : 0.5) + '"');
    chat = R(174, 60, 36, 14, 7, 'var(--a1)') + R(192, 80, 36, 14, 7, 'var(--a5)', ' opacity=".6"') + R(174, 100, 42, 14, 7, 'var(--a1)') + R(194, 120, 28, 14, 7, 'var(--a5)', ' opacity=".6"');
    return K.ph(86, 28, 68, 126, grid) + G('rotate(5 200 100)', K.ph(166, 40, 68, 116, chat)) + C(150, 36, 7, 'var(--a2)');
  };

  S.software = function () {
    var s = K.K(52, 36, 216, 108, 10) + P('M52 46a10 10 0 0 1 10-10h196a10 10 0 0 1 10 10v10H52z', 'var(--a3)') + C(66, 46, 3, 'var(--a4)', ' opacity=".8"') + C(77, 46, 3, 'var(--a4)', ' opacity=".6"');
    s += R(58, 64, 34, 74, 6, 'var(--a6)') + R(102, 64, 84, 10, 3, 'var(--a1)', ' opacity=".8"');
    for (i = 0; i < 4; i++) s += R(102, 80 + i * 16, 84, 9, 3, 'var(--a5)', ' opacity="' + (i % 2 ? 0.25 : 0.4) + '"');
    s += K.bars(198, 68, 62, 62, [0.45, 0.75, 0.55, 0.95, 0.7]);
    return s + K.sh(K.gear(75, 120, 14)) + K.gear(75, 120, 14, 'var(--a3)', 'var(--a4)') + C(75, 120, 3, 'var(--a2)');
  };

  S.network = function () {
    var s = L('M127 62a49 49 0 0 1 66 0', 'var(--a1)', 4, ' opacity=".35"') + L('M136 74a35 35 0 0 1 48 0', 'var(--a1)', 4, ' opacity=".6"') + L('M146 86a20 20 0 0 1 28 0', 'var(--a1)', 4);
    s += L('M126 102L116 64', 'var(--a3)', 5) + L('M194 102L204 64', 'var(--a3)', 5);
    s += K.B(110, 100, 100, 28, 8) + C(130, 114, 3, 'var(--a1)') + C(142, 114, 3, 'var(--a1)') + C(154, 114, 3, 'var(--a1)') + C(196, 114, 3.2, 'var(--a2)') + R(168, 111, 16, 6, 3, 'var(--a4)', ' opacity=".4"');
    s += L('M160 128v14h-34', 'var(--a5)', 3) + L('M160 142h82', 'var(--a5)', 3) + K.B(40, 132, 86, 24, 5);
    for (i = 0; i < 5; i++) s += R(48 + i * 14, 140, 9, 8, 2, 'var(--a4)', ' opacity=".85"');
    return s + C(250, 142, 10, 'var(--a1)') + C(250, 142, 4.5, 'var(--a4)');
  };

  S.security = function () {
    var b = function (x, y, dx, dy) { return L('M' + x + ' ' + (y + dy * 14) + 'V' + y + 'H' + (x + dx * 14), 'var(--a5)', 3.5); };
    var s = b(98, 46, 1, 1) + b(222, 46, -1, 1) + b(98, 138, 1, -1) + b(222, 138, -1, -1);
    s += K.sh(K.shield(160, 92, 2.05)) + K.shield(160, 92, 2.05, 'var(--a1)') + K.shield(160, 92, 1.55, 'var(--a4)').replace('/>', ' opacity=".16"/>');
    s += L('M141 92l13 13 27-30', 'var(--a4)', 8);
    return s + K.sh(R(198, 116, 32, 26, 6)) + R(198, 116, 32, 26, 6, 'var(--a3)', K.RIM) + L('M204 116v-8a10 10 0 0 1 20 0v8', 'var(--a3)', 5) + C(214, 127, 3.4, 'var(--a2)') + R(212.5, 128, 3, 8, 1.5, 'var(--a2)');
  };

  S.cctv = function () {
    var s = P('M100 78L216 36V150Z', 'var(--a1)', ' opacity=".15"') + R(58, 28, 44, 8, 3, 'var(--a3)', K.RIM) + R(76, 36, 8, 22, 2, 'var(--a3)');
    s += K.sh(P('M56 82a24 24 0 0 1 48 0z')) + P('M56 82a24 24 0 0 1 48 0z', 'var(--a3)', K.RIM) + C(80, 73, 7.5, 'var(--a4)') + C(80, 73, 3.4, 'var(--a1)') + K.B(52, 82, 56, 8, 4);
    [[222, 46], [258, 46], [222, 84], [258, 84]].forEach(function (p, n) {
      s += K.B(p[0], p[1], 32, 26, 4) + R(p[0] + 3, p[1] + 3, 26, 18, 2, 'var(--a4)') +
        (n === 0 ? C(p[0] + 9, p[1] + 10, 2.8, 'var(--a2)') + R(p[0] + 15, p[1] + 8, 10, 4, 2, 'var(--a5)', ' opacity=".6"') : R(p[0] + 7, p[1] + 11, 18, 4, 2, 'var(--a1)', ' opacity="' + (0.4 + n * 0.15) + '"'));
    });
    return s;
  };

  S.hardware = function () {
    var ui = R(72, 62, 34, 34, 6, 'var(--a1)', ' opacity=".85"') + R(80, 70, 18, 18, 3, 'var(--a4)') + ln(116, 64, 46) + ln(116, 78, 34) + ln(116, 92, 40);
    var s = K.lap(58, 46, 120, ui) + K.sh(R(196, 56, 76, 18, 3)) + R(196, 56, 76, 18, 3, 'var(--a1)');
    for (i = 0; i < 4; i++) s += R(202 + i * 17, 60, 13, 10, 2, 'var(--a4)', ' opacity=".9"');
    s += L('M200 80H268', 'var(--a2)', 4, ' stroke-dasharray="3 2.5"');
    return s + G('rotate(-28 236 126)', R(196, 120, 48, 13, 6.5, 'var(--a3)', K.RIM) + R(244, 124, 38, 5, 2.5, 'var(--a5)') + R(278, 123, 6, 7, 1, 'var(--a5)'));
  };

  S.power = function () {
    var s = K.B(58, 66, 76, 70, 9) + R(68, 76, 56, 16, 3, 'var(--a4)') + R(74, 81, 24, 6, 3, 'var(--a1)', ' opacity=".8"');
    for (i = 0; i < 3; i++) s += R(68 + i * 19.5, 102, 15, 16, 4, 'var(--a4)', ' opacity=".2"');
    s += C(116, 127, 3, 'var(--a1)') + K.B(148, 92, 66, 42, 7) + R(164, 86, 10, 6, 2, 'var(--a3)') + R(190, 86, 10, 6, 2, 'var(--a3)') + R(156, 100, 50, 26, 4, 'var(--a1)') + P('M184 100l-13 14h9l-3 12 15-17h-9z', 'var(--a2)');
    s += K.sh(P('M226 50l46-9 8 42-46 9z')) + P('M226 50l46-9 8 42-46 9z', 'var(--a1)', K.RIM) +
      L('M237 48l8 42M248.5 46l8 42M260 43.5l8 42M230 71l46-9', 'var(--a4)', 1.6, ' opacity=".6"') + L('M257 88v28M241 118h32', 'var(--a3)', 4);
    return s;
  };
})();
/* DAV_ART : scènes illustrées, domaines 9 à 16 */
(function () {
  'use strict';
  var K = window.DAV_ART._k, S = window.DAV_ART._scenes;
  var R = K.R, C = K.C, P = K.P, L = K.L, G = K.G, ln = K.ln, i;

  S.cloud = function () {
    return K.sh(K.cloud(160, 66, 1.5)) + K.cloud(160, 66, 1.5, 'var(--a4)') + K.rack(104, 108, 40, 2, 0) + K.rack(176, 108, 40, 2, -1) +
      L('M152 108V97M147 102l5-5 5 5', 'var(--a1)', 3.5) + L('M168 97v11M163 103l5 5 5-5', 'var(--a1)', 3.5);
  };

  S.data = function () {
    var s = K.K(56, 44, 134, 92, 10) + ln(68, 52, 40, 'var(--a1)', '.8') + K.bars(68, 66, 76, 56, [0.4, 0.62, 0.5, 0.82, 0.66], 'var(--a1)') +
      L('M70 106L92 92L112 100L134 76L156 84', 'var(--a3)', 2.6);
    [[70, 106], [92, 92], [112, 100], [134, 76], [156, 84]].forEach(function (p) { s += C(p[0], p[1], 3.3, 'var(--a4)', ' stroke="var(--a3)" stroke-width="2"'); });
    s += '<circle cx="166" cy="102" r="12" fill="none" stroke="var(--a5)" stroke-opacity=".4" stroke-width="7"/>' + L('M166 90a12 12 0 0 1 12 12', 'var(--a1)', 7);
    s += L('M190 90H212', 'var(--a5)', 3) + C(190, 90, 3.5, 'var(--a1)') + K.B(212, 64, 52, 52, 9) + R(224, 76, 28, 28, 5, 'var(--a1)');
    for (i = 0; i < 3; i++) s += L('M' + (222 + i * 16) + ' 56v8M' + (222 + i * 16) + ' 116v8M204 ' + (74 + i * 16) + 'h8M264 ' + (74 + i * 16) + 'h8', 'var(--a5)', 3);
    return s + K.star(272, 52, 10, 'var(--a2)');
  };

  S.design = function () {
    var s = R(76, 20, 150, 10, 2, 'var(--a5)', ' opacity=".45"');
    for (i = 0; i < 15; i++) s += L('M' + (84 + i * 10) + ' 20v' + (i % 5 === 0 ? 7 : 4), 'var(--a3)', 1.2, ' opacity=".5"');
    s += K.K(76, 38, 150, 104, 6) + L('M96 118C110 58 150 58 168 100S206 112 210 76', 'var(--a1)', 4.5) + L('M96 118L110 74M168 100L188 128', 'var(--a5)', 1.6) + C(110, 74, 3.4, 'var(--a3)') + C(188, 128, 3.4, 'var(--a3)');
    [[96, 118], [168, 100], [210, 76]].forEach(function (p) { s += R(p[0] - 5, p[1] - 5, 10, 10, 2, 'var(--a4)', ' stroke="var(--a3)" stroke-width="2"'); });
    return s + K.sh(C(250, 124, 26)) + C(250, 124, 26, 'var(--a3)', K.RIM) + C(240, 113, 5, 'var(--a1)') + C(257, 110, 5, 'var(--a4)') + C(266, 126, 5, 'var(--a5)') + C(246, 135, 5, 'var(--a2)') + C(263, 141, 6.5, 'var(--a6)');
  };

  S.media = function () {
    var f = K.B(208, 42, 50, 98, 6);
    for (i = 0; i < 6; i++) f += R(212, 50 + i * 15, 7, 8, 2, 'var(--a6)') + R(247, 50 + i * 15, 7, 8, 2, 'var(--a6)');
    f += R(223, 50, 20, 26, 2, 'var(--a4)', ' opacity=".9"') + R(223, 82, 20, 26, 2, 'var(--a1)', ' opacity=".8"') + R(223, 114, 20, 18, 2, 'var(--a4)', ' opacity=".9"');
    return G('rotate(10 240 92)', f) + K.B(62, 70, 100, 64, 10) + R(86, 60, 30, 10, 3, 'var(--a3)', K.RIM) + R(72, 78, 14, 8, 2, 'var(--a4)', ' opacity=".8"') +
      C(118, 102, 21, 'var(--a4)') + C(118, 102, 14, 'var(--a1)') + C(118, 102, 6, 'var(--a4)', ' opacity=".6"') + C(204, 52, 17, 'var(--a2)') + P('M199 44l14 8-14 8z', 'var(--a3)');
  };

  S.marketing = function () {
    var cone = 'M60 76h22l54-26v82l-54-26H60z';
    return K.sh(P(cone)) + P(cone, 'var(--a3)', K.RIM) + R(134, 48, 10, 86, 5, 'var(--a1)') + R(70, 106, 16, 28, 5, 'var(--a3)', K.RIM) +
      L('M154 74q10 17 0 34', 'var(--a5)', 3.5) + L('M164 66q16 25 0 50', 'var(--a5)', 3.5, ' opacity=".6"') +
      K.bars(186, 84, 86, 50, [0.3, 0.46, 0.62, 0.8, 1], 'var(--a1)') + L('M190 78L222 62L242 70L272 44M262 45l10-1-1 10', 'var(--a3)', 3.2) +
      '<path transform="translate(204 36) scale(1.15)" d="M0 12C-8 6-11 1-11-4A6 6 0 0 1 0-6 6 6 0 0 1 11-4C11 1 8 6 0 12Z" fill="var(--a2)"/>';
  };

  S.fintech = function () {
    var ui = K.qr(101, 58, 6, 'var(--a3)') + R(98, 110, 50, 12, 6, 'var(--a1)') + ln(104, 132, 38);
    return K.ph(86, 24, 72, 132, ui) + K.sh(C(206, 64, 24)) + C(206, 64, 24, 'var(--a2)') + '<circle cx="206" cy="64" r="16.5" fill="none" stroke="var(--a3)" stroke-width="2.2" opacity=".5"/>' + L('M206 53v22', 'var(--a3)', 3.2) +
      K.sh(R(172, 100, 96, 52, 9)) + R(172, 100, 96, 52, 9, 'var(--a1)') + R(172, 114, 96, 10, 0, 'var(--a3)', ' opacity=".45"') + R(184, 132, 20, 14, 3, 'var(--a4)', ' opacity=".85"') + ln(212, 136, 44, 'var(--a4)', '.5');
  };

  S.messaging = function () {
    var b1 = 'M72 40h92a12 12 0 0 1 12 12v28a12 12 0 0 1-12 12H100l-18 14V92H72a12 12 0 0 1-12-12V52a12 12 0 0 1 12-12z';
    var b2 = 'M142 100h96a12 12 0 0 1 12 12v22a12 12 0 0 1-12 12h-10v14l-18-14h-68a12 12 0 0 1-12-12v-22a12 12 0 0 1 12-12z';
    return K.sh(P(b1)) + P(b1, 'var(--a1)') + ln(74, 56, 64, 'var(--a4)', '.9') + ln(74, 68, 44, 'var(--a4)', '.6') +
      K.sh(P(b2)) + P(b2, 'var(--a4)', K.RIM) + ln(144, 114, 70) + ln(144, 126, 48, 'var(--a1)', '.7') +
      K.K(206, 30, 56, 38, 6) + L('M210 36l24 18 24-18', 'var(--a3)', 2.6) + C(262, 32, 7.5, 'var(--a2)') +
      L('M62 148a22 22 0 0 1 44 0', 'var(--a3)', 5) + R(56, 140, 12, 20, 5, 'var(--a3)', K.RIM) + R(100, 140, 12, 20, 5, 'var(--a3)', K.RIM);
  };

  S.training = function () {
    var ui = C(110, 100, 16, 'var(--a1)') + P('M105 92l15 8-15 8z', 'var(--a4)') + ln(136, 88, 38) + ln(136, 102, 28) + ln(136, 116, 34);
    return K.lap(66, 66, 120, ui) + K.sh(P('M126 24l40 16-40 16-40-16z')) + P('M126 24l40 16-40 16-40-16z', 'var(--a3)', K.RIM) + P('M106 49v13c10 8 30 8 40 0V49', 'var(--a3)') +
      L('M166 40v22', 'var(--a2)', 3) + C(166, 66, 3.2, 'var(--a2)') +
      K.K(210, 78, 68, 50, 5) + ln(220, 88, 40, 'var(--a3)', '.7') + ln(220, 100, 48) + C(262, 118, 8, 'var(--a1)') + P('M257 124l-3 12 8-4 8 4-3-12', 'var(--a1)');
  };
})();
/* DAV_ART : scènes illustrées, domaines 17 à 24 */
(function () {
  'use strict';
  var K = window.DAV_ART._k, S = window.DAV_ART._scenes;
  var R = K.R, C = K.C, P = K.P, L = K.L, G = K.G, ln = K.ln, i, y;

  S.consulting = function () {
    var s = K.B(78, 30, 96, 118, 8) + R(88, 46, 76, 96, 4, 'var(--a4)') + R(106, 22, 40, 14, 5, 'var(--a5)', K.RIM);
    for (i = 0; i < 3; i++) { y = 58 + i * 28; s += C(100, y + 3, 6.5, 'var(--a1)') + L('M97 ' + (y + 3) + 'l2.4 2.4 4.4-5', 'var(--a4)', 2) + ln(112, y, 40) + ln(112, y + 10, 26, 'var(--a5)', '.35'); }
    return s + C(216, 100, 24, 'var(--a4)', ' fill-opacity=".6" stroke="var(--a1)" stroke-width="6"') + L('M234 118l22 22', 'var(--a3)', 9) +
      L('M190 50c16 0 20 14 36 14s18-14 40-14', 'var(--a5)', 3, ' stroke-dasharray="1 8"') + C(190, 50, 4, 'var(--a1)') + C(268, 50, 6.5, 'var(--a2)');
  };

  S.support = function () {
    return L('M104 100a40 40 0 0 1 80 0', 'var(--a3)', 9) + K.B(92, 96, 22, 36, 10) + K.B(174, 96, 22, 36, 10) + L('M185 128c0 14-10 20-26 20', 'var(--a3)', 5) + C(156, 148, 6.5, 'var(--a2)') +
      K.K(210, 46, 68, 48, 6) + C(224, 62, 5.5, 'var(--a1)') + L('M221 62l2 2 4-4.5', 'var(--a4)', 1.8) + ln(236, 59, 32) + ln(220, 76, 48) + ln(220, 86, 34, 'var(--a5)', '.35') +
      G('rotate(-35 66 134)', R(36, 128, 66, 12, 6, 'var(--a5)') + C(36, 134, 12, 'var(--a5)') + C(31, 134, 5, 'var(--a6)'));
  };

  S.iot = function () {
    var s = L('M122 56a24 24 0 0 1 36 0', 'var(--a1)', 4) + L('M112 44a40 40 0 0 1 56 0', 'var(--a1)', 4, ' opacity=".5"');
    s += K.B(90, 70, 100, 70, 8) + R(116, 86, 36, 36, 6, 'var(--a1)') + R(124, 94, 20, 20, 3, 'var(--a4)', ' opacity=".9"') +
      L('M90 88h18M90 104h18M90 120h18M158 100h32M158 112h24', 'var(--a5)', 2.5, ' opacity=".7"');
    s += L('M63 62L90 84', 'var(--a5)', 2.5, ' stroke-dasharray="2 5"') + C(52, 60, 11, 'var(--a4)', K.RIM) + C(52, 60, 5, 'var(--a1)') +
      L('M59 124L90 118', 'var(--a5)', 2.5, ' stroke-dasharray="2 5"') + C(50, 126, 9, 'var(--a4)', K.RIM) + C(50, 126, 4, 'var(--a1)');
    return s + P('M222 128c0-22 16-34 42-34 0 24-16 34-42 34z', 'var(--a1)') + L('M224 126l32-26', 'var(--a4)', 2.5) + G('translate(252 48) scale(.8)', P('M0 0C-9 11-14 17-14 24a14 14 0 0 0 28 0C14 17 9 11 0 0z', 'var(--a2)'));
  };

  S.gis = function () {
    return K.sh(P('M60 56L127 44L193 56L260 44V128L193 140L127 128L60 140Z')) +
      P('M60 56L127 44V128L60 140Z', 'var(--a4)') + P('M127 44L193 56V140L127 128Z', 'var(--a4)', ' opacity=".82"') + P('M193 56L260 44V128L193 140Z', 'var(--a4)') +
      C(96, 94, 18, 'var(--a1)', ' opacity=".13"') + C(160, 110, 22, 'var(--a1)', ' opacity=".13"') + C(226, 100, 18, 'var(--a1)', ' opacity=".13"') +
      L('M127 44V128M193 56V140', 'var(--a5)', 1.5, ' opacity=".6"') + L('M80 122C108 102 118 74 148 94S194 116 230 84', 'var(--a1)', 3.6, ' stroke-dasharray="0.5 8"') +
      '<g transform="translate(232 84)"><path d="M0 0C-12-14-14-22-14-28a14 14 0 0 1 28 0c0 6-2 14-14 28z" fill="var(--a2)"/><circle cx="0" cy="-28" r="5" fill="var(--a3)"/></g>';
  };

  S.docs = function () {
    var s = G('rotate(-7 150 90)', K.K(98, 34, 92, 112, 6)) + G('rotate(3 150 90)', K.K(102, 30, 92, 112, 6)) + K.K(106, 30, 92, 112, 6);
    s += ln(118, 46, 50, 'var(--a3)', '.7') + ln(118, 60, 68) + ln(118, 72, 60) + ln(118, 84, 66) + ln(118, 112, 40);
    s += R(80, 94, 160, 7, 3.5, 'var(--a1)', ' opacity=".6"') + P('M80 101h160l-8 30H88z', 'var(--a1)', ' opacity=".12"');
    return s + K.sh(C(236, 122, 22)) + C(236, 122, 22, 'var(--a2)') + '<circle cx="236" cy="122" r="16" fill="none" stroke="var(--a3)" stroke-width="2" opacity=".4"/>' + L('M227 122l6 6 11-12', 'var(--a3)', 3.4);
  };

  S.gaming = function () {
    var pad = 'M96 78h64a26 26 0 0 1 25 33l-5 22a14 14 0 0 1-24 5l-12-14H112l-12 14a14 14 0 0 1-24-5l-5-22A26 26 0 0 1 96 78z';
    return K.sh(P(pad)) + P(pad, 'var(--a3)', K.RIM) + R(98, 92, 22, 7, 3, 'var(--a4)') + R(105.5, 84.5, 7, 22, 3, 'var(--a4)') +
      C(150, 92, 5.5, 'var(--a1)') + C(164, 100, 5.5, 'var(--a2)') + C(150, 108, 5.5, 'var(--a5)') + C(136, 100, 5.5, 'var(--a4)', ' opacity=".8"') +
      K.B(204, 58, 72, 44, 12) + C(226, 80, 10, 'var(--a4)', ' opacity=".9"') + C(254, 80, 10, 'var(--a4)', ' opacity=".9"') + C(226, 80, 4.5, 'var(--a1)') + C(254, 80, 4.5, 'var(--a1)') +
      L('M204 80h-12M276 80h12', 'var(--a5)', 5) +
      R(60, 52, 8, 8, 0, 'var(--a1)', ' opacity=".6"') + R(274, 40, 6, 6, 0, 'var(--a5)') + R(256, 130, 8, 8, 0, 'var(--a1)', ' opacity=".5"') + R(210, 126, 6, 6, 0, 'var(--a5)', ' opacity=".7"') + R(116, 46, 6, 6, 0, 'var(--a5)', ' opacity=".7"');
  };

  S.emerging = function () {
    var s = '<ellipse cx="160" cy="92" rx="100" ry="34" fill="none" stroke="var(--a5)" stroke-width="2" stroke-dasharray="3 6" transform="rotate(-18 160 92)"/>';
    s += K.sh(K.hex(138, 78, 26)) + K.sh(K.hex(183, 78, 26)) + K.sh(K.hex(160, 117, 26));
    s += K.hex(138, 78, 26, 'var(--a1)') + K.hex(138, 78, 11, 'none', ' stroke="var(--a4)" stroke-width="2.5"') +
      K.hex(183, 78, 26, 'var(--a3)', K.RIM) + K.hex(183, 78, 11, 'none', ' stroke="var(--a4)" stroke-width="2.5"') +
      K.hex(160, 117, 26, 'var(--a4)', K.RIM) + K.hex(160, 117, 11, 'none', ' stroke="var(--a1)" stroke-width="2.5"');
    return s + C(248, 53, 6, 'var(--a1)') + C(72, 131, 5, 'var(--a5)') + K.star(278, 34, 10, 'var(--a2)');
  };

  S.print = function () {
    var s = R(92, 46, 64, 42, 3, 'var(--a4)', K.RIM) + ln(100, 56, 40) + ln(100, 68, 28) + K.B(66, 76, 114, 52, 10) + R(84, 98, 78, 5, 2.5, 'var(--a6)', ' opacity=".25"') + ln(80, 86, 30, 'var(--a4)', '.3') + C(168, 88, 3.2, 'var(--a2)');
    s += K.K(88, 112, 72, 34, 3) + ln(96, 122, 40) + ln(96, 134, 28, 'var(--a1)', '.6');
    return s + L('M216 58L204 30M246 58L258 30', 'var(--a1)', 5) + R(222, 50, 18, 9, 3, 'var(--a5)', K.RIM) + K.K(196, 58, 70, 88, 8) +
      C(231, 92, 12, 'var(--a1)') + P('M213 126c2-10 8-14 18-14s16 4 18 14z', 'var(--a1)', ' opacity=".75"') + ln(210, 132, 42, 'var(--a3)', '.7');
  };
})();
/* DAV_ART : visuels produits, 1re partie (ordinateurs, téléphones, réseau, caméras) */
(function () {
  'use strict';
  var K = window.DAV_ART._k, D = window.DAV_ART._products;
  var R = K.R, C = K.C, P = K.P, L = K.L, G = K.G, ln = K.ln, B = K.B, i, r, c;
  var RIM = K.RIM;
  function bul(x, y) { return B(x, y, 44, 18, 8) + R(x + 36, y + 3, 10, 12, 4, 'var(--a4)') + C(x + 41, y + 9, 3, 'var(--a1)') + R(x + 14, y + 18, 8, 10, 2, 'var(--a5)'); }
  function led(x, y, on) { return C(x, y, 2.8, on ? 'var(--a2)' : 'var(--a1)'); }

  D.laptop = function () {
    return K.lap(46, 36, 108, R(54, 46, 14, 14, 4, 'var(--a2)') + ln(74, 48, 44, 'var(--a1)', '.8') + ln(54, 68, 64) + ln(54, 80, 52) + ln(54, 92, 30, 'var(--a5)', '.35'));
  };
  D.desktop = function () {
    return B(30, 40, 38, 84, 7) + R(38, 50, 22, 4, 2, 'var(--a4)', ' opacity=".35"') + R(38, 58, 22, 4, 2, 'var(--a4)', ' opacity=".2"') + C(49, 110, 4, 'var(--a2)') +
      K.mon(76, 30, 94, 62, ln(86, 42, 40, 'var(--a1)', '.8') + ln(86, 54, 62) + ln(86, 66, 48) + R(138, 42, 20, 16, 4, 'var(--a1)', ' opacity=".25"'));
  };
  D.allinone = function () {
    return B(38, 26, 124, 80, 9) + R(44, 32, 112, 58, 4, 'var(--a4)') + ln(54, 42, 44, 'var(--a1)', '.8') + ln(54, 54, 70) + ln(54, 66, 56) + R(120, 44, 28, 36, 5, 'var(--a1)', ' opacity=".22"') + C(100, 98, 2.6, 'var(--a2)') +
      P('M88 106h24l6 18H82z', 'var(--a3)') + R(68, 122, 64, 6, 3, 'var(--a3)', RIM);
  };
  D.minipc = function () {
    return P('M56 74l7-12h74l7 12z', 'var(--a5)', ' opacity=".55"') + B(46, 74, 108, 44, 10) + R(58, 86, 16, 6, 2, 'var(--a4)', ' opacity=".35"') + R(78, 86, 10, 6, 2, 'var(--a4)', ' opacity=".35"') +
      L('M96 84h30M96 92h30M96 100h30', 'var(--a5)', 2, ' opacity=".6"') + C(140, 96, 7, 'var(--a1)') + C(140, 96, 2.8, 'var(--a4)') + C(66, 108, 2.8, 'var(--a2)');
  };
  D.server = function () {
    var s = B(28, 42, 144, 38, 6) + R(20, 46, 8, 30, 2, 'var(--a5)') + R(172, 46, 8, 30, 2, 'var(--a5)');
    for (i = 0; i < 6; i++) s += R(38 + i * 18, 50, 14, 22, 3, 'var(--a4)', ' opacity=".2"') + R(41 + i * 18, 54, 8, 3, 1.5, 'var(--a1)');
    s += C(160, 61, 3, 'var(--a2)') + B(28, 88, 144, 38, 6) + R(20, 92, 8, 30, 2, 'var(--a5)') + R(172, 92, 8, 30, 2, 'var(--a5)');
    for (i = 0; i < 3; i++) s += R(38 + i * 44, 96, 38, 22, 3, 'var(--a4)', ' opacity=".2"') + R(44 + i * 44, 104, 18, 3, 1.5, 'var(--a1)');
    return s;
  };
  D.phone = function () {
    var g = '';
    for (r = 0; r < 3; r++) for (c = 0; c < 3; c++) g += R(80 + c * 15, 44 + r * 15, 11, 11, 3, r === 0 && c === 2 ? 'var(--a2)' : (r + c) % 2 ? 'var(--a5)' : 'var(--a1)', ' opacity="' + (r === 0 && c === 2 ? 1 : 0.7) + '"');
    return K.ph(72, 20, 56, 106, g + ln(80, 98, 40, 'var(--a5)', '.35') + R(80, 108, 40, 8, 4, 'var(--a1)', ' opacity=".5"'));
  };
  D.tablet = function () {
    return B(32, 34, 136, 88, 11) + R(38, 40, 124, 76, 6, 'var(--a4)') + R(48, 50, 42, 24, 4, 'var(--a1)', ' opacity=".85"') + ln(98, 52, 54, 'var(--a5)', '.5') + ln(98, 64, 40, 'var(--a5)', '.35') + R(48, 82, 104, 24, 4, 'var(--a5)', ' opacity=".25"') + C(138, 94, 5.5, 'var(--a2)');
  };
  D.powerbank = function () {
    var s = B(66, 24, 68, 100, 13);
    for (i = 0; i < 4; i++) s += R(76 + i * 13, 36, 9, 5, 2, 'var(--a1)', ' opacity="' + (1 - i * 0.18) + '"');
    return s + P('M104 62l-13 19h9l-3 15 16-21h-10z', 'var(--a2)') + R(88, 110, 24, 6, 3, 'var(--a4)', ' opacity=".3"');
  };
  D.router = function () {
    return L('M54 84L46 40M146 84L154 40', 'var(--a3)', 6) + L('M86 62a20 20 0 0 1 28 0', 'var(--a1)', 3.5) + L('M78 52a32 32 0 0 1 44 0', 'var(--a1)', 3.5, ' opacity=".5"') +
      B(30, 82, 140, 36, 9) + C(50, 100, 3, 'var(--a1)') + C(62, 100, 3, 'var(--a1)') + C(74, 100, 3, 'var(--a1)') + R(92, 97, 40, 6, 3, 'var(--a4)', ' opacity=".3"') + C(152, 100, 3.4, 'var(--a2)');
  };
  D.accesspoint = function () {
    return L('M100 60V28', 'var(--a5)', 4) + K.sh(P('M42 78v8a58 22 0 0 0 116 0v-8z')) + P('M42 78v8a58 22 0 0 0 116 0v-8z', 'var(--a3)', RIM) +
      '<ellipse cx="100" cy="78" rx="58" ry="22" fill="var(--a4)"' + RIM + '/><ellipse cx="100" cy="78" rx="30" ry="10" fill="var(--a1)" opacity=".22"/><ellipse cx="100" cy="78" rx="16" ry="5.5" fill="var(--a1)"/>' + C(100, 77.5, 2.6, 'var(--a2)');
  };
  D.switch = function () {
    var s = B(24, 62, 152, 40, 6) + R(16, 68, 8, 28, 2, 'var(--a5)') + R(176, 68, 8, 28, 2, 'var(--a5)');
    for (i = 0; i < 8; i++) s += led(40 + i * 14, 71, i === 0) + R(35 + i * 14, 78, 10, 12, 2, 'var(--a4)', ' opacity=".85"');
    return s + R(150, 76, 18, 14, 3, 'var(--a1)', ' opacity=".75"') + R(150, 94, 18, 3, 1.5, 'var(--a4)', ' opacity=".35"');
  };
  D.cable = function () {
    return '<ellipse cx="100" cy="82" rx="52" ry="34" fill="none" stroke="var(--a1)" stroke-width="7"/><ellipse cx="100" cy="82" rx="40" ry="25" fill="none" stroke="var(--a1)" stroke-width="7" opacity=".8"/><ellipse cx="100" cy="82" rx="28" ry="16" fill="none" stroke="var(--a1)" stroke-width="7" opacity=".6"/>' +
      L('M52 90L34 110', 'var(--a1)', 7) + K.K(22, 106, 24, 16, 3) + R(26, 100, 16, 6, 1.5, 'var(--a2)') + L('M148 92l16 16', 'var(--a1)', 7) + K.K(156, 104, 24, 16, 3);
  };
  D.modem4g = function () {
    var s = L('M138 50l16-18', 'var(--a3)', 5) + B(60, 36, 80, 84, 13) + R(70, 46, 60, 26, 5, 'var(--a4)');
    for (i = 0; i < 4; i++) s += R(78 + i * 8, 64 - i * 4, 5, 4 + i * 4, 1.5, 'var(--a1)');
    return s + R(106, 52, 18, 8, 2, 'var(--a5)', ' opacity=".5"') + C(100, 94, 7, 'var(--a1)') + C(100, 94, 2.8, 'var(--a4)') + C(78, 106, 3, 'var(--a2)') + R(92, 108, 36, 5, 2.5, 'var(--a4)', ' opacity=".25"');
  };
  D.repeater = function () {
    return R(84, 106, 8, 14, 2, 'var(--a5)') + R(108, 106, 8, 14, 2, 'var(--a5)') + B(58, 32, 84, 76, 12) + L('M82 62a18 18 0 0 1 36 0', 'var(--a1)', 3.5) + L('M89 70a9 9 0 0 1 22 0', 'var(--a1)', 3.5) + C(100, 77, 2.6, 'var(--a1)') + C(100, 94, 3, 'var(--a2)');
  };
  D.camera = function () {
    return R(44, 44, 76, 8, 4, 'var(--a3)', RIM) + B(48, 52, 90, 34, 10) + R(130, 56, 14, 26, 5, 'var(--a4)') + C(137, 69, 6, 'var(--a1)') + C(137, 69, 2.4, 'var(--a4)') + C(60, 69, 3, 'var(--a2)') +
      R(88, 86, 10, 16, 2, 'var(--a5)') + B(66, 100, 54, 9, 4);
  };
  D.camkit = function () {
    return L('M60 60L72 92M136 68L124 92', 'var(--a5)', 2.5, ' stroke-dasharray="2 5"') + bul(34, 30) + bul(120, 38) + B(40, 92, 120, 32, 6) + R(50, 100, 50, 6, 3, 'var(--a4)', ' opacity=".3"') + R(50, 110, 30, 4, 2, 'var(--a4)', ' opacity=".2"') + C(142, 108, 3.2, 'var(--a2)') + C(130, 108, 3, 'var(--a1)');
  };
  D.solarcam = function () {
    return K.sh(P('M82 22l60-8 8 34-60 8z')) + P('M82 22l60-8 8 34-60 8z', 'var(--a1)', RIM) + L('M96 20l7 36M110 18l7 36M124 16l7 36M86 38l60-8', 'var(--a4)', 1.4, ' opacity=".55"') +
      L('M118 54l-8 16', 'var(--a3)', 4) + B(52, 70, 90, 32, 10) + R(134, 74, 14, 24, 5, 'var(--a4)') + C(141, 86, 5.5, 'var(--a1)') + C(66, 86, 3, 'var(--a2)') + R(90, 102, 10, 12, 2, 'var(--a5)');
  };
  D.fingerprint = function () {
    return B(60, 20, 80, 106, 11) + R(68, 28, 64, 28, 4, 'var(--a4)') + ln(76, 36, 34, 'var(--a1)', '.8') + ln(76, 46, 22, 'var(--a5)', '.45') + C(100, 66, 3, 'var(--a2)') + C(100, 96, 24, 'var(--a1)') +
      L('M88 100a12 12 0 0 1 24 0M92 106a8 8 0 0 1 16 0M96 90a6 6 0 0 1 8 0M88 92a14 14 0 0 1 24 0', 'var(--a4)', 2.2);
  };
  D.doorlock = function () {
    var s = B(64, 18, 72, 108, 11) + C(100, 32, 3, 'var(--a2)');
    for (r = 0; r < 3; r++) for (c = 0; c < 3; c++) s += C(84 + c * 16, 52 + r * 14, 4, 'var(--a4)', ' opacity=".8"');
    return s + C(100, 100, 9, 'var(--a1)') + C(100, 100, 4, 'var(--a4)', ' opacity=".7"') + R(126, 88, 40, 11, 5.5, 'var(--a5)', RIM);
  };
  D.alarm = function () {
    return K.sh(P('M50 82V52a22 16 0 0 1 44 0v30z')) + P('M50 82V52a22 16 0 0 1 44 0v30z', 'var(--a1)') + B(42, 80, 60, 12, 5) + C(72, 38, 8, 'var(--a2)') + L('M60 26l-4-6M72 22v-7M84 26l4-6', 'var(--a2)', 3) +
      B(114, 50, 46, 72, 9) + R(120, 57, 34, 14, 3, 'var(--a4)') + R(124, 62, 14, 4, 2, 'var(--a1)') + (function () { var g = ''; for (r = 0; r < 3; r++) for (c = 0; c < 3; c++) g += R(122 + c * 11, 78 + r * 12, 8, 8, 2, 'var(--a4)', ' opacity=".7"'); return g; })();
  };
})();
/* DAV_ART : visuels produits, 2e partie (énergie, impression, stockage, accessoires, caisse, logiciels) */
(function () {
  'use strict';
  var K = window.DAV_ART._k, D = window.DAV_ART._products;
  var R = K.R, C = K.C, P = K.P, L = K.L, ln = K.ln, B = K.B, i, r, c;
  var RIM = K.RIM;

  function panel(pts, t, hz) { /* panneau solaire : 4 coins [x,y] + grille */
    var a = pts[0], b = pts[1], cc = pts[2], d = pts[3], g = '', n;
    var d1 = 'M' + a + 'L' + b + 'L' + cc + 'L' + d + 'z';
    for (n = 1; n <= t; n++) { var u = n / (t + 1); g += 'M' + K.f(a[0] + (b[0] - a[0]) * u) + ' ' + K.f(a[1] + (b[1] - a[1]) * u) + 'L' + K.f(d[0] + (cc[0] - d[0]) * u) + ' ' + K.f(d[1] + (cc[1] - d[1]) * u); }
    for (n = 1; n <= hz; n++) { var v = n / (hz + 1); g += 'M' + K.f(a[0] + (d[0] - a[0]) * v) + ' ' + K.f(a[1] + (d[1] - a[1]) * v) + 'L' + K.f(b[0] + (cc[0] - b[0]) * v) + ' ' + K.f(b[1] + (cc[1] - b[1]) * v); }
    return K.sh(P(d1)) + P(d1, 'var(--a1)', RIM) + L(g, 'var(--a4)', 1.4, ' opacity=".55"');
  }

  D.ups = function () {
    var s = B(50, 36, 100, 86, 10) + R(60, 46, 54, 18, 3, 'var(--a4)') + R(66, 52, 26, 6, 3, 'var(--a1)', ' opacity=".85"') + C(134, 56, 4, 'var(--a2)');
    for (i = 0; i < 3; i++) s += R(60 + i * 26, 78, 20, 30, 5, 'var(--a4)', ' opacity=".2"') + R(66 + i * 26, 88, 3, 8, 1, 'var(--a4)') + R(74 + i * 26, 88, 3, 8, 1, 'var(--a4)');
    return s;
  };
  D.battery = function () {
    return R(60, 38, 18, 12, 2, 'var(--a5)') + R(122, 38, 18, 12, 2, 'var(--a5)') + B(42, 50, 116, 72, 8) + R(54, 62, 92, 44, 5, 'var(--a4)', ' opacity=".14"') + P('M104 68l-14 20h10l-4 16 19-24h-11z', 'var(--a2)');
  };
  D.solarpanel = function () {
    return panel([[46, 38], [150, 26], [166, 90], [62, 102]], 4, 1) + L('M108 96v24M80 124h56', 'var(--a3)', 5) + C(176, 28, 9, 'var(--a2)');
  };
  D.solarkit = function () {
    return panel([[50, 24], [116, 16], [126, 52], [60, 60]], 2, 1) + L('M84 58L64 84', 'var(--a5)', 3, ' stroke-dasharray="2 5"') +
      B(30, 84, 58, 38, 7) + R(38, 92, 24, 10, 2, 'var(--a4)') + C(78, 97, 3, 'var(--a2)') + R(38, 108, 40, 4, 2, 'var(--a4)', ' opacity=".3"') +
      L('M88 104h18', 'var(--a5)', 3) + R(114, 86, 10, 6, 2, 'var(--a5)') + R(144, 86, 10, 6, 2, 'var(--a5)') + B(106, 92, 60, 30, 6) + R(114, 100, 44, 14, 3, 'var(--a1)');
  };
  D.stabilizer = function () {
    return B(42, 40, 116, 80, 10) + C(80, 82, 23, 'var(--a4)') + '<circle cx="80" cy="82" r="16" fill="none" stroke="var(--a3)" stroke-opacity=".35" stroke-width="2"/>' + L('M80 82l10-10', 'var(--a3)', 3.5) + C(91, 71, 3, 'var(--a2)') +
      R(112, 54, 36, 18, 3, 'var(--a4)') + ln(118, 60, 22, 'var(--a1)', '.8') + R(112, 84, 16, 22, 4, 'var(--a4)', ' opacity=".25"') + R(132, 84, 16, 22, 4, 'var(--a4)', ' opacity=".25"');
  };
  D.surge = function () {
    var s = L('M178 90c14 0 16 30-6 30H120', 'var(--a3)', 5) + B(22, 66, 156, 40, 10) + R(32, 76, 12, 22, 3, 'var(--a4)', ' opacity=".85"') + C(38, 82, 2.4, 'var(--a2)');
    for (i = 0; i < 5; i++) s += R(52 + i * 25, 74, 19, 24, 5, 'var(--a4)', ' opacity=".25"') + R(57 + i * 25, 83, 3, 6, 1, 'var(--a4)') + R(65 + i * 25, 83, 3, 6, 1, 'var(--a4)');
    return s;
  };
  D.printer = function () {
    return K.K(60, 30, 80, 34, 3) + ln(70, 38, 40) + ln(70, 50, 28) + B(36, 56, 128, 50, 9) + R(48, 68, 34, 8, 3, 'var(--a4)', ' opacity=".3"') + C(150, 72, 3, 'var(--a2)') + K.K(56, 98, 88, 26, 3) + ln(64, 106, 44) + ln(64, 116, 30, 'var(--a1)', '.6');
  };
  D.mfp = function () {
    return K.K(64, 22, 72, 22, 3) + ln(72, 30, 40) + R(40, 40, 120, 16, 4, 'var(--a5)', RIM) + B(34, 56, 132, 52, 9) + R(118, 64, 38, 20, 3, 'var(--a4)') + ln(124, 70, 20, 'var(--a1)', '.8') + C(148, 76, 2.6, 'var(--a2)') + R(44, 66, 56, 6, 3, 'var(--a4)', ' opacity=".25"') + K.K(54, 100, 80, 24, 3) + ln(62, 108, 40) + ln(62, 117, 28, 'var(--a1)', '.6');
  };
  D.scanner = function () {
    return B(30, 74, 140, 38, 8) + K.sh(P('M42 74l8-32h100l8 32z')) + P('M42 74l8-32h100l8 32z', 'var(--a3)', RIM) + R(44, 88, 112, 10, 3, 'var(--a1)', ' opacity=".55"') + C(160, 100, 3, 'var(--a2)');
  };
  D.cardprinter = function () {
    return B(40, 52, 120, 56, 9) + R(60, 44, 34, 10, 2, 'var(--a1)', ' opacity=".75"') + R(52, 66, 34, 10, 3, 'var(--a4)', ' opacity=".3"') + C(146, 70, 3, 'var(--a2)') + R(66, 94, 68, 5, 2.5, 'var(--a6)', ' opacity=".3"') +
      K.K(70, 98, 60, 34, 5) + C(84, 112, 6.5, 'var(--a1)') + ln(96, 106, 28) + ln(96, 117, 20, 'var(--a5)', '.35');
  };
  D.toner = function () {
    return R(70, 36, 60, 10, 5, 'var(--a5)', RIM) + B(36, 46, 128, 64, 12) + R(54, 58, 92, 40, 6, 'var(--a4)', ' opacity=".14"') + R(30, 64, 8, 28, 3, 'var(--a5)') + P('M100 64c-7 9-10 13-10 18a10 10 0 0 0 20 0c0-5-3-9-10-18z', 'var(--a2)');
  };
  D.hdd = function () {
    return L('M154 82h14c8 0 8 24 0 24h-22', 'var(--a3)', 5) + B(44, 42, 110, 70, 11) + R(56, 54, 54, 6, 3, 'var(--a4)', ' opacity=".3"') + R(56, 66, 38, 5, 2.5, 'var(--a4)', ' opacity=".2"') + C(86, 94, 10, 'var(--a4)', ' opacity=".14"') + R(146, 66, 8, 14, 2, 'var(--a5)') + C(138, 98, 3.4, 'var(--a2)');
  };
  D.ssd = function () {
    return B(38, 60, 122, 44, 7) + R(160, 70, 7, 24, 1.5, 'var(--a5)') + R(48, 70, 48, 6, 3, 'var(--a4)', ' opacity=".35"') + R(48, 82, 32, 5, 2.5, 'var(--a4)', ' opacity=".2"') + R(108, 70, 14, 24, 2, 'var(--a1)') + R(126, 70, 14, 24, 2, 'var(--a1)', ' opacity=".7"') + C(148, 74, 2.8, 'var(--a2)');
  };
  D.usb = function () {
    return B(48, 58, 86, 44, 11) + R(134, 66, 34, 28, 3, 'var(--a5)', RIM) + R(144, 74, 20, 4, 1, 'var(--a3)') + R(144, 84, 20, 4, 1, 'var(--a3)') + C(62, 80, 5, 'var(--a6)') + R(76, 70, 44, 6, 3, 'var(--a4)', ' opacity=".35"') + R(76, 82, 30, 5, 2.5, 'var(--a4)', ' opacity=".2"') + C(122, 91, 3, 'var(--a2)');
  };
  D.sdcard = function () {
    var d = 'M72 28h42l20 20v66a8 8 0 0 1-8 8H72a8 8 0 0 1-8-8V36a8 8 0 0 1 8-8z', s = K.sh(P(d)) + P(d, 'var(--a3)', RIM);
    s += R(72, 58, 52, 8, 3, 'var(--a2)') + R(72, 72, 52, 24, 4, 'var(--a4)', ' opacity=".14"');
    for (i = 0; i < 6; i++) s += R(73 + i * 8, 100, 5, 16, 1, 'var(--a5)');
    return s;
  };
  D.monitor = function () {
    return K.mon(38, 26, 124, 80, R(46, 38, 40, 30, 4, 'var(--a1)', ' opacity=".85"') + ln(94, 40, 54) + ln(94, 52, 40, 'var(--a5)', '.35') + R(46, 76, 108, 12, 4, 'var(--a5)', ' opacity=".25"')) + C(148, 101, 2.3, 'var(--a2)');
  };
  D.keyboardmouse = function () {
    var s = B(24, 62, 126, 50, 8);
    for (r = 0; r < 3; r++) for (c = 0; c < 9; c++) s += R(32 + c * 12, 68 + r * 11, 9, 8, 2, 'var(--a4)', ' opacity=".75"');
    return s + R(54, 102, 52, 6, 2, 'var(--a4)', ' opacity=".75"') + B(158, 66, 28, 46, 13) + L('M172 66v18', 'var(--a4)', 1.5, ' opacity=".6"') + R(169.5, 72, 5, 9, 2.5, 'var(--a2)');
  };
  D.headset = function () {
    return L('M52 84a48 48 0 0 1 96 0', 'var(--a3)', 9) + B(40, 78, 24, 40, 11) + B(136, 78, 24, 40, 11) + L('M148 114c0 10-8 14-26 14', 'var(--a3)', 5) + C(120, 128, 5.5, 'var(--a2)');
  };
  D.webcam = function () {
    return K.sh(C(100, 62, 34)) + C(100, 62, 34, 'var(--a3)', RIM) + C(100, 62, 23, 'var(--a1)') + C(100, 62, 11, 'var(--a3)') + C(94, 56, 3.4, 'var(--a4)', ' opacity=".8"') +
      P('M80 96h40l8 14H72z', 'var(--a3)') + R(68, 108, 64, 9, 4.5, 'var(--a3)', RIM) + C(100, 103, 2.6, 'var(--a2)');
  };
  D.projector = function () {
    return P('M154 82L192 58v56l-38-24z', 'var(--a1)', ' opacity=".18"') + B(30, 60, 128, 50, 12) + C(134, 86, 17, 'var(--a4)') + C(134, 86, 10.5, 'var(--a1)') + C(134, 86, 4, 'var(--a4)', ' opacity=".5"') +
      L('M46 76h46M46 85h46M46 94h46', 'var(--a5)', 2.5, ' opacity=".6"') + R(44, 110, 12, 6, 2, 'var(--a5)') + R(130, 110, 12, 6, 2, 'var(--a5)') + C(44, 100, 3, 'var(--a2)');
  };
  D.pos = function () {
    return B(36, 24, 120, 72, 9) + R(42, 30, 108, 52, 4, 'var(--a4)') + R(50, 38, 28, 16, 3, 'var(--a1)', ' opacity=".8"') + R(82, 38, 28, 16, 3, 'var(--a5)', ' opacity=".5"') + R(114, 38, 28, 16, 3, 'var(--a5)', ' opacity=".5"') + R(50, 60, 92, 14, 3, 'var(--a1)', ' opacity=".25"') +
      P('M80 96h32l8 20H72z', 'var(--a3)') + R(60, 114, 72, 8, 4, 'var(--a3)', RIM) + B(150, 92, 34, 28, 6) + R(156, 98, 22, 5, 2, 'var(--a4)', ' opacity=".4"') + C(167, 112, 2.6, 'var(--a2)');
  };
  D.barcode = function () {
    var s = '';
    for (i = 0; i < 8; i++) s += R(160 + i * 4.5, 40, 2 + (i % 3), 30, 0, 'var(--a3)', ' opacity=".6"');
    return s + B(34, 38, 106, 36, 10) + R(130, 46, 8, 20, 2, 'var(--a4)') + B(66, 68, 38, 56, 11) + R(96, 82, 6, 14, 3, 'var(--a5)') + L('M142 56h50', 'var(--a2)', 2.8);
  };
  D.thermal = function () {
    return K.K(76, 20, 48, 52, 2) + ln(84, 30, 32) + ln(84, 41, 22) + ln(84, 52, 28, 'var(--a5)', '.4') + B(44, 62, 112, 48, 10) + R(72, 62, 56, 5, 2.5, 'var(--a6)', ' opacity=".3"') + R(58, 86, 24, 8, 4, 'var(--a1)', ' opacity=".7"') + C(140, 90, 3, 'var(--a2)');
  };
  D.cashdrawer = function () {
    var s = B(34, 50, 132, 40, 7) + K.K(42, 86, 116, 34, 4);
    for (i = 0; i < 4; i++) s += R(50 + i * 27, 96, 22, 18, 3, 'var(--a5)', ' opacity=".4"');
    return s + R(60, 78, 42, 14, 2, 'var(--a1)', ' opacity=".8"') + C(132, 90, 6.5, 'var(--a2)') + R(80, 62, 40, 6, 3, 'var(--a4)', ' opacity=".3"');
  };
  D.license = function () {
    return K.K(54, 26, 84, 100, 6) + P('M138 26l16-8v100l-16 8z', 'var(--a5)', ' opacity=".6"') + P('M54 32a6 6 0 0 1 6-6h72a6 6 0 0 1 6 6v24H54z', 'var(--a1)') + ln(64, 38, 48, 'var(--a4)', '.9') + ln(64, 46, 30, 'var(--a4)', '.6') +
      ln(64, 66, 54) + ln(64, 78, 40) + C(96, 104, 14, 'var(--a2)') + L('M89 104l5 5 9-10', 'var(--a3)', 3);
  };
  D.antivirus = function () {
    return K.mon(44, 30, 112, 74, K.shield(100, 63, 0.95, 'var(--a1)') + L('M91 63l7 7 13-15', 'var(--a4)', 4)) + C(146, 99, 2.2, 'var(--a2)');
  };
})();
