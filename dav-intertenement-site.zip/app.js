/* ==========================================================================
   Dav Intertenement : noyau (outils, langue, thème, base de données)
   ========================================================================== */
(function () {
  'use strict';
  var D = window.DAV = window.DAV || {};
  var CFG = D.cfg = window.DAV_CONFIG || {};
  var CAT = D.cat = window.DAV_CATALOG || { domains: [], sectors: [], process: [], why: [], faq: [], productCats: [], products: [] };
  var ART = D.art = window.DAV_ART;
  var I18N = window.DAV_I18N || { fr: {}, en: {} };

  /* Valeurs par défaut au cas où une ligne de config.js serait effacée */
  CFG.brand = CFG.brand || { name: 'Dav Intertenement', city: 'Kinshasa', country: { fr: 'RDC', en: 'DR Congo' } };
  CFG.brand.logo = CFG.brand.logo || 'img/logo-mark.webp';
  CFG.brand.emblem = CFG.brand.emblem || 'img/logo-emblem.webp';
  CFG.contact = CFG.contact || {};
  CFG.contact.phones = CFG.contact.phones || [];
  CFG.contact.address = CFG.contact.address || { fr: '', en: '' };
  CFG.contact.hours = CFG.contact.hours || { fr: '', en: '' };
  CFG.social = CFG.social || {};
  CFG.supabase = CFG.supabase || { url: '', anonKey: '' };
  CFG.shop = CFG.shop || { cdfRate: 0, deliveryNote: { fr: '', en: '' } };
  CFG.shop.deliveryNote = CFG.shop.deliveryNote || { fr: '', en: '' };
  CFG.appointment = CFG.appointment || { daysAhead: 14, closedWeekdays: [0], start: '08:00', end: '17:00', slotMinutes: 60, types: ['onsite', 'phone', 'video'] };
  CFG.images = CFG.images || { hero: '', domains: {}, products: {}, projects: {} };
  CFG.images.domains = CFG.images.domains || {};
  CFG.images.products = CFG.images.products || {};
  CFG.images.projects = CFG.images.projects || {};
  CFG.projects = CFG.projects || [];
  CFG.testimonials = CFG.testimonials || [];

  /* ---------- Outils ---------- */
  var $ = D.$ = function (s, r) { return (r || document).querySelector(s); };
  var $$ = D.$$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };
  var ESC = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
  D.esc = function (s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return ESC[c]; }); };
  D.norm = function (s) { return String(s || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[’‘`]/g, "'"); };
  /* Recherche tolérante : « wifi » trouve aussi « Wi-Fi », « ecommerce » trouve « e-commerce » */
  D.matcher = function (q) {
    var res = D.norm(q).split(/\s+/).map(function (w) { return w.replace(/-/g, ''); }).filter(Boolean).map(function (w) {
      return new RegExp(w.split('').map(function (c) { return c.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); }).join('-?'), 'g');
    });
    return {
      n: res.length, res: res,
      all: function (hay) { return res.every(function (r) { r.lastIndex = 0; return r.test(hay); }); },
      starts: function (hay) { var r = res[0]; return !!r && new RegExp('(^|[\\s\',\\-\\/()&])' + r.source).test(hay); }
    };
  };
  D.longDate = function (str) {
    var p = String(str).split('-');
    if (p.length !== 3) return str;
    return new Intl.DateTimeFormat(D.lang === 'fr' ? 'fr-FR' : 'en-GB', { day: 'numeric', month: 'long', year: 'numeric', timeZone: 'UTC' }).format(new Date(Date.UTC(+p[0], +p[1] - 1, +p[2])));
  };
  D.icon = function (k, o) { return ART.icon(k, o); };
  D.pref = {
    get: function (k) { try { return localStorage.getItem(k); } catch (e) { return null; } },
    set: function (k, v) { try { localStorage.setItem(k, v); } catch (e) { /* stockage indisponible */ } }
  };
  D.store = {
    get: function (k, d) { try { var v = localStorage.getItem(k); return v == null ? d : JSON.parse(v); } catch (e) { return d; } },
    set: function (k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { /* stockage indisponible */ } }
  };
  var bus = {};
  D.on = function (n, f) { (bus[n] = bus[n] || []).push(f); };
  D.emit = function (n, d) { (bus[n] || []).forEach(function (f) { try { f(d); } catch (e) { if (window.console) console.error(e); } }); };
  D.hydrate = function (root) {
    $$('[data-icon]', root).forEach(function (el) { if (!el.firstChild) el.innerHTML = D.icon(el.getAttribute('data-icon')); });
  };
  D.newId = function () {
    if (window.crypto && crypto.randomUUID) return crypto.randomUUID();
    var h = '0123456789abcdef', s = '', i;
    for (i = 0; i < 36; i++) s += (i === 8 || i === 13 || i === 18 || i === 23) ? '-' : (i === 14 ? '4' : h[Math.floor(Math.random() * 16)]);
    return s;
  };
  D.refOf = function (id) { return 'DAV-' + String(id).replace(/-/g, '').slice(0, 6).toUpperCase(); };

  /* ---------- Langue ---------- */
  D.lang = 'fr';
  D.t = function (k, v) {
    var s = I18N[D.lang] && I18N[D.lang][k];
    if (s == null) s = I18N.fr && I18N.fr[k];
    if (s == null) return k;
    if (v) s = s.replace(/\{(\w+)\}/g, function (m, n) { return v[n] == null ? m : v[n]; });
    return s;
  };
  D.tn = function (k, n, v) {
    var one = D.lang === 'fr' ? n < 2 : n === 1;
    v = v || {}; v.n = n;
    return D.t(k + (one ? '.one' : '.many'), v);
  };
  D.pick = function (o) { if (!o) return ''; if (typeof o === 'string') return o; return o[D.lang] || o.fr || o.en || ''; };
  D.applyI18n = function (root) {
    $$('[data-i18n]', root).forEach(function (el) { el.textContent = D.t(el.getAttribute('data-i18n')); });
    $$('[data-i18n-ph]', root).forEach(function (el) { el.setAttribute('placeholder', D.t(el.getAttribute('data-i18n-ph'))); });
    $$('[data-i18n-aria]', root).forEach(function (el) { el.setAttribute('aria-label', D.t(el.getAttribute('data-i18n-aria'))); });
    $$('[data-i18n-title]', root).forEach(function (el) { el.setAttribute('title', D.t(el.getAttribute('data-i18n-title'))); });
  };
  function setMeta(sel, val) { var m = $(sel); if (m) m.setAttribute('content', val); }
  D.setLang = function (l, silent) {
    D.lang = l === 'en' ? 'en' : 'fr';
    document.documentElement.lang = D.lang;
    D.pref.set('dav-lang', D.lang);
    D.applyI18n();
    document.title = D.t('meta.title');
    setMeta('meta[name="description"]', D.t('meta.desc'));
    setMeta('meta[property="og:title"]', D.t('meta.title'));
    setMeta('meta[property="og:description"]', D.t('meta.ogdesc'));
    setMeta('meta[property="og:locale"]', D.lang === 'fr' ? 'fr_FR' : 'en_US');
    D.updateTools();
    if (!silent) D.emit('lang', D.lang);
  };

  /* ---------- Thème ---------- */
  D.theme = function () { return document.documentElement.getAttribute('data-theme') === 'dark' ? 'dark' : 'light'; };
  D.setTheme = function (t) {
    document.documentElement.setAttribute('data-theme', t);
    D.pref.set('dav-theme', t);
    setMeta('meta[name="theme-color"]', t === 'dark' ? '#060707' : '#0B0C0D');
    D.updateTools();
  };
  D.updateTools = function () {
    $$('[data-act="lang"]').forEach(function (b) {
      var c = $('.lang-code', b), l = $('.lang-label', b);
      if (c) c.textContent = D.lang === 'fr' ? 'EN' : 'FR';
      if (l) l.textContent = D.lang === 'fr' ? 'English' : 'Français';
      b.setAttribute('aria-label', D.t(D.lang === 'fr' ? 'tool.toEn' : 'tool.toFr'));
    });
    $$('[data-act="theme"]').forEach(function (b) {
      var dark = D.theme() === 'dark', ic = $('[data-icon]', b), l = $('.theme-label', b);
      if (ic) { ic.setAttribute('data-icon', dark ? 'sun' : 'moon'); ic.innerHTML = D.icon(dark ? 'sun' : 'moon'); }
      if (l) l.textContent = D.t(dark ? 'tool.light' : 'tool.dark');
      b.setAttribute('aria-label', D.t(dark ? 'tool.light' : 'tool.dark'));
    });
  };

  /* ---------- Montants ---------- */
  D.money = function (usd) {
    return new Intl.NumberFormat(D.lang === 'fr' ? 'fr-FR' : 'en-US', { style: 'currency', currency: 'USD', minimumFractionDigits: 0, maximumFractionDigits: 2 }).format(usd);
  };
  D.cdf = function (usd) {
    var r = Number(CFG.shop.cdfRate) || 0;
    if (!r) return '';
    return '≈ ' + new Intl.NumberFormat(D.lang === 'fr' ? 'fr-FR' : 'en-US', { maximumFractionDigits: 0 }).format(usd * r) + ' FC';
  };

  /* ---------- Message court ---------- */
  var toastT;
  D.toast = function (msg, act) {
    var el = $('#toast');
    if (!el) return;
    el.textContent = msg;
    if (act) {
      var b = document.createElement('button');
      b.type = 'button'; b.textContent = act.label;
      b.addEventListener('click', function () { el.classList.remove('show'); act.fn(); });
      el.appendChild(b);
    }
    el.classList.add('show');
    clearTimeout(toastT);
    toastT = setTimeout(function () { el.classList.remove('show'); }, act ? 5200 : 3200);
  };

  /* ---------- Fenêtres ---------- */
  D.openDialog = function (d) {
    if (!d) return;
    if (typeof d.showModal === 'function') { if (!d.open) d.showModal(); } else d.setAttribute('open', '');
    document.documentElement.classList.add('lock');
  };
  D.closeDialog = function (d) {
    if (!d) return;
    if (typeof d.close === 'function') d.close(); else d.removeAttribute('open');
    if (!$$('dialog.sheet[open]').length) document.documentElement.classList.remove('lock');
  };
  D.initDialogs = function () {
    $$('dialog.sheet').forEach(function (d) {
      d.addEventListener('close', function () { if (!$$('dialog.sheet[open]').length) document.documentElement.classList.remove('lock'); });
      d.addEventListener('click', function (e) { if (e.target === d) D.closeDialog(d); });
      $$('[data-close]', d).forEach(function (b) { b.addEventListener('click', function () { D.closeDialog(d); }); });
    });
  };

  /* ---------- Contacts, WhatsApp, e-mail ---------- */
  D.waNumber = function (n) { return String(n || CFG.contact.whatsapp || '').replace(/\D/g, ''); };
  D.waLink = function (text, num) { return 'https://wa.me/' + D.waNumber(num) + (text ? '?text=' + encodeURIComponent(text) : ''); };
  D.mailLink = function (subject, body) { return 'mailto:' + (CFG.contact.email || '') + '?subject=' + encodeURIComponent(subject) + '&body=' + encodeURIComponent(body); };
  D.openWa = function (text) { var a = document.createElement('a'); a.href = D.waLink(text); a.target = '_blank'; a.rel = 'noopener'; a.hidden = true; document.body.appendChild(a); a.click(); a.remove(); };
  D.openMail = function (subject, body) { location.href = D.mailLink(subject, body); };
  D.hasAddress = function () { return !!D.pick(CFG.contact.address).trim(); };

  /* ---------- Téléphone ---------- */
  D.COUNTRIES = [
    ['+243', 'RDC', 'DR Congo'], ['+242', 'Congo-Brazzaville', 'Congo-Brazzaville'], ['+244', 'Angola', 'Angola'], ['+250', 'Rwanda', 'Rwanda'],
    ['+257', 'Burundi', 'Burundi'], ['+256', 'Ouganda', 'Uganda'], ['+255', 'Tanzanie', 'Tanzania'], ['+254', 'Kenya', 'Kenya'],
    ['+260', 'Zambie', 'Zambia'], ['+236', 'Centrafrique', 'Central African Rep.'], ['+241', 'Gabon', 'Gabon'], ['+237', 'Cameroun', 'Cameroon'],
    ['+234', 'Nigeria', 'Nigeria'], ['+27', 'Afrique du Sud', 'South Africa'], ['+212', 'Maroc', 'Morocco'], ['+33', 'France', 'France'],
    ['+32', 'Belgique', 'Belgium'], ['+41', 'Suisse', 'Switzerland'], ['+44', 'Royaume-Uni', 'United Kingdom'], ['+1', 'États-Unis, Canada', 'USA, Canada'],
    ['+971', 'Émirats arabes unis', 'UAE'], ['+86', 'Chine', 'China'], ['+90', 'Turquie', 'Türkiye'], ['+91', 'Inde', 'India']
  ];
  D.fillCC = function () {
    $$('select[data-cc]').forEach(function (s) {
      var cur = s.value || '+243';
      s.innerHTML = D.COUNTRIES.map(function (c) { return '<option value="' + c[0] + '">' + c[0] + ' ' + D.esc(D.lang === 'fr' ? c[1] : c[2]) + '</option>'; }).join('');
      s.value = cur;
    });
  };
  D.fullPhone = function (cc, raw) {
    var r = String(raw || '').trim();
    if (!r) return '';
    if (r.charAt(0) === '+') return '+' + r.replace(/\D/g, '');
    var d = r.replace(/\D/g, '');
    if (d.indexOf('00') === 0) return '+' + d.slice(2);
    return (cc || '+243') + d.replace(/^0+/, '');
  };
  D.validPhone = function (p) { return /^\+\d{8,15}$/.test(p); };
  D.validEmail = function (e) { return /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(e); };

  D.COMMUNES = ['Bandalungwa', 'Barumbu', 'Bumbu', 'Gombe', 'Kalamu', 'Kasa-Vubu', 'Kimbanseke', 'Kinshasa', 'Kintambo', 'Kisenso', 'Lemba', 'Limete', 'Lingwala', 'Makala', 'Maluku', 'Masina', 'Matete', 'Mont-Ngafula', 'Ndjili', 'Ngaba', 'Ngaliema', 'Ngiri-Ngiri', 'Nsele', 'Selembao'];

  /* ---------- Heure de Kinshasa ---------- */
  D.kinNow = function () {
    var out = { y: 0, m: 0, d: 0, h: 0, i: 0 };
    try {
      new Intl.DateTimeFormat('en-GB', { timeZone: 'Africa/Kinshasa', year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', hourCycle: 'h23' })
        .formatToParts(new Date()).forEach(function (p) {
          if (p.type === 'year') out.y = +p.value; else if (p.type === 'month') out.m = +p.value; else if (p.type === 'day') out.d = +p.value;
          else if (p.type === 'hour') out.h = (+p.value) % 24; else if (p.type === 'minute') out.i = +p.value;
        });
    } catch (e) {
      var n = new Date(Date.now() + (new Date().getTimezoneOffset() + 60) * 60000);
      out = { y: n.getFullYear(), m: n.getMonth() + 1, d: n.getDate(), h: n.getHours(), i: n.getMinutes() };
    }
    return out;
  };
  D.pad = function (n) { return (n < 10 ? '0' : '') + n; };
  D.todayStr = function () { var n = D.kinNow(); return n.y + '-' + D.pad(n.m) + '-' + D.pad(n.d); };

  /* ---------- Contrôle des champs ---------- */
  D.fieldError = function (input, msg, keep) {
    var f = input.closest('.field') || input.parentNode, e = $('.err', f);
    f.classList.add('invalid');
    if (!e) { e = document.createElement('p'); e.className = 'err'; e.id = (input.id || 'f' + Math.random().toString(36).slice(2, 7)) + '-err'; f.appendChild(e); }
    e.innerHTML = D.icon('alert') + '<span></span>';
    e.lastChild.textContent = msg;
    input.setAttribute('aria-invalid', 'true');
    input.setAttribute('aria-describedby', e.id);
    return keep || input;
  };
  D.clearErrors = function (form) {
    $$('.field.invalid', form).forEach(function (f) { f.classList.remove('invalid'); });
    $$('.err', form).forEach(function (e) { e.remove(); });
    $$('[aria-invalid]', form).forEach(function (i) { i.removeAttribute('aria-invalid'); i.removeAttribute('aria-describedby'); });
    $$('.form-error', form).forEach(function (e) { e.hidden = true; });
  };
  D.watchErrors = function (form) {
    form.addEventListener('input', function (e) {
      var f = e.target.closest && e.target.closest('.field.invalid');
      if (!f) return;
      f.classList.remove('invalid');
      var er = $('.err', f); if (er) er.remove();
      e.target.removeAttribute('aria-invalid'); e.target.removeAttribute('aria-describedby');
    });
  };
  D.formError = function (el, msg) { if (!el) return; el.textContent = msg; el.hidden = false; };
  var lastSend = 0;
  D.tooFast = function () { var n = Date.now(); if (n - lastSend < 6000) { D.toast(D.t('err.wait')); return true; } lastSend = n; return false; };
  D.busy = function (btn, on) { if (!btn) return; btn.disabled = !!on; btn.setAttribute('aria-busy', on ? 'true' : 'false'); };
  D.fmtSize = function (b) { return b < 1048576 ? Math.max(1, Math.round(b / 1024)) + ' Ko' : (b / 1048576).toFixed(1).replace('.', ',') + ' Mo'; };

  /* Message de confirmation après un envoi */
  D.showDone = function (form, bodyId, doneId, o) {
    var body = $('#' + bodyId), done = $('#' + doneId);
    var h = '<div class="done-art">' + ART.empty(o.art || 'success') + '</div><h3>' + D.esc(o.title) + '</h3>';
    if (o.ref) h += '<p><span class="ref">' + D.esc(o.ref) + '</span></p>';
    h += '<p>' + D.esc(o.text) + '</p><div class="btn-row">';
    if (o.wa) h += '<a class="btn btn-wa" href="' + D.esc(D.waLink(o.wa)) + '" target="_blank" rel="noopener">' + D.icon('whatsapp') + '<span>' + D.esc(D.t(o.waLabel || 'done.wa')) + '</span></a>';
    h += '<button class="btn btn-ghost" type="button" data-again>' + D.esc(D.t('done.again')) + '</button></div>';
    done.innerHTML = h;
    body.hidden = true; done.hidden = false;
    var again = $('[data-again]', done);
    again.addEventListener('click', function () { done.hidden = true; body.hidden = false; if (o.onAgain) o.onAgain(); var f = $('input,textarea', body); if (f) f.focus(); });
    var hd = $('h3', done); hd.setAttribute('tabindex', '-1'); hd.focus({ preventScroll: true });
    if (done.scrollIntoView) done.scrollIntoView({ block: 'center', behavior: 'smooth' });
  };

  /* ---------- Base de données Supabase (facultative) ---------- */
  var sb = null;
  var db = D.db = { enabled: !!(CFG.supabase.url && CFG.supabase.anonKey) };
  function loadScript(src) {
    return new Promise(function (ok, ko) {
      var s = document.createElement('script');
      s.src = src; s.async = true; s.onload = ok; s.onerror = function () { ko(new Error('script')); };
      document.head.appendChild(s);
    });
  }
  db.client = function () {
    if (!db.enabled) return Promise.reject(new Error('db-off'));
    if (!sb) {
      sb = loadScript('https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2.45.4/dist/umd/supabase.js').then(function () {
        return window.supabase.createClient(CFG.supabase.url, CFG.supabase.anonKey, { auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: true } });
      }).catch(function (e) { sb = null; throw e; });
    }
    return sb;
  };
  db.insert = function (table, row) {
    return db.client().then(function (c) { return c.from(table).insert(row); }).then(function (r) { if (r.error) throw r.error; return true; });
  };
  db.rpc = function (fn, args) {
    return db.client().then(function (c) { return c.rpc(fn, args || {}); }).then(function (r) { if (r.error) throw r.error; return r.data; });
  };
  db.upload = function (path, file) {
    return db.client().then(function (c) { return c.storage.from('attachments').upload(path, file, { contentType: file.type || 'application/octet-stream', upsert: false }); })
      .then(function (r) { if (r.error) throw r.error; return path; });
  };
  D.dbMode = function () { return db.enabled; };
})();
/* ==========================================================================
   Dav Intertenement : accueil, recherche, liste de services, ma liste de devis
   ========================================================================== */
(function () {
  'use strict';
  var D = window.DAV, $ = D.$, $$ = D.$$, esc = D.esc, CAT = D.cat, CFG = D.cfg, ART = D.art;
  function t(k, v) { return D.t(k, v); }

  /* ---------- Données à plat ---------- */
  var SVC = D.SVC = [], SVC_BY_ID = {}, DOM_BY_ID = D.DOM_BY_ID = {}, SEC_BY_ID = D.SEC_BY_ID = {}, DOMHAY = {};
  CAT.domains.forEach(function (d, di) {
    DOM_BY_ID[d.id] = d;
    DOMHAY[d.id] = D.norm(d.fr.name + ' ' + d.en.name + ' ' + d.kw);
    d.services.forEach(function (s, si) {
      var o = { id: d.id + ':' + si, dom: d.id, di: di, fr: s[0], en: s[1], hay: D.norm(s[0] + ' ' + s[1]) };
      SVC.push(o); SVC_BY_ID[o.id] = o;
    });
  });
  CAT.sectors.forEach(function (s) { SEC_BY_ID[s.id] = s; });
  D.domName = function (d) { return d[D.lang] ? d[D.lang].name : d.fr.name; };

  /* ---------- Ma liste (panier de devis) ---------- */
  var KEY = 'dav-basket';
  var basket = D.basket = { items: [] };
  function needLabel(id) {
    var m = /^need:([^:]+):(\d+)$/.exec(id), s = m && SEC_BY_ID[m[1]];
    return s ? { fr: s.fr.needs[+m[2]], en: s.en.needs[+m[2]] } : null;
  }
  function valid(it) {
    if (!it || typeof it.id !== 'string') return false;
    if (SVC_BY_ID[it.id]) return true;
    if (needLabel(it.id)) return true;
    return it.id.indexOf('custom:') === 0 && typeof it.text === 'string' && it.text.length > 0;
  }
  basket.load = function () { var a = D.store.get(KEY, []); basket.items = (Array.isArray(a) ? a : []).filter(valid); };
  basket.save = function () { D.store.set(KEY, basket.items); };
  basket.has = function (id) { return basket.items.some(function (i) { return i.id === id; }); };
  basket.count = function () { return basket.items.length; };
  basket.label = function (it) {
    if (SVC_BY_ID[it.id]) return SVC_BY_ID[it.id][D.lang];
    var n = needLabel(it.id);
    if (n) return n[D.lang];
    return it.text || '';
  };
  basket.pair = function (it) {
    if (SVC_BY_ID[it.id]) return { fr: SVC_BY_ID[it.id].fr, en: SVC_BY_ID[it.id].en };
    var n = needLabel(it.id);
    return n || { fr: it.text, en: it.text };
  };
  function fire() { basket.save(); D.emit('basket'); }
  basket.add = function (id, text) { if (basket.has(id)) return false; basket.items.push(text ? { id: id, text: text } : { id: id }); fire(); return true; };
  basket.remove = function (id) { basket.items = basket.items.filter(function (i) { return i.id !== id; }); fire(); };
  basket.toggle = function (id) { if (basket.has(id)) { basket.remove(id); return false; } basket.add(id); return true; };
  basket.addCustom = function (text) {
    text = String(text || '').replace(/\s+/g, ' ').trim().slice(0, 120);
    if (!text) return false;
    var h = 0, n = D.norm(text), i;
    for (i = 0; i < n.length; i++) h = (h * 31 + n.charCodeAt(i)) >>> 0;
    return basket.add('custom:' + h.toString(36), text);
  };
  basket.clear = function () { basket.items = []; fire(); };

  /* ---------- Recherche dans les services ---------- */
  D.searchServices = function (q, limit) {
    var m = D.matcher(q), out = [];
    if (!m.n) return out;
    SVC.forEach(function (s, idx) {
      var score = 0;
      if (m.all(s.hay)) score = m.starts(s.hay) ? 4 : 3;
      else if (m.all(s.hay + ' ' + DOMHAY[s.dom])) score = 1;
      if (score) out.push({ s: s, score: score, idx: idx });
    });
    out.sort(function (a, b) { return b.score - a.score || a.idx - b.idx; });
    return limit ? out.slice(0, limit) : out;
  };
  D.hl = function (text, q) {
    var m = D.matcher(q), n = D.norm(text), mask = [], i, k, x, h, out = '', open = false;
    if (!m.n || n.length !== text.length) return esc(text);
    for (i = 0; i < text.length; i++) mask[i] = false;
    m.res.forEach(function (re) {
      re.lastIndex = 0;
      while ((h = re.exec(n)) !== null) { for (k = h.index; k < h.index + h[0].length; k++) mask[k] = true; if (!h[0].length) re.lastIndex++; }
    });
    for (i = 0; i < text.length; i++) {
      x = mask[i];
      if (x && !open) { out += '<mark>'; open = true; } else if (!x && open) { out += '</mark>'; open = false; }
      out += esc(text.charAt(i));
    }
    return open ? out + '</mark>' : out;
  };

  /* ---------- Liste déroulante de suggestions (accessible) ---------- */
  D.combo = function (o) {
    var input = o.input, list = o.list, items = [], active = -1;
    function close() { list.hidden = true; input.setAttribute('aria-expanded', 'false'); input.removeAttribute('aria-activedescendant'); active = -1; }
    function row(it, i) {
      return '<li role="option" id="' + list.id + '-' + i + '" class="res' + (it.on ? ' on' : '') + (it.custom ? ' res-custom' : '') + '" data-i="' + i + '" aria-selected="false">' +
        '<span class="res-ic">' + D.icon(it.icon || 'plus') + '</span><span class="res-t"><b>' + it.html + '</b>' + (it.sub ? '<small>' + esc(it.sub) + '</small>' : '') + '</span>' +
        '<span class="res-act">' + D.icon(it.on ? 'check' : 'plus') + '</span></li>';
    }
    function render(keep) {
      var q = input.value.trim();
      if (!q) { close(); return; }
      items = o.search(q);
      if (!items.length) { close(); return; }
      var prev = keep ? active : -1;
      list.innerHTML = items.map(row).join('');
      list.hidden = false; input.setAttribute('aria-expanded', 'true');
      active = -1; if (prev > -1 && prev < items.length) setActive(prev);
    }
    function setActive(i) {
      var all = $$('.res', list);
      if (active > -1 && all[active]) all[active].setAttribute('aria-selected', 'false');
      active = i;
      if (all[i]) { all[i].setAttribute('aria-selected', 'true'); input.setAttribute('aria-activedescendant', all[i].id); all[i].scrollIntoView({ block: 'nearest' }); } else input.removeAttribute('aria-activedescendant');
    }
    function pick(i) {
      var it = items[i];
      if (!it) return;
      o.onPick(it, input.value.trim());
      if (o.keepOpen) render(true); else { input.value = ''; close(); if (o.onClear) o.onClear(); }
    }
    input.addEventListener('input', function () { render(false); if (o.onInput) o.onInput(input.value); });
    input.addEventListener('focus', function () { if (input.value.trim()) render(false); });
    input.addEventListener('keydown', function (e) {
      var open = !list.hidden, n = items.length;
      if (e.key === 'ArrowDown') { e.preventDefault(); if (!open) render(false); else setActive(active < n - 1 ? active + 1 : 0); }
      else if (e.key === 'ArrowUp') { if (open) { e.preventDefault(); setActive(active > 0 ? active - 1 : n - 1); } }
      else if (e.key === 'Enter') { if (open) { e.preventDefault(); pick(active > -1 ? active : 0); } }
      else if (e.key === 'Escape') { if (open) { e.preventDefault(); close(); } }
    });
    list.addEventListener('mousedown', function (e) { e.preventDefault(); });
    list.addEventListener('click', function (e) { var li = e.target.closest('.res'); if (li) pick(+li.getAttribute('data-i')); });
    document.addEventListener('click', function (e) { if (!e.target.isConnected) return; if (e.target !== input && !list.contains(e.target)) close(); });
    return { render: render, close: close };
  };
  function svcItems(q, limit) {
    var out = D.searchServices(q, limit).map(function (r) {
      var s = r.s, d = DOM_BY_ID[s.dom];
      return { id: s.id, html: D.hl(s[D.lang], q), sub: D.domName(d), icon: d.icon, on: basket.has(s.id) };
    });
    out.push({ id: 'custom', custom: true, html: esc(t('search.addCustom', { q: q })), sub: t('search.addCustomHint'), icon: 'plus', on: false, text: q });
    return out;
  }
  D.svcItems = svcItems;
  function pickService(it, q) {
    var added;
    if (it.custom) added = basket.addCustom(q); else added = basket.toggle(it.id);
    D.toast(t(added ? 'basket.added' : 'basket.removed', { n: basket.count() }), { label: t('basket.see'), fn: function () { D.go('#devis'); } });
  }

  /* ---------- Accueil : champ de recherche, illustrations ---------- */
  function initHeroSearch() {
    var input = $('#q-hero'), clr = $('#q-hero-clear');
    D.combo({ input: input, list: $('#hero-results'), search: function (q) { return svcItems(q, 8); }, onPick: pickService, keepOpen: true, onInput: function (v) { clr.hidden = !v; } });
    clr.addEventListener('click', function () { input.value = ''; clr.hidden = true; input.dispatchEvent(new Event('input')); input.focus(); });
  }
  function img(src, alt) { return '<img src="' + esc(src) + '" alt="' + esc(alt || '') + '" loading="lazy" decoding="async">'; }
  function renderHeroArt() {
    var el = $('#hero-art'), ids = ['network', 'cctv', 'web', 'power'], h = '';
    if (CFG.images.hero) { el.className = 'hero-art solo'; el.innerHTML = '<figure>' + img(CFG.images.hero, '') + '</figure>'; return; }
    el.className = 'hero-art';
    ids.forEach(function (id) { var d = DOM_BY_ID[id]; if (d) h += '<figure data-dom="' + id + '">' + ART.scene(id) + '<figcaption>' + esc(D.domName(d)) + '</figcaption></figure>'; });
    el.innerHTML = h;
  }
  function renderCounts() {
    var n = { domains: CAT.domains.length, services: SVC.length };
    $$('[data-count]').forEach(function (el) { el.textContent = n[el.getAttribute('data-count')]; });
  }

  /* ---------- Index des domaines ---------- */
  var indexObs;
  function renderIndex() {
    var ul = $('#domain-index');
    ul.innerHTML = CAT.domains.map(function (d, i) {
      var n = d.services.length;
      return '<li style="--i:' + i + '"><a class="ix" href="#svc-' + d.id + '" data-dom="' + d.id + '"><span class="ix-name"><span>' + esc(D.domName(d)) + '</span></span><span class="ix-lead" aria-hidden="true"></span><span class="ix-n" aria-hidden="true">' + n + '</span><span class="sr-only">' + esc(D.tn('svc.nServices', n)) + '</span></a></li>';
    }).join('');
    if (!ul.hasAttribute('data-seen')) {
      ul.setAttribute('data-seen', '1');
      if ('IntersectionObserver' in window && !(window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches)) {
        ul.classList.add('pre');
        indexObs = new IntersectionObserver(function (es) {
          if (es.some(function (e) { return e.isIntersecting; })) { ul.classList.remove('pre'); ul.classList.add('go'); indexObs.disconnect(); }
        }, { threshold: 0.12 });
        indexObs.observe(ul);
      }
    }
  }

  /* ---------- Services : liste par domaine ---------- */
  var filterQ = '';
  function chipHtml(s, q) {
    var txt = s[D.lang], on = basket.has(s.id);
    return '<button type="button" class="chip" data-sid="' + s.id + '" aria-pressed="' + on + '">' +
      '<span class="ci-off">' + D.icon('plus', { size: 17 }) + '</span><span class="ci-on">' + D.icon('check', { size: 17 }) + '</span><span class="chip-t">' + (q ? D.hl(txt, q) : esc(txt)) + '</span></button>';
  }
  function domArt(d) {
    var p = CFG.images.domains[d.id];
    return p ? img(p, D.domName(d)) : ART.scene(d.id);
  }
  function fillPanel(det) {
    var panel = $('.dom-panel', det);
    if (!panel || panel.getAttribute('data-ok') === D.lang) return;
    var d = DOM_BY_ID[det.getAttribute('data-dom')];
    panel.setAttribute('data-ok', D.lang);
    panel.innerHTML = '<div class="dom-side"><div class="dom-art">' + domArt(d) + '</div><p class="dom-desc">' + esc(d[D.lang].desc) + '</p>' +
      '<div class="dom-actions"><button type="button" class="btn btn-ghost btn-sm" data-all="' + d.id + '">' + D.icon('check') + '<span>' + esc(t('svc.selectAll')) + '</span></button></div></div>' +
      '<div class="chips" role="group" aria-label="' + esc(D.domName(d)) + '">' + d.services.map(function (_, i) { return chipHtml(SVC_BY_ID[d.id + ':' + i], filterQ); }).join('') + '</div>';
    if (filterQ) applyFilterToPanel(det);
  }
  function renderServices() {
    var list = $('#svc-list'), open = {};
    $$('.dom[open]', list).forEach(function (d) { open[d.getAttribute('data-dom')] = true; });
    list.innerHTML = CAT.domains.map(function (d) {
      return '<details class="dom" id="svc-' + d.id + '" data-dom="' + d.id + '"' + (open[d.id] ? ' open' : '') + '><summary><span class="dom-ic">' + D.icon(d.icon) + '</span>' +
        '<span class="dom-name">' + esc(D.domName(d)) + '</span><span class="dom-meta"><span class="dom-sel" hidden></span><span>' + esc(D.tn('svc.nServices', d.services.length)) + '</span></span>' +
        '<span class="dom-chev">' + D.icon('chevronDown') + '</span></summary><div class="dom-panel"></div></details>';
    }).join('');
    $$('.dom[open]', list).forEach(fillPanel);
    syncBasketUI();
    if (filterQ) applyFilter(filterQ);
  }
  /* openDomain(id, true) : va dans l’onglet Services et ouvre le domaine ; openDomain(id) : l’ouvre seulement (appelé par la navigation) */
  function openDomain(id, nav) {
    if (nav && D.go) { D.go('#svc-' + id); return; }
    var det = $('#svc-' + id);
    if (!det) return;
    if (filterQ) { var q = $('#q-services'), clr = $('#q-services-clear'); q.value = ''; clr.hidden = true; applyFilter(''); }
    det.hidden = false; det.open = true; fillPanel(det);
  }
  D.openDomain = openDomain;

  function applyFilterToPanel(det) {
    var d = DOM_BY_ID[det.getAttribute('data-dom')], m = D.matcher(filterQ), domMatch = m.all(DOMHAY[d.id]), n = 0;
    $$('.chip', det).forEach(function (c) {
      var s = SVC_BY_ID[c.getAttribute('data-sid')], hit = m.all(s.hay), show = hit || domMatch;
      c.classList.toggle('is-hidden', !show);
      if (show) { n++; $('.chip-t', c).innerHTML = hit ? D.hl(s[D.lang], filterQ) : esc(s[D.lang]); }
    });
    return n;
  }
  function applyFilter(q) {
    filterQ = q;
    var list = $('#svc-list'), m = D.matcher(q), shown = 0, doms = 0, empty = $('#svc-empty'), line = $('#svc-count');
    if (!m.n) {
      $$('.dom', list).forEach(function (det) { det.hidden = false; $$('.chip', det).forEach(function (c) { c.classList.remove('is-hidden'); var s = SVC_BY_ID[c.getAttribute('data-sid')]; $('.chip-t', c).textContent = s[D.lang]; }); });
      empty.hidden = true; updateCountLine(); return;
    }
    $$('.dom', list).forEach(function (det) {
      var d = DOM_BY_ID[det.getAttribute('data-dom')], domMatch = m.all(DOMHAY[d.id]);
      var any = d.services.some(function (_, i) { return m.all(SVC_BY_ID[d.id + ':' + i].hay); });
      if (!any && !domMatch) { det.hidden = true; return; }
      det.hidden = false; det.open = true; fillPanel(det);
      var n = applyFilterToPanel(det); shown += n; doms++;
    });
    empty.hidden = shown > 0;
    if (!shown) { $('#svc-add-custom-t').textContent = t('search.addCustom', { q: q }); $('#svc-empty-art').innerHTML = ART.empty('search'); }
    line.textContent = shown ? t('svc.found', { s: D.tn('svc.nServices', shown), d: D.tn('svc.nDomains', doms) }) : '';
  }
  function updateCountLine() {
    var line = $('#svc-count');
    if (filterQ) return;
    var n = basket.count(), s = t('svc.count', { d: CAT.domains.length, s: SVC.length });
    line.textContent = n ? s + ' ' + D.tn('svc.inList', n) : s;
  }
  function syncAllButtons() {
    $$('[data-all]').forEach(function (b) {
      var vis = $$('.chip:not(.is-hidden)', b.closest('.dom-panel')).map(function (x) { return x.getAttribute('data-sid'); });
      var allOn = vis.length > 0 && vis.every(function (id) { return basket.has(id); });
      $('span', b).textContent = t(allOn ? 'svc.unselectAll' : 'svc.selectAll');
    });
  }
  function syncBasketUI() {
    $$('.chip[data-sid]').forEach(function (c) { c.setAttribute('aria-pressed', String(basket.has(c.getAttribute('data-sid')))); });
    var per = {};
    basket.items.forEach(function (it) { var s = SVC_BY_ID[it.id]; if (s) per[s.dom] = (per[s.dom] || 0) + 1; });
    $$('.dom').forEach(function (det) {
      var b = $('.dom-sel', det), n = per[det.getAttribute('data-dom')] || 0;
      if (b) { b.hidden = !n; b.textContent = n; b.setAttribute('title', D.tn('svc.inList', n)); }
    });
    syncAllButtons();
    updateCountLine();
    var fab = $('#fab-quote'), n = basket.count();
    if (fab) { fab.hidden = !n; $('#fab-quote-n').textContent = n; $('#fab-quote-t').textContent = t('fab.quote'); }
  }

  function initServices() {
    var list = $('#svc-list'), q = $('#q-services'), clr = $('#q-services-clear'), tg = $('#svc-toggle'), timer;
    list.addEventListener('toggle', function (e) { if (e.target.open) fillPanel(e.target); }, true);
    list.addEventListener('click', function (e) {
      var c = e.target.closest('.chip[data-sid]'), all = e.target.closest('[data-all]');
      if (c) { basket.toggle(c.getAttribute('data-sid')); return; }
      if (all) {
        var vis = $$('.chip:not(.is-hidden)', all.closest('.dom-panel')).map(function (x) { return x.getAttribute('data-sid'); });
        var allOn = vis.every(function (id) { return basket.has(id); });
        vis.forEach(function (id) { if (allOn) basket.items = basket.items.filter(function (i) { return i.id !== id; }); else if (!basket.has(id)) basket.items.push({ id: id }); });
        fire(); syncAllButtons();
      }
    });
    q.addEventListener('input', function () { clr.hidden = !q.value; clearTimeout(timer); timer = setTimeout(function () { applyFilter(q.value.trim()); }, 120); });
    clr.addEventListener('click', function () { q.value = ''; clr.hidden = true; applyFilter(''); q.focus(); });
    q.addEventListener('keydown', function (e) { if (e.key === 'Enter') { e.preventDefault(); applyFilter(q.value.trim()); } });
    tg.addEventListener('click', function () {
      var on = tg.getAttribute('aria-pressed') !== 'true';
      tg.setAttribute('aria-pressed', String(on));
      $('#svc-toggle-t').textContent = t(on ? 'svc.collapseAll' : 'svc.expandAll');
      $$('.dom', list).forEach(function (det) { if (!det.hidden) { det.open = on; if (on) fillPanel(det); } });
    });
    $('#svc-add-custom').addEventListener('click', function () {
      if (basket.addCustom(q.value)) D.toast(t('basket.added', { n: basket.count() }), { label: t('basket.see'), fn: function () { D.go('#devis'); } });
      else D.toast(t('basket.exists'));
    });
    $('#domain-index').addEventListener('click', function (e) {
      var a = e.target.closest('a.ix');
      if (!a) return;
      e.preventDefault();
      openDomain(a.getAttribute('data-dom'), true);
    });
    D.on('basket', syncBasketUI);
  }

  D.initHome = function () {
    basket.load();
    renderCounts(); initHeroSearch(); initServices();
    renderHeroArt(); renderIndex(); renderServices();
    D.on('lang', function () { renderHeroArt(); renderIndex(); renderServices(); });
  };
})();
/* ==========================================================================
   Dav Intertenement : secteurs, méthode, FAQ, réalisations, avis, contacts
   ========================================================================== */
(function () {
  'use strict';
  var D = window.DAV, $ = D.$, $$ = D.$$, esc = D.esc, CAT = D.cat, CFG = D.cfg, ART = D.art;
  function t(k, v) { return D.t(k, v); }
  function safeUrl(u) { return /^https?:\/\//i.test(String(u || '').trim()) ? String(u).trim() : ''; }
  function chip(id, text) {
    return '<button type="button" class="chip" data-sid="' + id + '" aria-pressed="' + D.basket.has(id) + '"><span class="ci-off">' + D.icon('plus', { size: 17 }) + '</span><span class="ci-on">' + D.icon('check', { size: 17 }) + '</span><span class="chip-t">' + esc(text) + '</span></button>';
  }

  /* ---------- Secteurs ---------- */
  var curSector = CAT.sectors.length ? CAT.sectors[0].id : '';
  function renderSectors() {
    var tabs = $('#sector-tabs');
    tabs.innerHTML = CAT.sectors.map(function (s) {
      var on = s.id === curSector;
      return '<button type="button" role="tab" class="tab" id="stab-' + s.id + '" data-sec="' + s.id + '" aria-selected="' + on + '" aria-controls="sector-panel" tabindex="' + (on ? 0 : -1) + '">' + D.icon(s.icon) + '<span>' + esc(s[D.lang].name) + '</span></button>';
    }).join('');
    renderSectorPanel();
  }
  function renderSectorPanel() {
    var s = D.SEC_BY_ID[curSector], p = $('#sector-panel');
    if (!s) return;
    p.setAttribute('aria-labelledby', 'stab-' + s.id);
    var needs = s[D.lang].needs.map(function (n, i) { return chip('need:' + s.id + ':' + i, n); }).join('');
    var doms = s.domains.map(function (id) {
      var d = D.DOM_BY_ID[id];
      return d ? '<a class="dlink" href="#svc-' + id + '" data-dom="' + id + '">' + D.icon(d.icon) + '<span>' + esc(D.domName(d)) + '</span></a>' : '';
    }).join('');
    p.innerHTML = '<div><h3>' + esc(s[D.lang].name) + '</h3><p class="sp-desc">' + esc(s[D.lang].desc) + '</p></div>' +
      '<div class="sp-cols"><div class="sp-block"><h4>' + esc(t('sec.needs')) + '</h4><div class="chips" role="group" aria-label="' + esc(t('sec.needs')) + '">' + needs + '</div></div>' +
      '<div class="sp-block"><h4>' + esc(t('sec.domains')) + '</h4><div class="dlinks">' + doms + '</div></div></div>' +
      '<div><button type="button" class="btn btn-primary" data-quote-sector="' + s.id + '">' + D.icon('send') + '<span>' + esc(t('sec.cta')) + '</span></button></div>';
  }
  function selectSector(id, focus) {
    curSector = id;
    $$('#sector-tabs .tab').forEach(function (b) {
      var on = b.getAttribute('data-sec') === id;
      b.setAttribute('aria-selected', String(on)); b.tabIndex = on ? 0 : -1;
      if (on && focus) b.focus();
    });
    renderSectorPanel();
  }
  function initSectors() {
    var tabs = $('#sector-tabs'), panel = $('#sector-panel');
    tabs.addEventListener('click', function (e) { var b = e.target.closest('.tab'); if (b) selectSector(b.getAttribute('data-sec'), false); });
    tabs.addEventListener('keydown', function (e) {
      var ids = CAT.sectors.map(function (s) { return s.id; }), i = ids.indexOf(curSector), n = ids.length, k = e.key, j = -1;
      if (k === 'ArrowRight' || k === 'ArrowDown') j = (i + 1) % n;
      else if (k === 'ArrowLeft' || k === 'ArrowUp') j = (i - 1 + n) % n;
      else if (k === 'Home') j = 0; else if (k === 'End') j = n - 1;
      if (j > -1) { e.preventDefault(); selectSector(ids[j], true); }
    });
    panel.addEventListener('click', function (e) {
      var c = e.target.closest('.chip[data-sid]'), a = e.target.closest('a.dlink'), q = e.target.closest('[data-quote-sector]');
      if (c) { D.basket.toggle(c.getAttribute('data-sid')); return; }
      if (a) { e.preventDefault(); D.openDomain(a.getAttribute('data-dom'), true); return; }
      if (q) { if (D.setQuoteSector) D.setQuoteSector(q.getAttribute('data-quote-sector')); D.go('#devis'); }
    });
    renderSectors();
    D.on('lang', renderSectors);
  }

  /* ---------- Accueil : les six piliers du secteur ---------- */
  function renderPillars() {
    var box = $('#pillars');
    if (!box) return;
    box.innerHTML = (CAT.pillars || []).map(function (p) {
      var s = 0;
      p.domains.forEach(function (id) { var d = D.DOM_BY_ID[id]; if (d) s += d.services.length; });
      return '<article class="pillar"><span class="pillar-ic" aria-hidden="true">' + D.icon(p.icon) + '</span><h3>' + esc(p[D.lang].title) + '</h3><p>' + esc(p[D.lang].text) + '</p>' +
        '<p class="pillar-meta">' + esc(t('pillar.meta', { d: p.domains.length, s: s })) + '</p></article>';
    }).join('');
  }

  /* ---------- Méthode, pourquoi nous, FAQ ---------- */
  function renderHow() {
    $('#how-list').innerHTML = CAT.process.map(function (p, i) {
      return '<li><span class="num" aria-hidden="true">' + (i + 1) + '</span><h3 class="step-t">' + esc(p[D.lang].title) + '</h3><p class="step-p">' + esc(p[D.lang].text) + '</p></li>';
    }).join('');
    $('#why-grid').innerHTML = CAT.why.map(function (w) {
      return '<div class="why"><span class="why-ic">' + D.icon(w.icon) + '</span><h4>' + esc(w[D.lang].title) + '</h4><p>' + esc(w[D.lang].text) + '</p></div>';
    }).join('');
  }
  function renderFaq() {
    var box = $('#faq-list'), open = $$('details[open]', box).map(function (d) { return d.getAttribute('data-i'); });
    box.innerHTML = CAT.faq.map(function (f, i) {
      return '<details data-i="' + i + '"' + (open.indexOf(String(i)) > -1 ? ' open' : '') + '><summary>' + esc(f[D.lang].q) + '</summary><p>' + esc(f[D.lang].a) + '</p></details>';
    }).join('');
  }

  /* ---------- Réalisations (config.js) ---------- */
  function renderProjects() {
    var sec = $('#realisations'), list = CFG.projects || [];
    sec.hidden = !list.length;
    if (!list.length) return;
    $('#proj-grid').innerHTML = list.map(function (p) {
      var d = D.DOM_BY_ID[p.domain], im = p.image ? '<img src="' + esc(p.image) + '" alt="" loading="lazy" decoding="async">' : (d ? ART.scene(d.id) : '');
      var meta = [d ? D.domName(d) : '', p.year || ''].filter(Boolean).join(', '), link = safeUrl(p.link);
      return '<article class="proj">' + (im ? '<div class="proj-img">' + im + '</div>' : '') + '<div class="proj-body"><h3>' + esc(D.pick(p.title)) + '</h3>' +
        (meta ? '<p class="proj-meta">' + esc(meta) + '</p>' : '') + '<p>' + esc(D.pick(p.text)) + '</p>' +
        (link ? '<p><a class="link" href="' + esc(link) + '" target="_blank" rel="noopener">' + esc(t('proj.visit')) + '</a></p>' : '') + '</div></article>';
    }).join('');
  }

  /* ---------- Avis : témoignages (config.js) et avis publiés (base de données) ---------- */
  D.reviews = [];
  function stars(n) {
    var h = '';
    for (var i = 1; i <= 5; i++) h += '<span class="' + (i <= n ? '' : 'off') + '">' + D.icon('starFill', { size: 18 }) + '</span>';
    return '<span class="stars" role="img" aria-label="' + esc(t('rev.stars', { n: n })) + '">' + h + '</span>';
  }
  D.renderReviews = function () {
    var sec = $('#avis'), cards = [];
    (CFG.testimonials || []).forEach(function (x) {
      cards.push('<figure class="qcard"><blockquote>' + esc(D.pick(x.text)) + '</blockquote><figcaption><b>' + esc(x.name) + '</b>' + (x.role ? '<span>' + esc(x.role) + '</span>' : '') + '</figcaption></figure>');
    });
    (D.reviews || []).forEach(function (r) {
      cards.push('<figure class="qcard">' + stars(+r.rating || 5) + '<blockquote>' + esc(r.body) + '</blockquote><figcaption><b>' + esc(r.author_name || t('rev.anon')) + '</b></figcaption></figure>');
    });
    sec.hidden = !cards.length;
    $('#rev-grid').innerHTML = cards.join('');
    $('#rev-cta').hidden = !(cards.length && D.accountEnabled && D.accountEnabled());
  };

  /* ---------- Contacts, pied de page, réseaux sociaux ---------- */
  function primaryPhone() {
    var n = D.waNumber(), ph = (CFG.contact.phones || []).filter(function (p) { return D.waNumber(p.wa) === n; })[0];
    return ph ? ph.display : (n ? '+' + n : '');
  }
  function renderContacts() {
    var c = CFG.contact, h = '', addr = D.pick(c.address).trim(), hours = D.pick(c.hours).trim(), n = D.waNumber();
    if (n) h += '<li class="c-item"><a class="c-main" href="' + esc(D.waLink(t('wa.hello'))) + '" target="_blank" rel="noopener"><span class="c-ic wa">' + D.icon('whatsapp') + '</span><span class="c-txt"><b>WhatsApp</b><small>' + esc(t('contact.waSub', { p: primaryPhone() })) + '</small></span></a></li>';
    (c.phones || []).forEach(function (p) {
      h += '<li class="c-item"><a class="c-main" href="tel:' + esc(p.tel) + '"><span class="c-ic">' + D.icon('phone') + '</span><span class="c-txt"><b>' + esc(p.display) + '</b><small>' + esc(t('contact.call')) + '</small></span></a>' +
        (p.wa ? '<a class="c-wa" href="' + esc(D.waLink('', p.wa)) + '" target="_blank" rel="noopener" aria-label="WhatsApp ' + esc(p.display) + '">' + D.icon('whatsapp') + '</a>' : '') + '</li>';
    });
    if (c.email) h += '<li class="c-item"><a class="c-main" href="mailto:' + esc(c.email) + '"><span class="c-ic">' + D.icon('mail') + '</span><span class="c-txt"><b class="c-mail">' + esc(c.email) + '</b><small>' + esc(t('contact.mail')) + '</small></span></a></li>';
    if (addr) h += '<li class="c-item"><a class="c-main" href="https://www.google.com/maps/search/?api=1&amp;query=' + encodeURIComponent(addr) + '" target="_blank" rel="noopener"><span class="c-ic">' + D.icon('pin') + '</span><span class="c-txt"><b>' + esc(addr) + '</b><small>' + esc(t('contact.map')) + '</small></span></a></li>';
    if (hours) h += '<li class="c-item"><div class="c-main"><span class="c-ic">' + D.icon('clock') + '</span><span class="c-txt"><b>' + esc(hours) + '</b><small>' + esc(t('contact.hours')) + '</small></span></div></li>';
    $('#contact-list').innerHTML = h;

    var f = '';
    (c.phones || []).forEach(function (p) { f += '<a href="tel:' + esc(p.tel) + '">' + D.icon('phone') + '<span>' + esc(p.display) + '</span></a>'; });
    if (c.email) f += '<a href="mailto:' + esc(c.email) + '">' + D.icon('mail') + '<span>' + esc(c.email) + '</span></a>';
    if (addr) f += '<a href="#contact">' + D.icon('pin') + '<span>' + esc(addr) + '</span></a>';
    $('#ftr-contact').innerHTML = f;

    var names = { facebook: 'Facebook', instagram: 'Instagram', linkedin: 'LinkedIn', tiktok: 'TikTok', youtube: 'YouTube', x: 'X' }, s = '';
    Object.keys(names).forEach(function (k) { var u = safeUrl(CFG.social[k]); if (u) s += '<a href="' + esc(u) + '" target="_blank" rel="noopener" aria-label="' + names[k] + '">' + D.icon(k) + '</a>'; });
    $('#socials').innerHTML = s;
    $('#socials').hidden = !s;
    var fs = $('#ftr-socials');
    if (fs) { fs.innerHTML = s; fs.hidden = !s; }
  }
  function hydrateWa() {
    $$('[data-wa]').forEach(function (a) {
      var m = a.getAttribute('data-wa-msg') || 'hello';
      a.setAttribute('href', D.waLink(t('wa.' + m)));
    });
  }
  function jsonLd() {
    var c = CFG.contact, o = { '@context': 'https://schema.org', '@type': 'ProfessionalService', name: CFG.brand.name, description: t('meta.desc'), areaServed: CFG.brand.city,
      address: { '@type': 'PostalAddress', addressLocality: CFG.brand.city, addressCountry: 'CD' } }, same = [];
    if (c.email) o.email = c.email;
    if ((c.phones || [])[0]) o.telephone = c.phones[0].tel;
    if (safeUrl(CFG.siteUrl)) {
      var base = safeUrl(CFG.siteUrl).replace(/\/+$/, '');
      o.url = base + '/'; o.image = base + '/og.jpg';
      if (CFG.brand.logo && !/^https?:/i.test(CFG.brand.logo)) o.logo = base + '/' + CFG.brand.logo.replace(/^\/+/, '');
    }
    if (D.pick(c.address).trim()) o.address.streetAddress = D.pick(c.address).trim();
    Object.keys(CFG.social).forEach(function (k) { if (safeUrl(CFG.social[k])) same.push(CFG.social[k]); });
    if (same.length) o.sameAs = same;
    var s = $('#ld-json');
    if (!s) { s = document.createElement('script'); s.type = 'application/ld+json'; s.id = 'ld-json'; document.head.appendChild(s); }
    s.textContent = JSON.stringify(o);
  }

  D.initContent = function () {
    initSectors(); renderPillars(); renderHow(); renderFaq(); renderProjects(); D.renderReviews(); renderContacts(); hydrateWa(); jsonLd();
    D.on('lang', function () { renderPillars(); renderHow(); renderFaq(); renderProjects(); D.renderReviews(); renderContacts(); hydrateWa(); jsonLd(); });
  };
})();
/* ==========================================================================
   Dav Intertenement : boutique, panier, commande
   ========================================================================== */
(function () {
  'use strict';
  var D = window.DAV, $ = D.$, $$ = D.$$, esc = D.esc, CAT = D.cat, CFG = D.cfg, ART = D.art;
  function t(k, v) { return D.t(k, v); }
  var P = CAT.products, CATS = CAT.productCats, PROD = {}, CATBY = {};
  /* Les prix sont facultatifs : tant qu'aucun produit n'en a, le site n'affiche ni prix, ni total, ni tri par prix. */
  var anyPrice = P.some(function (p) { return p.price != null; });
  P.forEach(function (p) { PROD[p.id] = p; });
  CATS.forEach(function (c) { CATBY[c.id] = c; });

  /* ---------- Panier ---------- */
  var KEY = 'dav-cart';
  var cart = D.cart = { lines: {} };
  cart.load = function () {
    var o = D.store.get(KEY, {}), out = {};
    if (o && typeof o === 'object') Object.keys(o).forEach(function (id) { var q = Math.floor(+o[id]); if (PROD[id] && q > 0) out[id] = Math.min(q, 99); });
    cart.lines = out;
  };
  function fire() { D.store.set(KEY, cart.lines); D.emit('cart'); }
  cart.qty = function (id) { return cart.lines[id] || 0; };
  cart.set = function (id, q) { q = Math.max(0, Math.min(99, q)); if (q) cart.lines[id] = q; else delete cart.lines[id]; fire(); };
  cart.clear = function () { cart.lines = {}; fire(); };
  cart.count = function () { return Object.keys(cart.lines).reduce(function (n, id) { return n + cart.lines[id]; }, 0); };
  cart.totals = function () {
    var sum = 0, ask = 0;
    Object.keys(cart.lines).forEach(function (id) { var p = PROD[id], q = cart.lines[id]; if (p.price == null) ask += q; else sum += p.price * q; });
    return { sum: sum, ask: ask };
  };

  /* ---------- Boutique ---------- */
  var state = { cat: 'all', q: '', sort: 'default' };
  function name(p) { return p[D.lang].name; }
  function prodArt(p) { var u = CFG.images.products[p.id]; return u ? '<img src="' + esc(u) + '" alt="" loading="lazy" decoding="async">' : ART.product(p.art); }
  function renderCats() {
    var all = [{ id: 'all' }].concat(CATS);
    $('#shop-cats').innerHTML = all.map(function (c) {
      return '<button type="button" class="chip" data-cat="' + c.id + '" aria-pressed="' + (state.cat === c.id) + '"><span class="chip-t">' + esc(c.id === 'all' ? t('shop.all') : c[D.lang]) + '</span></button>';
    }).join('');
  }
  function filtered() {
    var m = D.matcher(state.q);
    var list = P.filter(function (p) {
      if (state.cat !== 'all' && p.cat !== state.cat) return false;
      if (!m.n) return true;
      var c = CATBY[p.cat];
      return m.all(D.norm(p.fr.name + ' ' + p.en.name + ' ' + p.fr.spec + ' ' + p.en.spec + ' ' + c.fr + ' ' + c.en));
    });
    if (state.sort !== 'default') {
      list = list.slice().sort(function (a, b) {
        var pa = a.price == null ? (state.sort === 'asc' ? Infinity : -1) : a.price, pb = b.price == null ? (state.sort === 'asc' ? Infinity : -1) : b.price;
        if (pa === pb) return 0;
        return state.sort === 'asc' ? (pa < pb ? -1 : 1) : (pa > pb ? -1 : 1);
      });
    }
    return list;
  }
  function actHtml(p) {
    var q = cart.qty(p.id);
    if (!q) return '<button type="button" class="btn btn-primary btn-sm" data-add="' + p.id + '" aria-label="' + esc(t('shop.addAria', { name: name(p) })) + '">' + D.icon('cart') + '<span>' + esc(t(p.price == null ? 'shop.askAdd' : 'shop.add')) + '</span></button>';
    return '<div class="stepper" role="group" aria-label="' + esc(t('shop.qtyOf', { name: name(p) })) + '"><button type="button" data-dec="' + p.id + '" aria-label="' + esc(t('shop.less')) + '">' + D.icon('minus') + '</button><output>' + q + '</output><button type="button" data-inc="' + p.id + '" aria-label="' + esc(t('shop.more')) + '">' + D.icon('plus') + '</button></div>';
  }
  function priceHtml(p) {
    if (p.price == null) return anyPrice ? '<p class="price ask">' + esc(t('shop.ask')) + '</p>' : '';
    var c = D.cdf(p.price);
    return '<p class="price">' + esc(D.money(p.price)) + '</p>' + (c ? '<p class="hint">' + esc(c) + '</p>' : '');
  }
  function card(p) {
    return '<article class="prod" data-pid="' + p.id + '"><div class="prod-art">' + prodArt(p) + '</div><div class="prod-body"><p class="prod-cat">' + esc(CATBY[p.cat][D.lang]) + '</p>' +
      '<h3 class="prod-name">' + esc(name(p)) + '</h3><p class="prod-spec">' + esc(p[D.lang].spec) + '</p><div class="prod-foot">' + priceHtml(p) + '<div class="prod-act">' + actHtml(p) + '</div></div></div></article>';
  }
  function renderGrid() {
    var list = filtered(), grid = $('#shop-grid'), empty = $('#shop-empty');
    grid.innerHTML = list.map(card).join('');
    empty.hidden = list.length > 0;
    if (!list.length) $('#shop-empty-art').innerHTML = ART.empty('search');
    $('#shop-count').textContent = list.length ? D.tn('shop.count', list.length) : '';
  }
  function refreshActs() {
    $$('.prod').forEach(function (el) { var p = PROD[el.getAttribute('data-pid')]; $('.prod-act', el).innerHTML = actHtml(p); });
  }
  function note() {
    var n = D.pick(CFG.shop.deliveryNote).trim(), el = $('#shop-note');
    el.textContent = n; el.hidden = !n;
  }

  /* ---------- Fenêtre du panier ---------- */
  function renderCart() {
    var ids = Object.keys(cart.lines), none = !ids.length;
    $('#cart-empty').hidden = !none || !$('#cart-done').hidden; $('#cart-filled').hidden = none;
    if (none) { $('#cart-empty-art').innerHTML = ART.empty('cart'); return; }
    $('#cart-lines').innerHTML = ids.map(function (id) {
      var p = PROD[id], q = cart.lines[id];
      return '<li class="cl" data-pid="' + id + '"><div class="cl-art">' + prodArt(p) + '</div><div class="cl-main"><div class="cl-head"><p class="cl-name">' + esc(name(p)) + '</p>' +
        '<button type="button" class="cl-del" data-del="' + id + '" aria-label="' + esc(t('cart.remove', { name: name(p) })) + '">' + D.icon('trash') + '</button></div>' +
        (p.price != null ? '<p class="cl-unit">' + esc(D.money(p.price)) + ' ' + esc(t('cart.each')) + '</p>' : '') +
        '<div class="cl-row"><div class="stepper" role="group" aria-label="' + esc(t('shop.qtyOf', { name: name(p) })) + '"><button type="button" data-dec="' + id + '" aria-label="' + esc(t('shop.less')) + '">' + D.icon('minus') + '</button><output>' + q + '</output><button type="button" data-inc="' + id + '" aria-label="' + esc(t('shop.more')) + '">' + D.icon('plus') + '</button></div>' +
        (p.price != null ? '<span class="cl-price">' + esc(D.money(p.price * q)) + '</span>' : anyPrice ? '<span class="cl-price ask">' + esc(t('shop.ask')) + '</span>' : '') + '</div></div></li>';
    }).join('');
    /* Pas de prix dans le panier : on n'affiche aucun total (le prix est donné en discutant avec le client). */
    var tt = cart.totals(), box = $('#cart-total'), sub = $('#cart-sub'), od = $('#cart-ondemand');
    box.hidden = !(tt.sum > 0);
    sub.innerHTML = tt.sum > 0 ? esc(D.money(tt.sum)) + (D.cdf(tt.sum) ? '<small>' + esc(D.cdf(tt.sum)) + '</small>' : '') : '';
    od.hidden = !(tt.ask && tt.sum > 0);
    if (!od.hidden) od.textContent = D.tn('cart.onDemand', tt.ask);
  }
  function updateBadge() {
    var n = cart.count(), b = $('#cart-count');
    b.hidden = !n; b.textContent = n;
  }
  function openCart() {
    $('#cart-done').hidden = true;
    renderCart();
    D.openDialog($('#dlg-cart'));
  }
  D.openCart = openCart;

  /* ---------- Commande ---------- */
  function shipFields() {
    var ship = $('#o-del-ship').checked;
    $('#o-ship-wrap').hidden = !ship;
    var n = D.pick(CFG.shop.deliveryNote).trim();
    $('#o-ship-note').textContent = n || t('cart.shipHint');
  }
  function fillCommunes() {
    var s = $('#o-commune'), cur = s.value;
    s.innerHTML = '<option value="">' + esc(t('cart.chooseCommune')) + '</option>' + D.COMMUNES.map(function (c) { return '<option value="' + esc(c) + '">' + esc(c) + '</option>'; }).join('') + '<option value="other">' + esc(t('cart.otherCity')) + '</option>';
    s.value = cur;
    var dl = $('#communes');
    if (dl) dl.innerHTML = D.COMMUNES.map(function (c) { return '<option value="' + esc(c) + '">'; }).join('');
  }
  function payLabel(v) { return t({ mobile_money: 'cart.payMomo', cash: 'cart.payCash', bank: 'cart.payBank', discuss: 'cart.payTalk' }[v] || 'cart.payTalk'); }
  function orderText(data, ref) {
    var L = [], tt = cart.totals();
    L.push(t('msg.order.title', { ref: ref }), t('msg.order.intro'));
    Object.keys(cart.lines).forEach(function (id) {
      var p = PROD[id]; L.push('- ' + cart.lines[id] + ' × ' + name(p) + (p.price == null ? '' : ' (' + D.money(p.price) + ')'));
    });
    if (tt.sum > 0) L.push(t('msg.order.total', { t: D.money(tt.sum) }) + (tt.ask ? ' ' + D.tn('msg.order.more', tt.ask) : ''));
    else L.push(t('msg.order.askPrice'));
    L.push(t('msg.name') + ' : ' + data.full_name, t('msg.phone') + ' : ' + data.phone);
    if (data.email) L.push(t('msg.email') + ' : ' + data.email);
    var rec = data.delivery === 'delivery' ? t('cart.ship') + (data.commune ? ', ' + (data.commune === 'other' ? t('cart.otherCity') : data.commune) : '') + (data.address ? ', ' + data.address : '') : t('cart.pickup');
    L.push(t('msg.reception') + ' : ' + rec, t('msg.payment') + ' : ' + payLabel(data.payment));
    if (data.note) L.push(t('msg.note') + ' : ' + data.note);
    return L.join('\n');
  }
  function submitOrder(e) {
    e.preventDefault();
    var f = e.target, err = $('#o-error'), btn = $('#o-submit');
    D.clearErrors(f);
    if (f.website.value) return;
    var cc = f.phone_cc.value, phone = D.fullPhone(cc, f.phone.value), email = f.email.value.trim(), first = null;
    var data = { full_name: f.full_name.value.trim(), phone: phone, email: email, delivery: f.delivery.value, commune: f.commune.value, address: f.address.value.trim(), payment: f.payment.value, note: f.note.value.trim() };
    if (!data.full_name) first = D.fieldError(f.full_name, t('err.name'), first);
    if (!D.validPhone(phone)) first = D.fieldError(f.phone, t('err.phone'), first);
    if (email && !D.validEmail(email)) first = D.fieldError(f.email, t('err.email'), first);
    if (data.delivery === 'delivery' && !data.address) first = D.fieldError(f.address, t('err.address'), first);
    if (!Object.keys(cart.lines).length) { D.formError(err, t('err.cartEmpty')); return; }
    if (first) { first.focus(); return; }
    if (D.tooFast()) return;
    var id = D.newId(), ref = D.refOf(id), text = orderText(data, ref);
    function finish(viaDb) {
      D.showDone(f, 'cart-filled', 'cart-done', { title: t(viaDb ? 'done.orderTitle' : 'done.orderWaTitle'), ref: ref, text: t(viaDb ? 'done.orderText' : 'done.orderWaText'), wa: text, waLabel: viaDb ? 'done.wa' : 'done.waOpen', art: 'success', onAgain: renderCart });
      cart.clear();
      f.reset(); shipFields();
    }
    if (D.db.enabled) {
      D.busy(btn, true);
      var items = Object.keys(cart.lines).map(function (pid) { var p = PROD[pid]; return { id: pid, name_fr: p.fr.name, name_en: p.en.name, qty: cart.lines[pid], price: p.price }; });
      D.db.insert('orders', { id: id, ref: ref, items: items, total_usd: cart.totals().sum, full_name: data.full_name, phone: data.phone, email: data.email || null, delivery: data.delivery, commune: data.commune || null, address: data.address || null, payment: data.payment, note: data.note || null, lang: D.lang })
        .then(function () { finish(true); })
        .catch(function () { D.formError(err, t('err.send')); })
        .then(function () { D.busy(btn, false); });
    } else {
      D.openWa(text); finish(false);
    }
  }

  function initShop() {
    cart.load();
    renderCats(); renderGrid(); note(); updateBadge();
    var q = $('#q-shop'), clr = $('#q-shop-clear'), timer;
    $('#shop-cats').addEventListener('click', function (e) { var b = e.target.closest('[data-cat]'); if (!b) return; state.cat = b.getAttribute('data-cat'); renderCats(); renderGrid(); });
    q.addEventListener('input', function () { clr.hidden = !q.value; clearTimeout(timer); timer = setTimeout(function () { state.q = q.value.trim(); renderGrid(); }, 150); });
    clr.addEventListener('click', function () { q.value = ''; clr.hidden = true; state.q = ''; renderGrid(); q.focus(); });
    var sortBox = $('#shop-sort').closest('.select-wrap');
    if (sortBox) sortBox.hidden = !anyPrice; /* le tri par prix n'a de sens que si des prix existent */
    $('#shop-sort').addEventListener('change', function (e) { state.sort = e.target.value; renderGrid(); });
    function qtyClick(e) {
      var a = e.target.closest('[data-add],[data-inc],[data-dec],[data-del]');
      if (!a) return;
      var inDialog = !!a.closest('#dlg-cart');
      var id = a.getAttribute('data-add') || a.getAttribute('data-inc') || a.getAttribute('data-dec') || a.getAttribute('data-del');
      if (a.hasAttribute('data-add')) { cart.set(id, 1); D.toast(t('cart.added'), { label: t('cart.view'), fn: openCart }); }
      else if (a.hasAttribute('data-inc')) cart.set(id, cart.qty(id) + 1);
      else if (a.hasAttribute('data-dec')) cart.set(id, cart.qty(id) - 1);
      else cart.set(id, 0);
      var k = a.hasAttribute('data-inc') ? 'inc' : a.hasAttribute('data-dec') ? 'dec' : null;
      if (k) {
        var root = inDialog ? $('#cart-lines .cl[data-pid="' + id + '"]') : $('.prod[data-pid="' + id + '"] .prod-act'), nb = root && $('[data-' + k + '="' + id + '"]', root);
        if (nb) nb.focus();
      }
    }
    $('#shop-grid').addEventListener('click', qtyClick);
    $('#cart-lines').addEventListener('click', qtyClick);
    $('[data-act="cart"]').addEventListener('click', openCart);
    $('#cart-clear').addEventListener('click', function () { cart.clear(); });
    var form = $('#order-form');
    form.addEventListener('submit', submitOrder);
    D.watchErrors(form);
    $$('input[name="delivery"]', form).forEach(function (r) { r.addEventListener('change', shipFields); });
    D.on('cart', function () { updateBadge(); refreshActs(); if ($('#dlg-cart').open) renderCart(); });
    D.on('lang', function () { renderCats(); renderGrid(); note(); fillCommunes(); shipFields(); if ($('#dlg-cart').open) renderCart(); updateSubmitLabel(); });
    fillCommunes(); shipFields(); updateSubmitLabel();
  }
  function updateSubmitLabel() { $('#o-submit-t').textContent = t(D.db.enabled ? 'cart.submitDb' : 'cart.submitWa'); }

  D.initShop = initShop;
})();
/* ==========================================================================
   Dav Intertenement : formulaire de devis et formulaire de contact
   ========================================================================== */
(function () {
  'use strict';
  var D = window.DAV, $ = D.$, $$ = D.$$, esc = D.esc, CAT = D.cat, CFG = D.cfg;
  function t(k, v) { return D.t(k, v); }
  var basket = D.basket, files = [], MAX_FILES = 5, MAX_SIZE = 5 * 1048576, EXT = /\.(jpe?g|png|gif|webp|heic|pdf|docx?|xlsx?|pptx?|txt|csv)$/i;

  function sectorName(id) { var s = D.SEC_BY_ID[id]; return s ? s[D.lang].name : ''; }
  function fillSectors() {
    var s = $('#q-sector'), cur = s.value;
    s.innerHTML = '<option value="">' + esc(t('q.sectorPick')) + '</option>' + CAT.sectors.map(function (x) { return '<option value="' + x.id + '">' + esc(x[D.lang].name) + '</option>'; }).join('') + '<option value="other">' + esc(t('q.sectorOther')) + '</option>';
    s.value = cur;
  }
  D.setQuoteSector = function (id) { $('#q-sector').value = id; };

  /* ----- champs spéciaux ----- */
  function syncType() {
    var f = $('#quote-form'), v = f.client_type.value;
    $('#q-company-wrap').hidden = v === 'individual';
  }
  function syncBudget() {
    var r = $('#q-budget'), v = +r.value, txt = t('q.bud.' + v);
    r.style.setProperty('--pct', (v / 6 * 100) + '%');
    $('#q-budget-out').textContent = txt;
    r.setAttribute('aria-valuetext', txt);
  }
  function renderTags() {
    var ul = $('#q-tags');
    ul.innerHTML = basket.items.map(function (it) {
      var l = basket.label(it);
      return '<li class="tag"><span>' + esc(l) + '</span><button type="button" data-rm="' + esc(it.id) + '" aria-label="' + esc(t('q.remove', { name: l })) + '">' + D.icon('close') + '</button></li>';
    }).join('');
  }
  function initPicker() {
    var input = $('#q-svc-input');
    D.combo({
      input: input, list: $('#q-svc-results'), search: function (q) { return D.svcItems(q, 7); },
      onPick: function (it, q) { if (it.custom) basket.addCustom(q); else basket.toggle(it.id); }
    });
    $('#q-tags').addEventListener('click', function (e) {
      var b = e.target.closest('[data-rm]');
      if (b) { basket.remove(b.getAttribute('data-rm')); input.focus(); }
    });
    D.on('basket', renderTags);
    renderTags();
  }

  /* ----- pièces jointes ----- */
  function okType(f) { return EXT.test(f.name) || (f.type || '').indexOf('image/') === 0; }
  function renderFiles() {
    $('#q-files').innerHTML = files.map(function (f, i) {
      return '<li class="file">' + D.icon(/^image\//.test(f.type) ? 'image' : 'file') + '<span class="file-n">' + esc(f.name) + '</span><small>' + esc(D.fmtSize(f.size)) + '</small>' +
        '<button type="button" data-rmf="' + i + '" aria-label="' + esc(t('q.removeFile', { name: f.name })) + '">' + D.icon('close') + '</button></li>';
    }).join('');
  }
  function addFiles(list) {
    var msg = '';
    list.forEach(function (f) {
      if (files.length >= MAX_FILES) { msg = msg || t('err.tooMany'); return; }
      if (f.size > MAX_SIZE) { msg = msg || t('err.tooBig', { name: f.name }); return; }
      if (!okType(f)) { msg = msg || t('err.type', { name: f.name }); return; }
      if (files.some(function (x) { return x.name === f.name && x.size === f.size; })) return;
      files.push(f);
    });
    renderFiles();
    if (msg) D.toast(msg);
  }
  function initDrop() {
    var inp = $('#q-file'), drop = $('#q-drop');
    inp.addEventListener('change', function () { addFiles(Array.prototype.slice.call(inp.files)); inp.value = ''; });
    ['dragenter', 'dragover'].forEach(function (ev) { drop.addEventListener(ev, function (e) { e.preventDefault(); drop.classList.add('over'); }); });
    ['dragleave', 'drop'].forEach(function (ev) { drop.addEventListener(ev, function (e) { e.preventDefault(); drop.classList.remove('over'); }); });
    drop.addEventListener('drop', function (e) { if (e.dataTransfer) addFiles(Array.prototype.slice.call(e.dataTransfer.files)); });
    $('#q-files').addEventListener('click', function (e) { var b = e.target.closest('[data-rmf]'); if (b) { files.splice(+b.getAttribute('data-rmf'), 1); renderFiles(); } });
  }

  /* ----- envoi du devis ----- */
  function collect(f) {
    return {
      client_type: f.client_type.value, company: f.company.value.trim(), full_name: f.full_name.value.trim(), phone: D.fullPhone(f.phone_cc.value, f.phone.value),
      email: f.email.value.trim(), contact_pref: f.contact_pref.value, city: f.city.value.trim(), sector: f.sector.value, description: f.description.value.trim(),
      budget: 'b' + f.budget.value, urgency: f.urgency.value, start_date: f.start_date.value,
      options: { maintenance: f.opt_maintenance.checked, training: f.opt_training.checked, onsite: f.opt_onsite.checked, takeover: f.opt_takeover.checked },
      services: basket.items.map(function (it) { return basket.pair(it); })
    };
  }
  function validate(f, d) {
    var first = null, er = $('#q-error');
    if (!d.full_name) first = D.fieldError(f.full_name, t('err.name'), first);
    if (!D.validPhone(d.phone)) first = D.fieldError(f.phone, t('err.phone'), first);
    if (d.email && !D.validEmail(d.email)) first = D.fieldError(f.email, t('err.email'), first);
    if (!d.services.length && !d.description) { D.formError(er, t('err.needSomething')); first = first || $('#q-svc-input'); }
    if (first) { first.focus(); return false; }
    return true;
  }
  function quoteText(d, ref) {
    var L = [t('msg.quote.title', { ref: ref })], prefKey = { whatsapp: 'f.prefWa', call: 'f.prefCall', email: 'f.prefMail' }[d.contact_pref] || 'f.prefWa';
    L.push(t('msg.profile') + ' : ' + t('q.ct.' + d.client_type) + (d.company ? ' (' + d.company + ')' : ''));
    L.push(t('msg.name') + ' : ' + d.full_name, t('msg.phone') + ' : ' + d.phone);
    if (d.email) L.push(t('msg.email') + ' : ' + d.email);
    L.push(t('msg.pref') + ' : ' + t(prefKey));
    if (d.city) L.push(t('msg.city') + ' : ' + d.city);
    if (d.services.length) { L.push(t('msg.services') + ' :'); d.services.forEach(function (s) { L.push('- ' + (s[D.lang] || s.fr)); }); }
    if (d.sector) L.push(t('msg.sector') + ' : ' + (d.sector === 'other' ? t('q.sectorOther') : sectorName(d.sector)));
    if (d.description) L.push(t('msg.need') + ' : ' + d.description);
    L.push(t('msg.budget') + ' : ' + t('q.bud.' + d.budget.slice(1)), t('msg.urgency') + ' : ' + t('q.urg.' + d.urgency));
    if (d.start_date) L.push(t('msg.start') + ' : ' + D.longDate(d.start_date));
    var o = ['maintenance', 'training', 'onsite', 'takeover'].filter(function (k) { return d.options[k]; }).map(function (k) { return t('q.opt.' + k); });
    if (o.length) L.push(t('msg.options') + ' : ' + o.join(', '));
    if (files.length) L.push(t('msg.files') + ' : ' + files.map(function (x) { return x.name; }).join(', '));
    return L.join('\n');
  }
  function resetQuote() {
    var f = $('#quote-form');
    f.reset(); files = []; renderFiles(); syncBudget(); syncType(); $('#q-desc-n').textContent = '0'; D.clearErrors(f);
    if (D.prefillNow) D.prefillNow();
  }
  function sendQuote(channel) {
    var f = $('#quote-form'), btn = $('#q-submit'), er = $('#q-error');
    D.clearErrors(f);
    if (f.website.value) return;
    var d = collect(f);
    if (!validate(f, d)) return;
    if (D.tooFast()) return;
    var id = D.newId(), ref = D.refOf(id), text = quoteText(d, ref);
    if (channel === 'wa') {
      D.openWa(text);
      D.showDone(f, 'quote-body', 'quote-done', { title: t('done.waTitle'), ref: ref, text: t('done.waText'), wa: text, waLabel: 'done.waOpen', onAgain: null });
    } else if (channel === 'mail') {
      D.openMail(t('msg.quote.title', { ref: ref }), text);
      D.showDone(f, 'quote-body', 'quote-done', { title: t('done.mailTitle'), ref: ref, text: t('done.mailText', { email: CFG.contact.email || '' }), onAgain: null });
    } else {
      D.busy(btn, true);
      var paths = [];
      Promise.all(files.map(function (file) {
        var p = 'public/' + id + '/' + file.name.replace(/[^\w.\-]+/g, '_').slice(-80);
        paths.push(p);
        return D.db.upload(p, file);
      })).then(function () {
        return D.db.insert('quote_requests', {
          id: id, ref: ref, lang: D.lang, client_type: d.client_type, company: d.company || null, full_name: d.full_name, phone: d.phone, email: d.email || null,
          contact_pref: d.contact_pref, city: d.city || null, services: d.services, sector: d.sector || null, description: d.description || null, budget: d.budget,
          urgency: d.urgency, start_date: d.start_date || null, options: d.options, files: paths
        });
      }).then(function () {
        D.showDone(f, 'quote-body', 'quote-done', { title: t('done.quoteTitle'), ref: ref, text: t('done.quoteText'), wa: t('msg.followup', { ref: ref }), waLabel: 'done.wa', onAgain: resetQuote });
        basket.clear(); files = []; renderFiles();
        D.emit('sent', { kind: 'quote' });
      }).catch(function () { D.formError(er, t(files.length ? 'err.sendFiles' : 'err.send')); })
        .then(function () { D.busy(btn, false); });
    }
  }
  function setMode() {
    var db = D.db.enabled, f = $('#quote-form');
    $('#q-submit-t').textContent = t(db ? 'q.submitDb' : 'q.submitWa');
    $('[data-send="wa"]', f).hidden = !db;
    $('#q-files-note').hidden = db;
    $('#c-submit-t').textContent = t(db ? 'contact.submitDb' : 'contact.submitWa');
  }
  function initQuote() {
    var f = $('#quote-form');
    D.watchErrors(f);
    fillSectors(); syncType(); syncBudget(); initPicker(); initDrop();
    $$('input[name="client_type"]', f).forEach(function (r) { r.addEventListener('change', syncType); });
    $('#q-budget').addEventListener('input', syncBudget);
    $('#q-desc').addEventListener('input', function (e) { $('#q-desc-n').textContent = e.target.value.length; });
    $('#q-date').min = D.todayStr();
    f.addEventListener('submit', function (e) { e.preventDefault(); sendQuote(D.db.enabled ? 'db' : 'wa'); });
    $$('[data-send]', f).forEach(function (b) { b.addEventListener('click', function () { sendQuote(b.getAttribute('data-send')); }); });
  }

  /* ----- formulaire de contact ----- */
  function sendContact(channel) {
    var f = $('#contact-form'), er = $('#c-error'), btn = $('#c-submit');
    D.clearErrors(f);
    if (f.website.value) return;
    var name = f.full_name.value.trim(), how = f.contact.value.trim(), msg = f.message.value.trim(), first = null, isMail = how.indexOf('@') > -1;
    if (!name) first = D.fieldError(f.full_name, t('err.name'), first);
    if (!how) first = D.fieldError(f.contact, t('err.contact'), first);
    else if (isMail ? !D.validEmail(how) : !D.validPhone(D.fullPhone('+243', how))) first = D.fieldError(f.contact, t('err.contactBad'), first);
    if (msg.length < 5) first = D.fieldError(f.message, t('err.message'), first);
    if (first) { first.focus(); return; }
    if (D.tooFast()) return;
    var id = D.newId(), ref = D.refOf(id), contact = isMail ? how : D.fullPhone('+243', how);
    var text = [t('msg.contact.title', { ref: ref }), t('msg.name') + ' : ' + name, t('msg.reach') + ' : ' + contact, t('msg.message') + ' : ' + msg].join('\n');
    function reset() { f.reset(); if (D.prefillNow) D.prefillNow(); }
    if (channel === 'wa') {
      D.openWa(text);
      D.showDone(f, 'contact-body', 'contact-done', { title: t('done.waTitle'), ref: ref, text: t('done.waText'), wa: text, waLabel: 'done.waOpen', onAgain: reset });
    } else if (channel === 'mail') {
      D.openMail(t('msg.contact.title', { ref: ref }), text);
      D.showDone(f, 'contact-body', 'contact-done', { title: t('done.mailTitle'), ref: ref, text: t('done.mailText', { email: CFG.contact.email || '' }), onAgain: reset });
    } else {
      D.busy(btn, true);
      D.db.insert('messages', { id: id, ref: ref, full_name: name, contact: contact, body: msg, lang: D.lang })
        .then(function () { D.showDone(f, 'contact-body', 'contact-done', { title: t('done.contactTitle'), ref: ref, text: t('done.contactText'), wa: t('msg.followup', { ref: ref }), waLabel: 'done.wa', onAgain: reset }); reset(); })
        .catch(function () { D.formError(er, t('err.send')); })
        .then(function () { D.busy(btn, false); });
    }
  }
  function initContact() {
    var f = $('#contact-form');
    D.watchErrors(f);
    f.addEventListener('submit', function (e) { e.preventDefault(); sendContact(D.db.enabled ? 'db' : 'wa'); });
    $('[data-send="mail"]', f).addEventListener('click', function () { sendContact('mail'); });
  }

  /* ----- préremplissage pour un client connecté ----- */
  D.profile = null;
  D.prefillNow = function () {
    var p = D.profile;
    if (!p) return;
    [['#q-name', 'full_name'], ['#r-name', 'full_name'], ['#o-name', 'full_name'], ['#c-name', 'full_name'], ['#q-email', 'email'], ['#r-email', 'email'], ['#o-email', 'email']].forEach(function (m) {
      var el = $(m[0]); if (el && !el.value && p[m[1]]) el.value = p[m[1]];
    });
    if (p.phone) ['#q-phone', '#r-phone', '#o-phone'].forEach(function (s) {
      var el = $(s), cc = $(s.replace('phone', 'cc'));
      if (el && !el.value) { var m = /^(\+(?:1|7|2[0-9]{2}|3[0-9]{1,2}|4[0-9]|9[0-9]{2}|86))(\d+)$/.exec(p.phone); if (m && cc && $('option[value="' + m[1] + '"]', cc)) { cc.value = m[1]; el.value = m[2]; } else el.value = p.phone; }
    });
  };

  D.initForms = function () {
    D.fillCC(); setMode();
    initQuote(); initContact();
    D.on('lang', function () { fillSectors(); syncBudget(); renderTags(); setMode(); D.fillCC(); });
    D.on('auth', D.prefillNow);
  };
})();
/* ==========================================================================
   Dav Intertenement : rendez-vous en ligne
   ========================================================================== */
(function () {
  'use strict';
  var D = window.DAV, $ = D.$, $$ = D.$$, esc = D.esc, CAT = D.cat, CFG = D.cfg;
  function t(k, v) { return D.t(k, v); }
  var A = CFG.appointment, LEAD = 60, ICONS = { onsite: 'pin', phone: 'phone', video: 'media', office: 'sme' };
  var state = { type: '', date: '', time: '', taken: {}, seq: 0 };

  function types() {
    var l = (A.types || []).filter(function (x) { return ICONS[x] && (x !== 'office' || D.hasAddress()); });
    return l.length ? l : ['phone'];
  }
  function toMin(s) { var m = /^(\d{1,2}):(\d{2})$/.exec(String(s || '')); return m ? +m[1] * 60 + +m[2] : 0; }
  function fmt(min) { return D.pad(Math.floor(min / 60)) + ':' + D.pad(min % 60); }
  function locale() { return D.lang === 'fr' ? 'fr-FR' : 'en-GB'; }
  function dateOf(str) { var p = str.split('-'); return new Date(Date.UTC(+p[0], +p[1] - 1, +p[2])); }
  function longDate(str) { return new Intl.DateTimeFormat(locale(), { weekday: 'long', day: 'numeric', month: 'long', timeZone: 'UTC' }).format(dateOf(str)); }

  function slotsOf(date) {
    var start = toMin(A.start || '08:00'), end = toMin(A.end || '17:00'), len = Math.max(15, +A.slotMinutes || 60), out = [], m, n = D.kinNow();
    var isToday = date === D.todayStr(), now = n.h * 60 + n.i;
    for (m = start; m + len <= end; m += len) out.push({ time: fmt(m), past: isToday && m < now + LEAD });
    return out;
  }
  function days() {
    var n = D.kinNow(), base = Date.UTC(n.y, n.m - 1, n.d), out = [], k, dt, ds;
    for (k = 0; k < Math.max(1, +A.daysAhead || 14); k++) {
      dt = new Date(base + k * 86400000);
      if ((A.closedWeekdays || []).indexOf(dt.getUTCDay()) > -1) continue;
      ds = dt.toISOString().slice(0, 10);
      if (!slotsOf(ds).some(function (s) { return !s.past; })) continue;
      out.push(ds);
    }
    return out;
  }

  /* ----- affichage ----- */
  function renderTypes() {
    var l = types();
    if (l.indexOf(state.type) < 0) state.type = l[0];
    $('#rdv-types').innerHTML = l.map(function (k) {
      return '<span class="opt"><input class="vh" type="radio" name="rdv_type" id="rt-' + k + '" value="' + k + '"' + (k === state.type ? ' checked' : '') + '><label for="rt-' + k + '">' + D.icon(ICONS[k]) + '<span><b>' + esc(t('rdv.t.' + k)) + '</b><small>' + esc(t('rdv.d.' + k)) + '</small></span></label></span>';
    }).join('');
    $('#r-addr-wrap').hidden = state.type !== 'onsite';
  }
  function renderDays() {
    var list = days(), box = $('#rdv-days');
    if (list.indexOf(state.date) < 0) { state.date = list[0] || ''; state.time = ''; }
    box.innerHTML = list.map(function (ds) {
      var dt = dateOf(ds), wd = new Intl.DateTimeFormat(locale(), { weekday: 'short', timeZone: 'UTC' }).format(dt), mo = new Intl.DateTimeFormat(locale(), { month: 'short', timeZone: 'UTC' }).format(dt);
      return '<button type="button" class="day" data-date="' + ds + '" aria-pressed="' + (ds === state.date) + '" aria-label="' + esc(longDate(ds)) + '"><small>' + esc(wd) + '</small><b>' + dt.getUTCDate() + '</b><span>' + esc(mo) + '</span></button>';
    }).join('');
    if (!list.length) box.innerHTML = '<p class="slots-empty">' + esc(t('rdv.noDays')) + '</p>';
  }
  function takenFor(date) {
    if (!D.db.enabled) return Promise.resolve([]);
    var c = state.taken[date];
    if (c && Date.now() - c.at < 30000) return Promise.resolve(c.list);
    return D.db.rpc('get_taken_slots', { p_date: date }).then(function (data) {
      var list = (data || []).map(function (x) { return String(typeof x === 'string' ? x : (x.appt_time || x.t || '')).slice(0, 5); });
      state.taken[date] = { at: Date.now(), list: list };
      return list;
    }).catch(function () { return []; });
  }
  function renderSlots() {
    var box = $('#rdv-slots'), date = state.date, mine = ++state.seq;
    if (!date) { box.innerHTML = ''; summary(); return; }
    box.setAttribute('aria-busy', 'true');
    takenFor(date).then(function (taken) {
      if (mine !== state.seq) return;
      var all = slotsOf(date);
      box.innerHTML = all.map(function (s) {
        var off = s.past || taken.indexOf(s.time) > -1;
        return '<button type="button" class="slot" data-time="' + s.time + '" aria-pressed="' + (s.time === state.time && !off) + '"' + (off ? ' disabled title="' + esc(t('rdv.unavailable')) + '"' : '') + '>' + s.time + '</button>';
      }).join('');
      if (state.time && (taken.indexOf(state.time) > -1 || (all.filter(function (s) { return s.time === state.time && s.past; }).length))) state.time = '';
      box.setAttribute('aria-busy', 'false');
      summary();
    });
  }
  function summary() {
    var el = $('#rdv-summary');
    el.textContent = state.date && state.time ? t('rdv.summary', { date: longDate(state.date), time: state.time, type: t('rdv.t.' + state.type) }) : '';
  }
  function setMode() {
    $('#r-submit-t').textContent = t(D.db.enabled ? 'rdv.submitDb' : 'rdv.submitWa');
    $('#rdv-tz').textContent = t('rdv.tz') + (D.db.enabled ? '' : ' ' + t('rdv.tzWa'));
    var tp = $('#r-topic'), cur = tp.value;
    tp.innerHTML = '<option value="">' + esc(t('rdv.topicOther')) + '</option>' + CAT.domains.map(function (d) { return '<option value="' + d.id + '">' + esc(D.domName(d)) + '</option>'; }).join('');
    tp.value = cur;
  }

  /* ----- envoi ----- */
  function topicName(v) { var d = D.DOM_BY_ID[v]; return d ? D.domName(d) : t('rdv.topicOther'); }
  function apptText(d, ref) {
    var L = [t('msg.appt.title', { ref: ref }), t('msg.type') + ' : ' + t('rdv.t.' + d.type), t('msg.when') + ' : ' + t('rdv.when', { date: longDate(d.date), time: d.time }), t('msg.topic') + ' : ' + topicName(d.topic),
      t('msg.name') + ' : ' + d.full_name, t('msg.phone') + ' : ' + d.phone];
    if (d.email) L.push(t('msg.email') + ' : ' + d.email);
    if (d.address) L.push(t('msg.address') + ' : ' + d.address);
    if (d.note) L.push(t('msg.note') + ' : ' + d.note);
    return L.join('\n');
  }
  function send(e) {
    e.preventDefault();
    var f = e.target, er = $('#r-error'), btn = $('#r-submit');
    D.clearErrors(f);
    if (f.website.value) return;
    var d = { type: state.type, date: state.date, time: state.time, topic: f.topic.value, full_name: f.full_name.value.trim(), phone: D.fullPhone(f.phone_cc.value, f.phone.value), email: f.email.value.trim(), address: f.address.value.trim(), note: f.note.value.trim() };
    var first = null;
    if (!d.date || !d.time) { D.formError(er, t('err.pickSlot')); first = $('#rdv-slots .slot:not(:disabled)') || $('#rdv-days .day'); }
    if (!d.full_name) first = D.fieldError(f.full_name, t('err.name'), first);
    if (!D.validPhone(d.phone)) first = D.fieldError(f.phone, t('err.phone'), first);
    if (d.email && !D.validEmail(d.email)) first = D.fieldError(f.email, t('err.email'), first);
    if (d.type === 'onsite' && !d.address) first = D.fieldError(f.address, t('err.address'), first);
    if (first) { first.focus(); return; }
    if (D.tooFast()) return;
    var id = D.newId(), ref = D.refOf(id), text = apptText(d, ref);
    function again() { state.time = ''; renderSlots(); f.reset(); renderTypesKeep(); if (D.prefillNow) D.prefillNow(); }
    if (!D.db.enabled) {
      D.openWa(text);
      D.showDone(f, 'rdv-body', 'rdv-done', { title: t('done.waTitle'), ref: ref, text: t('done.waText'), wa: text, waLabel: 'done.waOpen', art: 'calendar', onAgain: null });
      return;
    }
    D.busy(btn, true);
    D.db.insert('appointments', { id: id, ref: ref, appt_date: d.date, appt_time: d.time, type: d.type, topic: d.topic || null, full_name: d.full_name, phone: d.phone, email: d.email || null, address: d.address || null, note: d.note || null, lang: D.lang })
      .then(function () {
        delete state.taken[d.date];
        D.showDone(f, 'rdv-body', 'rdv-done', { title: t('done.rdvTitle'), ref: ref, text: t('done.rdvText', { date: longDate(d.date), time: d.time }), wa: t('msg.followup', { ref: ref }), waLabel: 'done.wa', art: 'calendar', onAgain: again });
        D.emit('sent', { kind: 'appointment' });
      })
      .catch(function (err) {
        var dup = err && (err.code === '23505' || /duplicate|unique/i.test(String(err.message || '')));
        if (dup) { delete state.taken[d.date]; state.time = ''; renderSlots(); }
        D.formError(er, t(dup ? 'err.slotTaken' : 'err.send'));
      })
      .then(function () { D.busy(btn, false); });
  }
  function renderTypesKeep() { renderTypes(); }

  D.initBooking = function () {
    var f = $('#rdv-form');
    D.watchErrors(f);
    renderTypes(); renderDays(); renderSlots(); setMode();
    f.addEventListener('change', function (e) {
      if (e.target.name === 'rdv_type') { state.type = e.target.value; $('#r-addr-wrap').hidden = state.type !== 'onsite'; summary(); }
    });
    $('#rdv-days').addEventListener('click', function (e) {
      var b = e.target.closest('.day'); if (!b) return;
      state.date = b.getAttribute('data-date'); state.time = '';
      $$('#rdv-days .day').forEach(function (x) { x.setAttribute('aria-pressed', String(x === b)); });
      renderSlots();
    });
    $('#rdv-slots').addEventListener('click', function (e) {
      var b = e.target.closest('.slot'); if (!b || b.disabled) return;
      state.time = b.getAttribute('data-time');
      $$('#rdv-slots .slot').forEach(function (x) { x.setAttribute('aria-pressed', String(x === b)); });
      var er = $('#r-error'); er.hidden = true; summary();
    });
    f.addEventListener('submit', send);
    D.on('lang', function () { renderTypes(); renderDays(); renderSlots(); setMode(); D.fillCC(); });
  };
})();
/* ==========================================================================
   Dav Intertenement : espace client (connexion, compte, suivi, avis)
   Actif seulement quand Supabase est configuré (ou en mode aperçu : CFG.demo).
   ========================================================================== */
(function () {
  'use strict';
  var D = window.DAV, $ = D.$, $$ = D.$$, esc = D.esc, CFG = D.cfg;
  function t(k, v) { return D.t(k, v); }
  var demo = !D.db.enabled && !!CFG.demo, user = null, view = 'login';
  D.accountEnabled = function () { return D.db.enabled || demo; };
  D.user = null;

  function show(name) {
    view = name;
    var guest = name === 'login' || name === 'register' || name === 'reset';
    $('#acct-guest').hidden = !guest;
    $('#acct-guest .seg').hidden = name === 'reset';
    $('#form-login').hidden = name !== 'login';
    $('#form-register').hidden = name !== 'register';
    $('#form-reset').hidden = name !== 'reset';
    $('#form-newpass').hidden = name !== 'newpass';
    $('#acct-user').hidden = name !== 'user';
    ['login', 'register'].forEach(function (k) { var b = $('#tab-' + k); b.setAttribute('aria-selected', String(name === k)); b.tabIndex = name === k ? 0 : -1; });
    $('#acct-title').textContent = t(name === 'user' ? 'acct.mine' : (name === 'newpass' ? 'acct.newPass' : 'acct.title'));
    $$('.banner.info', $('#dlg-account')).forEach(function (b) { b.remove(); });
  }
  function info(form, msg) {
    $$('.banner.info', form).forEach(function (b) { b.remove(); });
    var p = document.createElement('p');
    p.className = 'banner info'; p.setAttribute('role', 'status'); p.textContent = msg;
    form.insertBefore(p, form.firstChild);
  }
  function authError(err) {
    var m = String((err && err.message) || '');
    if (/invalid login/i.test(m)) return t('err.login');
    if (/not confirmed/i.test(m)) return t('err.confirm');
    if (/already registered|already been registered/i.test(m)) return t('err.exists');
    if (/at least|weak/i.test(m)) return t('err.pass');
    if (/rate|too many|seconds/i.test(m)) return t('err.rate');
    return t('err.send');
  }
  function initial(s) { return (String(s || '?').trim().charAt(0) || '?').toUpperCase(); }

  /* ----- session ----- */
  function setUser(u) {
    user = u || null; D.user = user;
    if (user) {
      var m = user.user_metadata || {};
      D.profile = { full_name: m.full_name || '', phone: m.phone || '', email: user.email || '' };
    } else D.profile = null;
    D.emit('auth', user);
    var b = $('#btn-account');
    if (b) b.setAttribute('aria-label', t(user ? 'acct.mine' : 'acct.open'));
    if ($('#dlg-account').open) {
      if (user && (view === 'login' || view === 'register' || view === 'reset')) { show('user'); dash(); }
      else if (!user && view === 'user') show('login');
    }
  }
  function open() {
    D.openDialog($('#dlg-account'));
    if (demo) { show('login'); return; }
    if (user) { show('user'); dash(); } else if (view !== 'newpass') show('login');
  }

  /* ----- tableau de bord ----- */
  function statusClass(s) { return { confirmed: 'ok', done: 'ok', delivered: 'ok', paid: 'ok', cancelled: 'bad' }[s] || 'warn'; }
  function statusLabel(s) { var k = 'st.' + s, v = t(k); return v === k ? s : v; }
  function rowHtml(ref, status, line, extra) {
    return '<li class="row"><div class="row-top"><b>' + esc(ref || '') + '</b><span class="status ' + statusClass(status) + '">' + esc(statusLabel(status)) + '</span></div><small>' + esc(line) + '</small>' + (extra || '') + '</li>';
  }
  function fillList(id, rows, none) { $('#' + id).innerHTML = rows.length ? rows.join('') : '<li class="row-empty">' + esc(none) + '</li>'; }
  function dateOnly(s) { return new Intl.DateTimeFormat(D.lang === 'fr' ? 'fr-FR' : 'en-GB', { day: 'numeric', month: 'short', year: 'numeric', timeZone: 'UTC' }).format(new Date(s)); }
  function dash() {
    var p = D.profile || {};
    $('#acct-name').textContent = p.full_name || p.email || '';
    $('#acct-email').textContent = p.full_name ? p.email : '';
    $('#acct-avatar').textContent = initial(p.full_name || p.email);
    ['acct-quotes', 'acct-appts', 'acct-orders'].forEach(function (id) { $('#' + id).innerHTML = '<li class="row-empty">' + esc(t('acct.loading')) + '</li>'; });
    D.db.client().then(function (c) {
      return Promise.all([
        c.from('quote_requests').select('id,ref,created_at,status,services').order('created_at', { ascending: false }).limit(20),
        c.from('appointments').select('id,ref,appt_date,appt_time,type,status').order('appt_date', { ascending: false }).limit(20),
        c.from('orders').select('id,ref,created_at,status,total_usd,items').order('created_at', { ascending: false }).limit(20)
      ]);
    }).then(function (r) {
      var q = r[0].data || [], a = r[1].data || [], o = r[2].data || [], today = D.todayStr();
      fillList('acct-quotes', q.map(function (x) { return rowHtml(x.ref, x.status, dateOnly(x.created_at) + ', ' + D.tn('svc.nServices', (x.services || []).length)); }), t('acct.noQuotes'));
      fillList('acct-appts', a.map(function (x) {
        var can = (x.status === 'pending' || x.status === 'confirmed') && x.appt_date >= today;
        return rowHtml(x.ref, x.status, dateOnly(x.appt_date) + ' ' + String(x.appt_time).slice(0, 5) + ', ' + t('rdv.t.' + x.type), can ? '<div class="row-act"><button type="button" class="btn btn-ghost btn-sm" data-cancel="' + esc(x.id) + '">' + esc(t('acct.cancel')) + '</button></div>' : '');
      }), t('acct.noAppts'));
      fillList('acct-orders', o.map(function (x) { return rowHtml(x.ref, x.status, dateOnly(x.created_at) + ', ' + D.tn('acct.nItems', (x.items || []).length) + (x.total_usd > 0 ? ', ' + D.money(x.total_usd) : '')); }), t('acct.noOrders'));
    }).catch(function () {
      ['acct-quotes', 'acct-appts', 'acct-orders'].forEach(function (id) { $('#' + id).innerHTML = '<li class="row-empty">' + esc(t('err.load')) + '</li>'; });
    });
  }
  function loadReviews() {
    D.db.rpc('get_public_reviews').then(function (data) { D.reviews = Array.isArray(data) ? data : []; D.renderReviews(); }).catch(function () { /* section reste cachée */ });
  }

  /* ----- formulaires ----- */
  function run(form, work) {
    var er = $('.form-error', form), btn = $('button[type="submit"]', form);
    D.clearErrors(form);
    $$('.banner.info', form).forEach(function (b) { b.remove(); });
    if (demo) { D.formError(er, t('acct.demoMsg')); return; }
    if (form.website && form.website.value) return;
    var first = work.check && work.check();
    if (first) { first.focus && first.focus(); return; }
    D.busy(btn, true);
    D.db.client().then(work.go).catch(function (e) { D.formError(er, authError(e)); }).then(function () { D.busy(btn, false); });
  }
  function initForms() {
    var login = $('#form-login'), reg = $('#form-register'), rst = $('#form-reset'), np = $('#form-newpass'), rv = $('#form-review');
    [login, reg, rst, np, rv].forEach(D.watchErrors);

    login.addEventListener('submit', function (e) {
      e.preventDefault();
      run(login, {
        check: function () { var f = login, x = null; if (!D.validEmail(f.email.value.trim())) x = D.fieldError(f.email, t('err.email')); if (!f.password.value) x = D.fieldError(f.password, t('err.passEmpty'), x); return x; },
        go: function (c) { return c.auth.signInWithPassword({ email: login.email.value.trim(), password: login.password.value }).then(function (r) { if (r.error) throw r.error; login.reset(); }); }
      });
    });
    reg.addEventListener('submit', function (e) {
      e.preventDefault();
      run(reg, {
        check: function () {
          var f = reg, x = null, ph = f.phone.value.trim() ? D.fullPhone(f.phone_cc.value, f.phone.value) : '';
          if (!f.full_name.value.trim()) x = D.fieldError(f.full_name, t('err.name'));
          if (ph && !D.validPhone(ph)) x = D.fieldError(f.phone, t('err.phone'), x);
          if (!D.validEmail(f.email.value.trim())) x = D.fieldError(f.email, t('err.email'), x);
          if (f.password.value.length < 8) x = D.fieldError(f.password, t('err.pass'), x);
          return x;
        },
        go: function (c) {
          var f = reg, ph = f.phone.value.trim() ? D.fullPhone(f.phone_cc.value, f.phone.value) : '';
          return c.auth.signUp({ email: f.email.value.trim(), password: f.password.value, options: { data: { full_name: f.full_name.value.trim(), phone: ph }, emailRedirectTo: location.origin + location.pathname } })
            .then(function (r) {
              if (r.error) throw r.error;
              if (r.data && r.data.session) { f.reset(); D.toast(t('acct.welcome')); } else info(f, t('acct.checkMail'));
            });
        }
      });
    });
    rst.addEventListener('submit', function (e) {
      e.preventDefault();
      run(rst, {
        check: function () { return D.validEmail(rst.email.value.trim()) ? null : D.fieldError(rst.email, t('err.email')); },
        go: function (c) { return c.auth.resetPasswordForEmail(rst.email.value.trim(), { redirectTo: location.origin + location.pathname }).then(function (r) { if (r.error) throw r.error; info(rst, t('acct.resetSent')); }); }
      });
    });
    np.addEventListener('submit', function (e) {
      e.preventDefault();
      run(np, {
        check: function () { return np.password.value.length >= 8 ? null : D.fieldError(np.password, t('err.pass')); },
        go: function (c) { return c.auth.updateUser({ password: np.password.value }).then(function (r) { if (r.error) throw r.error; np.reset(); D.toast(t('acct.passSaved')); show('user'); dash(); }); }
      });
    });
    rv.addEventListener('submit', function (e) {
      e.preventDefault();
      run(rv, {
        check: function () { if (!rv.rating.value) { D.formError($('.form-error', rv), t('err.rating')); return $('#rv-5'); } if (rv.body.value.trim().length < 10) return D.fieldError(rv.body, t('err.review')); return null; },
        go: function () {
          var p = D.profile || {};
          return D.db.insert('reviews', { rating: +rv.rating.value, body: rv.body.value.trim(), author_name: p.full_name || null, lang: D.lang }).then(function () { rv.reset(); info(rv, t('acct.reviewSent')); });
        }
      });
    });

    $('#tab-login').addEventListener('click', function () { show('login'); });
    $('#tab-register').addEventListener('click', function () { show('register'); });
    $('#acct-guest .seg').addEventListener('keydown', function (e) {
      if (e.key === 'ArrowRight' || e.key === 'ArrowLeft') { e.preventDefault(); var to = view === 'login' ? 'register' : 'login'; show(to); $('#tab-' + to).focus(); }
    });
    $('#btn-forgot').addEventListener('click', function () { show('reset'); $('#x-email').focus(); });
    $('#btn-back-login').addEventListener('click', function () { show('login'); });
    $('#btn-logout').addEventListener('click', function () { if (demo) return; D.db.client().then(function (c) { return c.auth.signOut(); }).then(function () { show('login'); D.toast(t('acct.bye')); }); });
    $$('[data-pw]', $('#dlg-account')).forEach(function (b) {
      b.addEventListener('click', function () {
        var inp = $('input', b.parentNode), on = inp.type === 'password';
        inp.type = on ? 'text' : 'password';
        b.innerHTML = D.icon(on ? 'eyeOff' : 'eye');
        b.setAttribute('aria-label', t(on ? 'acct.hidePass' : 'acct.showPass'));
      });
    });
    $('#acct-appts').addEventListener('click', function (e) {
      var b = e.target.closest('[data-cancel]');
      if (!b) return;
      D.busy(b, true);
      D.db.rpc('cancel_my_appointment', { p_id: b.getAttribute('data-cancel') }).then(function () { D.toast(t('acct.cancelled')); dash(); }).catch(function () { D.busy(b, false); D.toast(t('err.send')); });
    });
    $('#rev-write').addEventListener('click', function () {
      open();
      if (user) { var s = $('#acct-review'); if (s) s.scrollIntoView({ block: 'center' }); }
    });
  }

  D.initAccount = function () {
    if (!D.accountEnabled()) return;
    $('#btn-account').hidden = false;
    $('#acct-demo').hidden = !demo;
    $('[data-act="account"]').addEventListener('click', open);
    initForms();
    if (D.db.enabled) {
      D.db.client().then(function (c) {
        c.auth.onAuthStateChange(function (ev, session) {
          setUser(session && session.user);
          if (ev === 'PASSWORD_RECOVERY') { D.openDialog($('#dlg-account')); show('newpass'); }
        });
        return c.auth.getSession();
      }).then(function (r) { setUser(r && r.data && r.data.session && r.data.session.user); }).catch(function () { /* hors ligne */ });
      loadReviews();
    }
    D.on('lang', function () { if (user && $('#dlg-account').open && view === 'user') dash(); show(view); });
    D.renderReviews();
  };
})();
/* ==========================================================================
   Dav Intertenement : fonds animés de l’accueil
   - réseau animé : les icônes de tous les domaines reliées entre elles
   - diaporama de tes propres photos (images.heroSlides dans config.js)
   - illustrations de l’accueil qui changent toutes seules
   - bouton pause, mouvement réduit respecté, arrêt quand l’accueil n’est pas à l’écran
   Réglages : effects et images.heroSlides dans config.js
   ========================================================================== */
(function () {
  'use strict';
  var D = window.DAV, $ = D.$, $$ = D.$$, CFG = D.cfg, FX = CFG.effects || {};
  function enabled(k) { return FX[k] !== false; }

  var reduceMq = window.matchMedia ? window.matchMedia('(prefers-reduced-motion: reduce)') : null;
  var reduce = !!(reduceMq && reduceMq.matches);
  var conn = navigator.connection || {};
  var lowData = !!(conn.saveData || /(^|-)2g$/.test(String(conn.effectiveType || '')));
  var KEY = 'dav-motion';
  var st = { paused: false, inView: true, hidden: !!document.hidden };
  var parts = [], btn = null;

  function wantPaused() {
    if (reduce) return true;
    var p = D.pref.get(KEY);
    if (p === 'off') return true;
    if (p === 'on') return false;
    return lowData;
  }
  function running() { return !st.paused && st.inView && !st.hidden; }
  function paintButton() {
    if (!btn) return;
    btn.setAttribute('aria-pressed', String(st.paused));
    btn.innerHTML = D.icon(st.paused ? 'play' : 'pause');
    var label = D.t(st.paused ? 'bg.play' : 'bg.pause');
    btn.setAttribute('aria-label', label);
    btn.title = label;
  }
  function apply() {
    var run = running();
    document.documentElement.classList.toggle('fx-paused', st.paused);
    parts.forEach(function (p) { if (run) p.start(); else p.stop(); });
    paintButton();
  }
  function rnd(a, b) { return a + Math.random() * (b - a); }

  /* ---------- Réseau animé : les icônes des domaines reliées entre elles ---------- */
  function makeNet(canvas, hero) {
    var ctx = canvas.getContext ? canvas.getContext('2d') : null;
    if (!ctx) return null;
    var TAU = Math.PI * 2, M = 26;
    var W = 0, H = 0, dpr = 1, small = false, LD = 150, LD2 = LD * LD, gap = 0;
    var nodes = [], packets = [], imgs = {}, raf = 0, last = 0, lastSpawn = 0, box = null;
    var ptr = { x: -1e4, y: -1e4 };
    var col = { line: '206,202,190', spark: '95,226,240', spark2: '164,142,255' };

    function readColors() {
      var cs = window.getComputedStyle(document.documentElement);
      function pick(name, dflt) {
        var v = String(cs.getPropertyValue(name) || '').replace(/\s+/g, '');
        return /^\d{1,3},\d{1,3},\d{1,3}$/.test(v) ? v : dflt;
      }
      col.line = pick('--fx-rgb', col.line);
      col.spark = pick('--fx-spark-rgb', col.spark);
      col.spark2 = pick('--fx-spark2-rgb', col.spark2);
    }
    function iconImg(key) {
      if (imgs[key]) return imgs[key];
      var svg = D.art.icon(key, { size: 64, sw: 1.5 }).replace(/currentColor/g, 'rgb(' + col.line + ')');
      var im = new Image();
      im.onload = function () { if (!raf) draw(0); };
      im.src = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svg);
      imgs[key] = im;
      return im;
    }
    function mkNode(icon) {
      var s = small ? 22 : 28, a = rnd(0, TAU), v = rnd(6, small ? 13 : 17);
      var x = icon && W > 900 ? rnd(W * 0.34, Math.max(W * 0.34 + 1, W - M)) : rnd(M, Math.max(M + 1, W - M));
      return {
        x: x, y: rnd(M, Math.max(M + 1, H - M)), vx: Math.cos(a) * v, vy: Math.sin(a) * v,
        icon: icon, img: icon ? iconImg(icon) : null, s: icon ? s + rnd(-3, 4) : rnd(1.1, 2.1),
        ph: rnd(0, TAU), fade: 1, flash: 0
      };
    }
    function build() {
      nodes = []; packets = [];
      var doms = ((D.cat && D.cat.domains) || []).filter(function (d) { return d.icon; });
      var nIcons = small ? Math.min(12, doms.length) : doms.length, nDust = small ? 14 : 28, i, k, tries, n, ok;
      for (i = 0; i < nIcons; i++) {
        var d = doms[Math.floor(i * doms.length / nIcons)];
        for (tries = 0; tries < 24; tries++) {
          n = mkNode(d.icon); ok = true;
          for (k = 0; k < nodes.length; k++) {
            if (nodes[k].icon && Math.abs(nodes[k].x - n.x) < 58 && Math.abs(nodes[k].y - n.y) < 58) { ok = false; break; }
          }
          if (ok) break;
        }
        nodes.push(n);
      }
      for (i = 0; i < nDust; i++) nodes.push(mkNode(null));
    }
    function measure() {
      var c = $('.hero-copy', hero), r = hero.getBoundingClientRect();
      if (!c) { box = null; return; }
      var b = c.getBoundingClientRect();
      box = { l: b.left - r.left - 12, r: b.right - r.left + 12, t: b.top - r.top - 12, b: b.bottom - r.top + 12 };
    }
    function resize() {
      var r = hero.getBoundingClientRect(), w = Math.round(r.width), h = Math.round(r.height);
      if (w < 1 || h < 1) return; /* l’accueil est caché (autre onglet ouvert) : on garde la taille et les points actuels */
      if (w === W && h === H) return;
      var ow = W, oh = H, wasSmall = small;
      W = w; H = h; dpr = Math.min(window.devicePixelRatio || 1, 1.5);
      canvas.width = Math.round(W * dpr); canvas.height = Math.round(H * dpr);
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      small = W < 700; LD = small ? 112 : 150; LD2 = LD * LD; gap = small ? 28 : 0;
      readColors();
      if (!nodes.length || small !== wasSmall) build();
      else nodes.forEach(function (n) { n.x *= W / ow; n.y *= H / oh; });
      measure();
      if (!raf) draw(0);
    }

    function step(dt) {
      var i, n, dx, dy, d, f, sp, inside, p, mx = small ? 16 : 20, pr = small ? 90 : 120;
      for (i = 0; i < nodes.length; i++) {
        n = nodes[i];
        n.vx += (Math.random() - 0.5) * 6 * dt; n.vy += (Math.random() - 0.5) * 6 * dt;
        sp = Math.sqrt(n.vx * n.vx + n.vy * n.vy);
        if (sp > mx) { n.vx *= mx / sp; n.vy *= mx / sp; }
        else if (sp < 5 && sp > 0.01) { n.vx *= 5 / sp; n.vy *= 5 / sp; }
        n.x += n.vx * dt; n.y += n.vy * dt;
        if (n.x < M) { n.x = M; n.vx = Math.abs(n.vx); } else if (n.x > W - M) { n.x = W - M; n.vx = -Math.abs(n.vx); }
        if (n.y < M) { n.y = M; n.vy = Math.abs(n.vy); } else if (n.y > H - M) { n.y = H - M; n.vy = -Math.abs(n.vy); }
        dx = n.x - ptr.x; dy = n.y - ptr.y; d = Math.sqrt(dx * dx + dy * dy);
        if (d < pr && d > 0.5) { f = (1 - d / pr) * 70 * dt; n.x += dx / d * f; n.y += dy / d * f; }
        inside = box && n.x > box.l && n.x < box.r && n.y > box.t && n.y < box.b;
        n.fade += ((inside ? (n.icon ? 0.38 : 0.5) : 1) - n.fade) * Math.min(1, dt * 3);
        if (n.flash > 0) n.flash = Math.max(0, n.flash - dt * 1.6);
      }
      for (i = packets.length - 1; i >= 0; i--) {
        p = packets[i]; p.t += dt / p.dur;
        if (p.t >= 1) { p.b.flash = 1; packets.splice(i, 1); }
      }
    }
    function spawn(now) {
      if (packets.length >= (small ? 3 : 6) || now - lastSpawn < 380 || nodes.length < 2) return;
      for (var k = 0; k < 10; k++) {
        var a = nodes[(Math.random() * nodes.length) | 0], b = nodes[(Math.random() * nodes.length) | 0];
        if (a === b || !(a.icon || b.icon)) continue;
        var dx = a.x - b.x, dy = a.y - b.y;
        if (dx * dx + dy * dy < LD2 * 0.85) { packets.push({ a: a, b: b, t: 0, dur: rnd(1.1, 2), c: Math.random() < 0.45 ? 1 : 0 }); lastSpawn = now; return; }
      }
    }
    function draw(t) {
      var i, j, a, b, dx, dy, d2, al, n, p, x, y, tt, x0, y0, sc;
      ctx.clearRect(0, 0, W, H);
      ctx.lineWidth = 1;
      for (i = 0; i < nodes.length; i++) {
        a = nodes[i];
        for (j = i + 1; j < nodes.length; j++) {
          b = nodes[j]; dx = a.x - b.x; dy = a.y - b.y; d2 = dx * dx + dy * dy;
          if (d2 < LD2) {
            al = (1 - Math.sqrt(d2) / LD) * 0.36 * Math.min(a.fade, b.fade);
            ctx.strokeStyle = 'rgba(' + col.line + ',' + al.toFixed(3) + ')';
            ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); ctx.stroke();
          }
        }
        dx = a.x - ptr.x; dy = a.y - ptr.y; d2 = dx * dx + dy * dy;
        if (d2 < 22500) {
          al = (1 - Math.sqrt(d2) / 150) * 0.5;
          ctx.strokeStyle = 'rgba(' + col.spark + ',' + al.toFixed(3) + ')';
          ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(ptr.x, ptr.y); ctx.stroke();
        }
      }
      for (i = 0; i < nodes.length; i++) {
        n = nodes[i];
        if (n.icon) {
          al = n.fade * (0.8 + 0.2 * Math.sin(t * 1.4 + n.ph));
          ctx.beginPath(); ctx.arc(n.x, n.y, n.s * 0.92, 0, TAU);
          ctx.fillStyle = 'rgba(' + col.line + ',' + (0.09 * al + n.flash * 0.2).toFixed(3) + ')'; ctx.fill();
          ctx.strokeStyle = 'rgba(' + (n.flash > 0.05 ? col.spark : col.line) + ',' + Math.min(1, 0.36 * al + n.flash * 0.6).toFixed(3) + ')'; ctx.stroke();
          if (n.img.complete && n.img.naturalWidth) {
            ctx.globalAlpha = Math.min(1, al * 0.95 + n.flash * 0.4);
            ctx.drawImage(n.img, n.x - n.s / 2, n.y - n.s / 2, n.s, n.s);
            ctx.globalAlpha = 1;
          }
        } else {
          ctx.beginPath(); ctx.arc(n.x, n.y, n.s, 0, TAU);
          ctx.fillStyle = 'rgba(' + col.line + ',' + (0.55 * n.fade).toFixed(3) + ')'; ctx.fill();
        }
      }
      for (i = 0; i < packets.length; i++) {
        p = packets[i]; sc = p.c ? col.spark2 : col.spark;
        x = p.a.x + (p.b.x - p.a.x) * p.t; y = p.a.y + (p.b.y - p.a.y) * p.t;
        tt = Math.max(0, p.t - 0.12); x0 = p.a.x + (p.b.x - p.a.x) * tt; y0 = p.a.y + (p.b.y - p.a.y) * tt;
        ctx.strokeStyle = 'rgba(' + sc + ',.6)'; ctx.lineWidth = 1.6;
        ctx.beginPath(); ctx.moveTo(x0, y0); ctx.lineTo(x, y); ctx.stroke(); ctx.lineWidth = 1;
        ctx.fillStyle = 'rgba(' + sc + ',.24)'; ctx.beginPath(); ctx.arc(x, y, 6, 0, TAU); ctx.fill();
        ctx.fillStyle = 'rgba(' + sc + ',.95)'; ctx.beginPath(); ctx.arc(x, y, 2.2, 0, TAU); ctx.fill();
      }
    }
    function frame(now) {
      raf = window.requestAnimationFrame(frame);
      if (gap && now - last < gap) return;
      var dt = Math.min(0.05, Math.max(0.001, (now - last) / 1000));
      last = now;
      spawn(now); step(dt); draw(now / 1000);
    }

    function onMove(e) { var r = canvas.getBoundingClientRect(); ptr.x = e.clientX - r.left; ptr.y = e.clientY - r.top; }
    function onOut() { ptr.x = ptr.y = -1e4; }
    hero.addEventListener('pointermove', onMove, { passive: true });
    hero.addEventListener('pointerleave', onOut);
    hero.addEventListener('pointercancel', onOut);
    hero.addEventListener('pointerup', function (e) { if (e.pointerType === 'touch') onOut(); });
    if (window.ResizeObserver) new window.ResizeObserver(resize).observe(hero); else window.addEventListener('resize', resize);
    resize();

    return {
      start: function () { if (!raf) { last = window.performance.now(); raf = window.requestAnimationFrame(frame); } },
      stop: function () { if (raf) { window.cancelAnimationFrame(raf); raf = 0; } },
      still: function () { if (!raf) draw(0); }
    };
  }

  /* ---------- Diaporama de tes photos (images.heroSlides) ---------- */
  function makeSlides(box, list) {
    var slides = list.map(function (src) {
      var d = document.createElement('div');
      d.className = 'hb-slide';
      d.style.backgroundImage = 'url("' + encodeURI(String(src)).replace(/["()\\]/g, '') + '")';
      box.appendChild(d);
      return d;
    });
    var i = -1, timer = 0;
    function show(n) {
      var prev = slides[i];
      if (prev) { prev.classList.remove('on'); prev.classList.add('out'); setTimeout(function () { prev.classList.remove('out'); }, 1700); }
      i = n; slides[i].classList.remove('out'); slides[i].classList.add('on');
    }
    show(0);
    return {
      start: function () { if (slides.length > 1 && !timer) timer = setInterval(function () { show((i + 1) % slides.length); }, 6500); },
      stop: function () { clearInterval(timer); timer = 0; }
    };
  }

  /* ---------- Illustrations de l’accueil qui changent toutes seules ---------- */
  function makeCards(wrap) {
    var timer = 0, tick = 0, cursor = 0, doms = (D.cat && D.cat.domains) || [];
    function swap(fig, d) {
      fig.classList.add('out');
      setTimeout(function () {
        if (!fig.isConnected) return;
        fig.setAttribute('data-dom', d.id);
        fig.innerHTML = D.art.scene(d.id) + '<figcaption>' + D.esc(D.domName(d)) + '</figcaption>';
        fig.classList.remove('out'); fig.classList.add('in');
        setTimeout(function () { fig.classList.remove('in'); }, 560);
      }, 320);
    }
    function next() {
      var figs = $$('figure[data-dom]', wrap).filter(function (f) { return f.offsetParent !== null; });
      if (!figs.length || !doms.length) return;
      var shown = {};
      $$('figure[data-dom]', wrap).forEach(function (f) { shown[f.getAttribute('data-dom')] = 1; });
      var slot = figs[tick % figs.length]; tick++;
      for (var k = 0; k < doms.length; k++) {
        var d = doms[(cursor + k) % doms.length];
        if (!shown[d.id]) { cursor = (cursor + k + 1) % doms.length; swap(slot, d); return; }
      }
    }
    return {
      start: function () { if (!timer) timer = setInterval(next, 3600); },
      stop: function () { clearInterval(timer); timer = 0; }
    };
  }

  /* ---------- Chiffres de l’accueil qui montent ---------- */
  function countUp() {
    if (reduce || st.paused || !window.performance) return;
    var n = { domains: ((D.cat && D.cat.domains) || []).length, services: (D.SVC || []).length };
    $$('.hero [data-count]').forEach(function (el) {
      var to = n[el.getAttribute('data-count')], t0 = 0;
      if (!to) return;
      el.textContent = '0';
      (function tick(ts) {
        if (!t0) t0 = ts;
        var p = Math.min(1, (ts - t0) / 900);
        el.textContent = String(Math.round(to * (1 - Math.pow(1 - p, 3))));
        if (p < 1) window.requestAnimationFrame(tick);
      })(window.performance.now());
    });
  }

  D.initMotion = function () {
    var hero = $('#accueil'), bg = $('#hero-bg');
    btn = $('#hb-toggle');
    if (!hero || !bg) return;
    var amb = $('.ambient');
    if (amb && !enabled('ambient')) amb.remove();
    if (!enabled('glow')) $$('.hb-glow', bg).forEach(function (g) { g.remove(); });
    st.paused = wantPaused();

    var slides = CFG.images && CFG.images.heroSlides, box = $('#hero-slides');
    if (Array.isArray(slides) && slides.length && box) parts.push(makeSlides(box, slides)); else if (box) box.remove();

    var canvas = $('#hero-net'), net = enabled('network') && canvas ? makeNet(canvas, hero) : null;
    if (net) parts.push(net); else if (canvas) canvas.remove();

    if (enabled('cards') && !(CFG.images && CFG.images.hero)) parts.push(makeCards($('#hero-art')));

    if ('IntersectionObserver' in window) {
      new IntersectionObserver(function (es) { st.inView = es[es.length - 1].isIntersecting; apply(); }, { threshold: 0 }).observe(hero);
    }
    document.addEventListener('visibilitychange', function () { st.hidden = !!document.hidden; apply(); });
    if (btn) {
      btn.hidden = reduce || !parts.length;
      btn.addEventListener('click', function () { st.paused = !st.paused; D.pref.set(KEY, st.paused ? 'off' : 'on'); apply(); });
    }
    D.on('lang', paintButton);
    if (reduceMq && reduceMq.addEventListener) {
      reduceMq.addEventListener('change', function (e) {
        reduce = e.matches; st.paused = wantPaused();
        if (btn) btn.hidden = reduce || !parts.length;
        apply();
      });
    }
    apply();
    if (net) net.still();
    countUp();
  };
})();
/* ==========================================================================
   Dav Intertenement : onglets (pages) et navigation
   Une seule page est visible à la fois. L’adresse (#boutique, #devis…) dit quel onglet est ouvert :
   le bouton Retour du téléphone revient donc à l’onglet précédent, et un lien comme #boutique ouvre directement la boutique.
   Pour ajouter un onglet : ajoute-le dans VIEWS, crée <div class="view" id="view-xxx" data-view="xxx"> dans index.html,
   ajoute son lien dans le menu (nav) et sa règle dans la feuille de style (.js[data-view="xxx"] #view-xxx).
   ========================================================================== */
(function () {
  'use strict';
  var D = window.DAV, $ = D.$, $$ = D.$$;
  var VIEWS = ['accueil', 'services', 'secteurs', 'boutique', 'devis', 'rdv', 'faq', 'contact'];
  var NAVKEY = { services: 'nav.services', secteurs: 'nav.sectors', boutique: 'nav.shop', devis: 'nav.quote', rdv: 'nav.appointment', faq: 'nav.faq', contact: 'nav.contact' };
  var root = document.documentElement;
  var cur = '', saved = {}, lock = false, ready = false;

  /* défilement sans animation, même si la page est réglée sur « smooth » */
  function jump(fn) {
    var p = root.style.scrollBehavior;
    root.style.scrollBehavior = 'auto';
    try { fn(); } finally { root.style.scrollBehavior = p; }
  }
  function headerH() { var h = $('#top'); return h ? h.offsetHeight : 0; }
  /* saut immédiat ; si on est déjà à cet endroit, un petit écart force l’arrêt d’un défilement animé encore en cours */
  function setY(y) {
    if (Math.abs(window.pageYOffset - y) < 1) window.scrollTo(0, y + 1);
    window.scrollTo(0, y);
  }
  /* certains navigateurs font encore un dernier pas d’un défilement animé juste après le saut : on remet la page en place
     pendant quelques images, sauf si la personne touche l’écran ou la molette entre-temps */
  var inputs = 0;
  ['wheel', 'touchstart', 'touchmove', 'keydown'].forEach(function (ev) { window.addEventListener(ev, function () { inputs++; }, { passive: true }); });
  function settle(wanted) {
    var n = 0, i0 = inputs;
    (function next() {
      window.requestAnimationFrame(function () {
        if (inputs !== i0 || ++n > 4) return;
        var y = wanted();
        if (Math.abs(window.pageYOffset - y) > 1) jump(function () { window.scrollTo(0, y); });
        next();
      });
    })();
  }
  function elTop(el) { return Math.max(0, el.getBoundingClientRect().top + window.pageYOffset - (headerH() + 14)); }
  function toEl(el, smooth) {
    if (smooth) { window.scrollTo({ top: elTop(el), behavior: 'smooth' }); return; }
    jump(function () { setY(elTop(el)); });
    settle(function () { return elTop(el); });
  }
  function toY(y, smooth) {
    if (smooth) { window.scrollTo({ top: y, behavior: 'smooth' }); return; }
    jump(function () { setY(y); });
    settle(function () { return y; });
  }

  /* adresse -> onglet (et élément visé, par exemple #svc-web ou #methode) */
  function resolve(hash) {
    var id = '';
    try { id = decodeURIComponent(String(hash || '').replace(/^#/, '')); } catch (e) { id = ''; }
    if (!id) return { view: 'accueil', el: null };
    if (VIEWS.indexOf(id) > -1) return { view: id, el: null };
    var el = document.getElementById(id), v = el && el.closest ? el.closest('.view') : null;
    return v ? { view: v.getAttribute('data-view'), el: el } : { view: null, el: null };
  }

  function paintNav() {
    $$('#nav a, .ftr-nav a').forEach(function (a) {
      if (a.getAttribute('href') === '#' + cur) a.setAttribute('aria-current', 'page'); else a.removeAttribute('aria-current');
    });
    var nav = $('#nav'), a = nav && $('a[aria-current="page"]', nav);
    if (a && nav.scrollWidth > nav.clientWidth + 2) {
      var left = Math.max(0, a.offsetLeft - (nav.clientWidth - a.offsetWidth) / 2);
      if (nav.scrollTo) nav.scrollTo({ left: left, behavior: ready ? 'smooth' : 'auto' }); else nav.scrollLeft = left;
    }
  }
  function paintTitle() {
    var brand = (D.cfg.brand && D.cfg.brand.name) || 'Dav Intertenement';
    document.title = NAVKEY[cur] ? D.t(NAVKEY[cur]) + ' | ' + brand : D.t('meta.title');
  }
  function focusHeading() {
    var v = document.getElementById('view-' + cur), h = v && $('h1, h2', v);
    if (!h) return;
    if (!h.hasAttribute('tabindex')) h.setAttribute('tabindex', '-1');
    try { h.focus({ preventScroll: true }); } catch (e) { /* ignore */ }
  }

  function show(v, user) {
    cur = v;
    root.setAttribute('data-view', v);
    lock = true;
    window.requestAnimationFrame(function () { window.requestAnimationFrame(function () { lock = false; }); });
    $$('.view.enter').forEach(function (x) { x.classList.remove('enter'); });
    var el = document.getElementById('view-' + v);
    if (user && el) {
      void el.offsetWidth;
      el.classList.add('enter');
      el.addEventListener('animationend', function done() { el.classList.remove('enter'); el.removeEventListener('animationend', done); });
    }
    paintNav(); paintTitle();
    D.emit('view', v);
  }

  /* user = vrai quand la personne vient de toucher un lien ; faux au chargement et avec les boutons Retour / Avancer */
  function route(user) {
    var r = resolve(location.hash), next = r.view || cur || 'accueil', changed = next !== cur;
    if (changed) show(next, user);
    if (r.el) {
      if (/^svc-/.test(r.el.id) && D.openDomain) D.openDomain(r.el.id.slice(4), false);
      toEl(r.el, !changed && ready);
    } else if (changed) {
      toY(user ? 0 : (saved[next] || 0), false);
    } else if (user) {
      toY(0, true);
    }
    if (changed && user) focusHeading();
  }

  /* D.go('#boutique') : ouvre l’onglet (ou l’élément) et ajoute une étape à l’historique */
  D.go = function (hash) {
    hash = String(hash || '#accueil');
    if (hash.charAt(0) !== '#') hash = '#' + hash;
    if (cur) saved[cur] = window.pageYOffset;
    if ((location.hash || '#accueil') !== hash) {
      try { history.pushState(null, '', hash); } catch (e) { location.hash = hash; return; }
    }
    route(true);
  };
  D.view = function () { return cur; };

  function onClick(e) {
    if (e.defaultPrevented || e.button > 0 || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return;
    var a = e.target && e.target.closest ? e.target.closest('a[href^="#"]') : null;
    if (!a || a.target) return;
    var h = a.getAttribute('href');
    if (!h || h === '#') return;
    e.preventDefault();
    if (h === '#top') { toY(0, true); return; }
    if (h === '#main') { focusHeading(); return; }
    D.go(h);
  }

  D.initRouter = function () {
    try { if ('scrollRestoration' in history) history.scrollRestoration = 'manual'; } catch (e) { /* ignore */ }
    window.addEventListener('scroll', function () { if (!lock && cur) saved[cur] = window.pageYOffset; }, { passive: true });
    window.addEventListener('popstate', function () { route(false); });
    window.addEventListener('hashchange', function () { route(false); });
    document.addEventListener('click', onClick);
    D.on('lang', function () { paintTitle(); });
    route(false);
    ready = true;
  };
})();
/* ==========================================================================
   Dav Intertenement : démarrage et en-tête
   ========================================================================== */
(function () {
  'use strict';
  var D = window.DAV, $ = D.$;
  function safe(name) { try { if (D[name]) D[name](); } catch (e) { if (window.console) console.error(name, e); } }

  function initHeader() {
    document.addEventListener('click', function (e) {
      var l = e.target.closest('[data-act="lang"]'), th = e.target.closest('[data-act="theme"]');
      if (l) { D.setLang(D.lang === 'fr' ? 'en' : 'fr'); }
      if (th) { D.setTheme(D.theme() === 'dark' ? 'light' : 'dark'); }
    });
  }

  /* Logo : on utilise les images du dossier img (noms réglables dans config.js).
     Si une image manque, on affiche à la place le petit logo dessiné. */
  function initLogos() {
    var B = D.cfg.brand;
    function put(sel, src, size) {
      var host = $(sel); if (!host) return;
      var im = $('img', host);
      function fallback() { if (size) host.innerHTML = D.art.logo({ size: size }); else host.hidden = true; }
      if (!im) return fallback();
      im.addEventListener('error', fallback, { once: true });
      if (im.getAttribute('src') !== src) im.setAttribute('src', src);
      if (im.complete && im.getAttribute('src') && !im.naturalWidth) fallback();
    }
    put('#brand-logo', B.logo, 38);
    put('#ftr-logo', B.logo, 46);
    put('#about-logo-host', B.emblem, 0);
  }

  function boot() {
    var saved = D.pref.get('dav-lang'), nl = String(navigator.language || 'fr').slice(0, 2).toLowerCase();
    D.lang = saved === 'en' || saved === 'fr' ? saved : (nl === 'en' ? 'en' : 'fr');
    initLogos();
    D.hydrate(document);
    D.initDialogs();
    D.fillCC();
    D.setLang(D.lang, true);
    D.setTheme(D.theme());
    $('#year').textContent = new Date().getFullYear();
    safe('initHome'); safe('initContent'); safe('initShop'); safe('initForms'); safe('initBooking'); safe('initAccount');
    safe('initRouter'); safe('initMotion');
    initHeader();
    D.emit('ready');
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot); else boot();
})();
