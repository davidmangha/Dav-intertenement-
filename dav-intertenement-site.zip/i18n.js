/* ==========================================================================
   Dav Intertenement : textes du site, français (fr) et anglais (en)
   Pour changer un texte : cherche la clé (ex. hero.title) et modifie la 2e
   ligne (français) ou la 3e (anglais). Garde les {mots} entre accolades.
   ========================================================================== */
(function () {
  'use strict';
  var fr = {}, en = {};
  function K(k, a, b) { fr[k] = a; en[k] = b; }

  /* ----- page, accessibilité, outils ----- */
  K('meta.title', 'Dav Intertenement | Entreprise informatique à Kinshasa', 'Dav Intertenement | IT company in Kinshasa');
  K('meta.desc', 'Dav Intertenement, entreprise informatique à Kinshasa. Sites web, applications, réseaux, sécurité, caméras, matériel, énergie, cloud, IA, formation : tous les domaines de l’informatique, avec devis, rendez-vous en ligne et boutique de matériel.', 'Dav Intertenement, an IT company in Kinshasa. Websites, apps, networks, security, cameras, hardware, power, cloud, AI, training: every area of IT, with quotes, online appointments and a hardware shop.');
  K('meta.ogdesc', 'Tous les domaines de l’informatique : sites web, réseaux, sécurité, caméras, matériel, énergie, cloud, IA, formation. Devis, rendez-vous en ligne et boutique.', 'Every area of IT: websites, networks, security, cameras, hardware, power, cloud, AI, training. Quotes, online appointments and a shop.');
  K('a11y.skip', 'Aller au contenu', 'Skip to content');
  K('a11y.nav', 'Navigation principale', 'Main navigation');
  K('a11y.footer', 'Pied de page', 'Footer');
  K('tool.toEn', 'Passer en anglais', 'Switch to English');
  K('tool.toFr', 'Passer en français', 'Switch to French');
  K('tool.dark', 'Mode sombre', 'Dark mode');
  K('tool.light', 'Mode clair', 'Light mode');
  K('common.clear', 'Effacer', 'Clear');
  K('common.close', 'Fermer', 'Close');
  K('common.whatsapp', 'WhatsApp', 'WhatsApp');
  K('common.whatsappWrite', 'Écrire sur WhatsApp', 'Message us on WhatsApp');
  K('nav.services', 'Services', 'Services');
  K('nav.sectors', 'Secteurs', 'Sectors');
  K('nav.shop', 'Boutique', 'Shop');
  K('nav.quote', 'Devis', 'Quote');
  K('nav.appointment', 'Rendez-vous', 'Appointment');
  K('nav.faq', 'FAQ', 'FAQ');
  K('nav.contact', 'Contact', 'Contact');
  K('fab.quote', 'Mon devis', 'My quote');

  /* ----- accueil et index ----- */
  /* ----- marque ----- */
  K('brand.tagline', 'Votre hub de solutions informatiques globales', 'Your hub for global IT solutions');

  K('hero.title', 'Toute l’informatique, à Kinshasa.', 'All of IT, in Kinshasa.');
  K('hero.lead', 'Sites web, réseaux, caméras, matériel, énergie, logiciels, cloud, IA, formation et tout le reste. Cherchez votre besoin, ajoutez-le à votre liste et recevez une proposition de Dav Intertenement.', 'Websites, networks, cameras, hardware, power, software, cloud, AI, training and everything else. Search for what you need, add it to your list and get a proposal from Dav Intertenement.');
  K('hero.searchLabel', 'Que cherchez-vous ?', 'What are you looking for?');
  K('hero.searchPh', 'Ex. : caméra, Wi-Fi, site web…', 'E.g. camera, Wi-Fi, website…');
  K('hero.ctaQuote', 'Demander un devis', 'Request a quote');
  K('hero.ctaAppt', 'Prendre rendez-vous', 'Book an appointment');
  K('hero.fDomains', 'domaines', 'areas');
  K('hero.fServices', 'services listés', 'services listed');
  K('hero.fLang', 'Site en français et en anglais', 'Site in French and English');
  K('idx.title', 'Tous les domaines que nous couvrons', 'Every area we cover');
  K('idx.lead', 'Touchez un domaine pour ouvrir la liste de ses services.', 'Tap an area to open its list of services.');

  /* ----- services ----- */
  K('svc.title', 'Tous nos services, domaine par domaine', 'All our services, area by area');
  K('svc.lead', 'Ouvrez un domaine et touchez les services qui vous intéressent : ils s’ajoutent à votre demande de devis. Un besoin qui n’est pas dans la liste ? Tapez-le dans la recherche et ajoutez-le tel quel.', 'Open an area and tap the services you need: they are added to your quote request. Something that is not on the list? Type it in the search and add it as it is.');
  K('svc.filterLabel', 'Filtrer les services', 'Filter services');
  K('svc.filterPh', 'Filtrer : caméra, Wi-Fi, formation…', 'Filter: camera, Wi-Fi, training…');
  K('svc.expandAll', 'Tout déplier', 'Expand all');
  K('svc.collapseAll', 'Tout replier', 'Collapse all');
  K('svc.count', '{d} domaines, {s} services.', '{d} areas, {s} services.');
  K('svc.found', 'Résultat : {s} dans {d}.', 'Result: {s} in {d}.');
  K('svc.nServices.one', '{n} service', '{n} service');
  K('svc.nServices.many', '{n} services', '{n} services');
  K('svc.nDomains.one', '{n} domaine', '{n} area');
  K('svc.nDomains.many', '{n} domaines', '{n} areas');
  K('svc.inList.one', '{n} service dans votre liste.', '{n} service in your list.');
  K('svc.inList.many', '{n} services dans votre liste.', '{n} services in your list.');
  K('svc.noneTitle', 'Aucun service ne correspond à cette recherche', 'No service matches this search');
  K('svc.noneText', 'Ce n’est pas un problème : ajoutez votre besoin tel quel à votre demande, nous l’étudierons.', 'No problem: add your need as it is to your request and we will look into it.');
  K('svc.selectAll', 'Tout sélectionner', 'Select all');
  K('svc.unselectAll', 'Tout retirer', 'Remove all');
  K('search.addCustom', 'Ajouter « {q} » à ma liste', 'Add “{q}” to my list');
  K('search.addCustomHint', 'Votre besoin tel quel, même s’il n’est pas dans la liste', 'Your need as written, even if it is not in the list');
  K('basket.added', 'Ajouté à votre liste. Total : {n}.', 'Added to your list. Total: {n}.');
  K('basket.removed', 'Retiré de votre liste. Total : {n}.', 'Removed from your list. Total: {n}.');
  K('basket.see', 'Voir', 'View');
  K('basket.exists', 'Déjà dans votre liste.', 'Already in your list.');

  /* ----- secteurs ----- */
  K('sec.title', 'Des solutions pour chaque secteur d’activité', 'Solutions for every line of business');
  K('sec.lead', 'Choisissez votre secteur pour voir les besoins les plus courants. Touchez un besoin pour l’ajouter à votre demande de devis.', 'Pick your sector to see the most common needs. Tap a need to add it to your quote request.');
  K('sec.tabs', 'Secteurs d’activité', 'Business sectors');
  K('sec.needs', 'Besoins courants', 'Common needs');
  K('sec.domains', 'Domaines concernés', 'Relevant areas');
  K('sec.cta', 'Demander un devis pour ce secteur', 'Request a quote for this sector');

  /* ----- boutique et panier ----- */
  K('shop.title', 'Matériel informatique, du poste de travail à l’onduleur', 'IT hardware, from the workstation to the UPS');
  K('shop.lead', 'Ordinateurs, téléphones, réseau, caméras, énergie, impression, stockage et caisse. Ajoutez ce qui vous intéresse au panier : nous vous donnons le prix en discutant avec vous.', 'Computers, phones, networking, cameras, power, printing, storage and point of sale. Add what interests you to the cart: we give you the price when we talk with you.');
  K('shop.searchLabel', 'Rechercher un produit', 'Search products');
  K('shop.searchPh', 'Portable, routeur, onduleur…', 'Laptop, router, UPS…');
  K('shop.sort', 'Trier', 'Sort');
  K('shop.sortDefault', 'Ordre de la boutique', 'Shop order');
  K('shop.sortAsc', 'Prix croissant', 'Price, low to high');
  K('shop.sortDesc', 'Prix décroissant', 'Price, high to low');
  K('shop.cats', 'Catégories', 'Categories');
  K('shop.all', 'Tous', 'All');
  K('shop.count.one', '{n} produit', '{n} product');
  K('shop.count.many', '{n} produits', '{n} products');
  K('shop.ask', 'Prix sur demande', 'Price on request');
  K('shop.add', 'Ajouter', 'Add');
  K('shop.askAdd', 'Demander le prix', 'Ask for the price');
  K('shop.addAria', 'Ajouter {name} au panier', 'Add {name} to the cart');
  K('shop.qtyOf', 'Quantité : {name}', 'Quantity: {name}');
  K('shop.less', 'Moins', 'Less');
  K('shop.more', 'Plus', 'More');
  K('shop.cartOpen', 'Ouvrir le panier', 'Open the cart');
  K('shop.noneTitle', 'Aucun produit ne correspond', 'No product matches');
  K('shop.noneText', 'Essayez un autre mot, ou écrivez-nous sur WhatsApp : nous regarderons ce qui est possible.', 'Try another word, or message us on WhatsApp: we will look at what is possible.');
  K('shop.askWa', 'Demander sur WhatsApp', 'Ask on WhatsApp');
  K('cart.title', 'Mon panier', 'My cart');
  K('cart.emptyT', 'Votre panier est vide', 'Your cart is empty');
  K('cart.emptyP', 'Ajoutez du matériel depuis la boutique, puis revenez ici pour envoyer votre demande.', 'Add hardware from the shop, then come back here to send your request.');
  K('cart.toShop', 'Voir la boutique', 'Go to the shop');
  K('cart.subtotal', 'Total indicatif', 'Indicative total');
  K('cart.onDemand.one', '{n} article à prix sur demande n’est pas compté dans ce total.', '{n} item priced on request is not included in this total.');
  K('cart.onDemand.many', '{n} articles à prix sur demande ne sont pas comptés dans ce total.', '{n} items priced on request are not included in this total.');
  K('cart.each', 'l’unité', 'each');
  K('cart.remove', 'Retirer {name}', 'Remove {name}');
  K('cart.formTitle', 'Vos informations', 'Your details');
  K('cart.delivery', 'Réception', 'Receiving');
  K('cart.pickup', 'Je viens récupérer', 'I will pick it up');
  K('cart.ship', 'Livraison', 'Delivery');
  K('cart.commune', 'Commune ou ville', 'Commune or city');
  K('cart.chooseCommune', 'Choisir', 'Choose');
  K('cart.otherCity', 'Autre ville', 'Other city');
  K('cart.addr', 'Adresse de livraison', 'Delivery address');
  K('cart.shipHint', 'Les modalités de livraison sont confirmées avec l’équipe.', 'Delivery arrangements are confirmed with the team.');
  K('cart.pay', 'Paiement souhaité', 'Preferred payment');
  K('cart.payMomo', 'Mobile Money', 'Mobile Money');
  K('cart.payCash', 'Espèces', 'Cash');
  K('cart.payBank', 'Virement', 'Bank transfer');
  K('cart.payTalk', 'À discuter', 'To discuss');
  K('cart.payHint', 'Aucun paiement n’est demandé en ligne : le mode de paiement est confirmé avec l’équipe.', 'No payment is taken online: the payment method is confirmed with the team.');
  K('cart.note', 'Précisions (facultatif)', 'Details (optional)');
  K('cart.notePh', 'Couleur, marque préférée, horaire de passage…', 'Colour, preferred brand, pick-up time…');
  K('cart.notice', 'Nous vous donnons le prix et la disponibilité en discutant avec vous, avant tout paiement.', 'We give you the price and availability when we talk with you, before any payment.');
  K('cart.submitWa', 'Envoyer par WhatsApp', 'Send via WhatsApp');
  K('cart.submitDb', 'Envoyer ma demande', 'Send my request');
  K('cart.clear', 'Vider le panier', 'Empty the cart');
  K('cart.added', 'Ajouté au panier.', 'Added to the cart.');
  K('cart.view', 'Voir le panier', 'View cart');

  /* ----- méthode, avis, FAQ, contact, pied de page ----- */
  K('how.title', 'Comment ça se passe', 'How it works');
  K('why.title', 'Pourquoi travailler avec nous', 'Why work with us');
  K('proj.title', 'Quelques projets menés', 'A few projects');
  K('proj.visit', 'Voir le projet', 'View the project');
  K('rev.title', 'Ce que disent nos clients', 'What our clients say');
  K('rev.write', 'Laisser un avis', 'Leave a review');
  K('rev.anon', 'Un client', 'A client');
  K('rev.stars', '{n} étoiles sur 5', '{n} out of 5 stars');
  K('faq.title', 'Questions fréquentes', 'Frequently asked questions');
  K('faq.more', 'Une autre question ?', 'Another question?');
  K('faq.moreCta', 'Écrivez-nous sur WhatsApp', 'Message us on WhatsApp');
  K('contact.title', 'Parlons de votre projet', 'Let’s talk about your project');
  K('contact.lead', 'Le plus simple : un message WhatsApp. Vous pouvez aussi appeler, écrire un e-mail ou remplir le formulaire.', 'The easiest way: a WhatsApp message. You can also call, send an email or fill in the form.');
  K('contact.waSub', 'Écrire au {p}', 'Message {p}');
  K('contact.call', 'Appeler', 'Call');
  K('contact.mail', 'Écrire un e-mail', 'Send an email');
  K('contact.map', 'Voir sur la carte', 'View on the map');
  K('contact.hours', 'Horaires', 'Opening hours');
  K('contact.formTitle', 'Envoyer un message', 'Send a message');
  K('contact.how', 'Téléphone ou e-mail', 'Phone or email');
  K('contact.howPh', 'Pour vous répondre', 'So we can reply');
  K('contact.msg', 'Message', 'Message');
  K('contact.msgPh', 'Votre question ou votre besoin', 'Your question or need');
  K('contact.submitWa', 'Envoyer par WhatsApp', 'Send on WhatsApp');
  K('contact.submitDb', 'Envoyer le message', 'Send the message');
  K('ftr.text', 'Entreprise informatique à Kinshasa. Tous les domaines de l’informatique, du conseil à la maintenance.', 'IT company in Kinshasa. Every area of IT, from consulting to maintenance.');
  K('ftr.top', 'Haut de page', 'Back to top');
  K('wa.hello', 'Bonjour Dav Intertenement, j’ai une question.', 'Hello Dav Intertenement, I have a question.');
  K('wa.shop', 'Bonjour, je cherche un produit qui n’est pas dans la boutique : ', 'Hello, I am looking for a product that is not in the shop: ');

  window.__K1 = { fr: fr, en: en };
})();
/* ==========================================================================
   Dav Intertenement : textes des formulaires, messages, erreurs, compte
   (suite des textes, même principe que la première partie)
   ========================================================================== */
(function () {
  'use strict';
  var fr = {}, en = {};
  function K(k, a, b) { fr[k] = a; en[k] = b; }

  /* ----- champs communs ----- */
  K('f.required', 'obligatoire', 'required');
  K('f.name', 'Nom complet', 'Full name');
  K('f.namePh', 'Prénom et nom', 'First and last name');
  K('f.company', 'Organisation', 'Organization');
  K('f.companyPh', 'Nom de l’entreprise ou de l’organisation', 'Name of the company or organization');
  K('f.phone', 'Téléphone (WhatsApp de préférence)', 'Phone (WhatsApp preferred)');
  K('f.phoneShort', 'Téléphone', 'Phone');
  K('f.cc', 'Indicatif du pays', 'Country code');
  K('f.email', 'Adresse e-mail', 'Email address');
  K('f.emailPh', 'vous@exemple.com', 'you@example.com');
  K('f.city', 'Ville ou commune', 'City or district');
  K('f.cityPh', 'Ex. : Gombe, Limete, Lubumbashi…', 'E.g. Gombe, Limete, Lubumbashi…');
  K('f.pref', 'Comment préférez-vous être contacté ?', 'How would you like to be contacted?');
  K('f.prefWa', 'WhatsApp', 'WhatsApp');
  K('f.prefCall', 'Appel', 'Phone call');
  K('f.prefMail', 'E-mail', 'Email');

  /* ----- demande de devis ----- */
  K('quote.title', 'Décrivez votre besoin, nous revenons avec une proposition', 'Describe what you need and we’ll come back with a proposal');
  K('quote.lead', 'Quelques minutes suffisent. Plus votre description est précise, plus la proposition sera juste. Les champs marqués d’une étoile sont obligatoires.', 'It only takes a few minutes. The more precise your description, the more accurate our proposal. Fields marked with a star are required.');
  K('q.s1', 'Vous êtes', 'You are');
  K('q.ct.individual', 'Particulier', 'Individual');
  K('q.ct.company', 'Entreprise', 'Business');
  K('q.ct.school', 'École ou université', 'School or university');
  K('q.ct.ngo', 'ONG ou association', 'NGO or association');
  K('q.ct.gov', 'Administration', 'Government body');
  K('q.s2', 'Vos coordonnées', 'Your details');
  K('q.s3', 'Votre projet', 'Your project');
  K('q.s4', 'Précisions utiles', 'Helpful details');
  K('q.services', 'Services souhaités', 'Services you need');
  K('q.servicesPh', 'Chercher un service…', 'Search for a service…');
  K('q.servicesHint', 'Tapez pour chercher un service, ou parcourez la liste complète dans l’onglet Services. Rien n’est obligatoire ici si vous décrivez votre besoin ci-dessous.', 'Type to search for a service, or browse the full list in the Services tab. Nothing is required here if you describe your need below.');
  K('q.remove', 'Retirer {name}', 'Remove {name}');
  K('q.sector', 'Secteur d’activité', 'Business sector');
  K('q.sectorPick', 'Choisir un secteur', 'Choose a sector');
  K('q.sectorOther', 'Autre', 'Other');
  K('q.desc', 'Décrivez votre besoin', 'Describe your need');
  K('q.descPh', 'Ex. : nous ouvrons une boutique et voulons un site pour vendre en ligne, des caméras et un Wi-Fi pour le magasin.', 'E.g. we are opening a shop and want a website to sell online, cameras and Wi-Fi for the store.');
  K('q.budget', 'Budget estimé', 'Estimated budget');
  K('q.budgetHint', 'Une fourchette en dollars américains, seulement pour orienter la proposition. Elle n’engage à rien.', 'A range in US dollars, only to guide our proposal. It commits you to nothing.');
  K('q.bud.0', 'Moins de 500 $', 'Under $500');
  K('q.bud.1', '500 à 2 000 $', '$500 to $2,000');
  K('q.bud.2', '2 000 à 5 000 $', '$2,000 to $5,000');
  K('q.bud.3', '5 000 à 20 000 $', '$5,000 to $20,000');
  K('q.bud.4', '20 000 à 50 000 $', '$20,000 to $50,000');
  K('q.bud.5', 'Plus de 50 000 $', 'Over $50,000');
  K('q.bud.6', 'À discuter', 'To be discussed');
  K('q.urgency', 'Délai souhaité', 'Desired timeline');
  K('q.urg.flexible', 'Pas pressé', 'No rush');
  K('q.urg.month', 'Dans le mois', 'Within the month');
  K('q.urg.week', 'Cette semaine', 'This week');
  K('q.urg.urgent', 'Urgent', 'Urgent');
  K('q.date', 'Date de début souhaitée', 'Preferred start date');
  K('q.opt.maintenance', 'Maintenance après livraison', 'Maintenance after delivery');
  K('q.opt.maintenanceH', 'Dépannage et suivi dans la durée', 'Troubleshooting and long-term follow-up');
  K('q.opt.training', 'Formation de mon équipe', 'Training for my team');
  K('q.opt.trainingH', 'Prise en main des outils livrés', 'Getting started with the delivered tools');
  K('q.opt.onsite', 'Installation sur place', 'On-site installation');
  K('q.opt.onsiteH', 'Un technicien se déplace chez moi', 'A technician comes to my location');
  K('q.opt.takeover', 'J’ai déjà un système en place', 'I already have a system in place');
  K('q.opt.takeoverH', 'Site, réseau ou logiciel à reprendre ou améliorer', 'A website, network or software to take over or improve');
  K('q.files', 'Pièces jointes (facultatif)', 'Attachments (optional)');
  K('q.dropT', 'Glissez vos fichiers ici ou touchez pour choisir', 'Drop your files here or tap to choose');
  K('q.dropH', 'Photos, PDF, Word ou Excel. 5 fichiers au maximum, 5 Mo chacun.', 'Photos, PDF, Word or Excel. Up to 5 files, 5 MB each.');
  K('q.filesWa', 'Les fichiers ne partent pas avec ce formulaire : ajoutez-les ensuite dans la conversation WhatsApp.', 'Files are not sent with this form: add them afterwards in the WhatsApp conversation.');
  K('q.removeFile', 'Retirer le fichier {name}', 'Remove file {name}');
  K('q.notice', 'En envoyant ce formulaire, vous acceptez que vos informations servent uniquement à traiter votre demande et à vous répondre.', 'By sending this form you agree that your information is used only to handle your request and reply to you.');
  K('q.submitWa', 'Envoyer par WhatsApp', 'Send on WhatsApp');
  K('q.submitDb', 'Envoyer ma demande', 'Send my request');
  K('q.sendWa', 'Plutôt par WhatsApp', 'Send on WhatsApp instead');
  K('q.sendMail', 'Envoyer par e-mail', 'Send by email');

  /* ----- rendez-vous en ligne ----- */
  K('rdv.title', 'Prenez rendez-vous en ligne', 'Book an appointment online');
  K('rdv.lead', 'Choisissez le type de rendez-vous, une date et un créneau libre, puis laissez vos coordonnées. Nous confirmons ensuite avec vous.', 'Choose the type of appointment, a date and a free slot, then leave your details. We then confirm with you.');
  K('rdv.s1', 'Type de rendez-vous', 'Appointment type');
  K('rdv.t.onsite', 'Visite sur place', 'On-site visit');
  K('rdv.d.onsite', 'Un technicien vient chez vous ou dans vos locaux', 'A technician comes to your home or premises');
  K('rdv.t.phone', 'Appel téléphonique', 'Phone call');
  K('rdv.d.phone', 'Nous vous appelons à l’heure choisie', 'We call you at the chosen time');
  K('rdv.t.video', 'Appel vidéo', 'Video call');
  K('rdv.d.video', 'Un échange à distance, face à face', 'A face-to-face talk, remotely');
  K('rdv.t.office', 'Rendez-vous au bureau', 'Visit our office');
  K('rdv.d.office', 'Venez nous voir à notre adresse', 'Come and see us at our address');
  K('rdv.s2', 'Date et heure', 'Date and time');
  K('rdv.days', 'Jours disponibles', 'Available days');
  K('rdv.slots', 'Créneaux du jour choisi', 'Time slots for the chosen day');
  K('rdv.noDays', 'Aucun créneau n’est ouvert pour le moment. Écrivez-nous sur WhatsApp.', 'No slot is open at the moment. Message us on WhatsApp.');
  K('rdv.unavailable', 'Créneau indisponible', 'Slot unavailable');
  K('rdv.tz', 'Heures de Kinshasa (UTC+1).', 'Kinshasa time (UTC+1).');
  K('rdv.tzWa', 'Plusieurs personnes peuvent demander le même créneau : nous confirmons avec vous.', 'Several people may request the same slot: we confirm with you.');
  K('rdv.summary', '{date} à {time}, {type} (heure de Kinshasa)', '{date} at {time}, {type} (Kinshasa time)');
  K('rdv.when', '{date} à {time}', '{date} at {time}');
  K('rdv.s3', 'Vos coordonnées', 'Your details');
  K('rdv.topic', 'Sujet du rendez-vous', 'Appointment topic');
  K('rdv.topicOther', 'Autre ou je ne sais pas encore', 'Other, or not sure yet');
  K('rdv.addr', 'Adresse de la visite', 'Visit address');
  K('rdv.addrPh', 'Avenue, numéro, commune, repère connu', 'Avenue, number, district, known landmark');
  K('rdv.note', 'Précisions (facultatif)', 'Details (optional)');
  K('rdv.notePh', 'Ce que vous voulez voir ou régler pendant le rendez-vous', 'What you would like to see or sort out during the appointment');
  K('rdv.notice', 'Le créneau choisi est une demande : il est confirmé avec vous par message ou par appel.', 'The chosen slot is a request: it is confirmed with you by message or call.');
  K('rdv.submitWa', 'Demander ce rendez-vous sur WhatsApp', 'Request this appointment on WhatsApp');
  K('rdv.submitDb', 'Demander ce rendez-vous', 'Request this appointment');

  /* ----- confirmations après envoi ----- */
  K('done.again', 'Nouvelle demande', 'New request');
  K('done.waTitle', 'Votre message est prêt dans WhatsApp', 'Your message is ready in WhatsApp');
  K('done.waText', 'Envoyez le message dans WhatsApp pour terminer. Si WhatsApp ne s’est pas ouvert, touchez le bouton ci-dessous.', 'Send the message in WhatsApp to finish. If WhatsApp did not open, tap the button below.');
  K('done.waOpen', 'Ouvrir WhatsApp', 'Open WhatsApp');
  K('done.wa', 'Suivre sur WhatsApp', 'Follow up on WhatsApp');
  K('done.mailTitle', 'Votre e-mail est prêt', 'Your email is ready');
  K('done.mailText', 'Envoyez le message depuis votre application e-mail. Vous pouvez aussi écrire directement à {email}.', 'Send the message from your email app. You can also write directly to {email}.');
  K('done.quoteTitle', 'Demande de devis envoyée', 'Quote request sent');
  K('done.quoteText', 'Merci. Gardez votre référence : elle permet de suivre votre demande. Nous revenons vers vous avec une proposition.', 'Thank you. Keep your reference number: it lets you follow up on your request. We will come back to you with a proposal.');
  K('done.rdvTitle', 'Demande de rendez-vous envoyée', 'Appointment request sent');
  K('done.rdvText', '{date} à {time}. Nous confirmons le créneau avec vous par message ou par appel.', '{date} at {time}. We confirm the slot with you by message or call.');
  K('done.contactTitle', 'Message envoyé', 'Message sent');
  K('done.contactText', 'Merci pour votre message. Nous vous répondons dès que possible.', 'Thank you for your message. We will reply as soon as we can.');
  K('done.orderTitle', 'Demande envoyée', 'Request sent');
  K('done.orderText', 'Merci. Nous vous contactons pour confirmer la disponibilité, vous donner le prix et convenir du retrait ou de la livraison.', 'Thank you. We will contact you to confirm availability, give you the price and arrange pickup or delivery.');
  K('done.orderWaTitle', 'Votre demande est prête dans WhatsApp', 'Your request is ready in WhatsApp');
  K('done.orderWaText', 'Envoyez le message dans WhatsApp pour recevoir les prix. Si WhatsApp ne s’est pas ouvert, touchez le bouton ci-dessous.', 'Send the message in WhatsApp to get the prices. If WhatsApp did not open, tap the button below.');

  /* ----- messages préparés (WhatsApp, e-mail) ----- */
  K('msg.quote.title', 'Demande de devis (réf. {ref})', 'Quote request (ref. {ref})');
  K('msg.contact.title', 'Message depuis le site (réf. {ref})', 'Message from the website (ref. {ref})');
  K('msg.appt.title', 'Demande de rendez-vous (réf. {ref})', 'Appointment request (ref. {ref})');
  K('msg.order.title', 'Demande boutique (réf. {ref})', 'Shop request (ref. {ref})');
  K('msg.order.intro', 'Bonjour, je suis intéressé par ces articles :', 'Hello, I am interested in these items:');
  K('msg.order.total', 'Total : {t}', 'Total: {t}');
  K('msg.order.askPrice', 'Pouvez-vous m’indiquer les prix et la disponibilité ?', 'Could you tell me the prices and availability?');
  K('msg.order.more.one', '+ {n} article sur demande', '+ {n} item on request');
  K('msg.order.more.many', '+ {n} articles sur demande', '+ {n} items on request');
  K('msg.followup', 'Bonjour, je viens d’envoyer une demande depuis votre site (réf. {ref}).', 'Hello, I have just sent a request from your website (ref. {ref}).');
  K('msg.profile', 'Profil', 'Profile');
  K('msg.name', 'Nom', 'Name');
  K('msg.phone', 'Téléphone', 'Phone');
  K('msg.email', 'E-mail', 'Email');
  K('msg.pref', 'Contact préféré', 'Preferred contact');
  K('msg.city', 'Ville', 'City');
  K('msg.services', 'Services', 'Services');
  K('msg.sector', 'Secteur', 'Sector');
  K('msg.need', 'Besoin', 'Need');
  K('msg.budget', 'Budget', 'Budget');
  K('msg.urgency', 'Délai', 'Timeline');
  K('msg.start', 'Début souhaité', 'Preferred start');
  K('msg.options', 'Options', 'Options');
  K('msg.files', 'Pièces jointes', 'Attachments');
  K('msg.reach', 'Contact', 'Contact');
  K('msg.message', 'Message', 'Message');
  K('msg.type', 'Type', 'Type');
  K('msg.when', 'Date et heure', 'Date and time');
  K('msg.topic', 'Sujet', 'Topic');
  K('msg.address', 'Adresse', 'Address');
  K('msg.note', 'Remarque', 'Note');
  K('msg.reception', 'Retrait ou livraison', 'Pickup or delivery');
  K('msg.payment', 'Paiement', 'Payment');

  /* ----- messages d’erreur ----- */
  K('err.name', 'Indiquez votre nom.', 'Please enter your name.');
  K('err.phone', 'Numéro invalide. Vérifiez l’indicatif et les chiffres.', 'Invalid number. Check the country code and the digits.');
  K('err.email', 'Adresse e-mail invalide.', 'Invalid email address.');
  K('err.address', 'Indiquez l’adresse.', 'Please enter the address.');
  K('err.needSomething', 'Choisissez au moins un service ou décrivez votre besoin.', 'Choose at least one service or describe your need.');
  K('err.message', 'Écrivez un message d’au moins 5 caractères.', 'Write a message of at least 5 characters.');
  K('err.contact', 'Indiquez un numéro ou une adresse e-mail.', 'Enter a phone number or an email address.');
  K('err.contactBad', 'Ce numéro ou cette adresse e-mail n’est pas valide.', 'This number or email address is not valid.');
  K('err.cartEmpty', 'Votre panier est vide.', 'Your cart is empty.');
  K('err.pickSlot', 'Choisissez un jour et une heure.', 'Choose a day and a time.');
  K('err.slotTaken', 'Ce créneau vient d’être pris. Choisissez-en un autre.', 'This slot has just been taken. Please choose another one.');
  K('err.send', 'L’envoi a échoué. Vérifiez votre connexion et réessayez, ou écrivez-nous sur WhatsApp.', 'Sending failed. Check your connection and try again, or message us on WhatsApp.');
  K('err.sendFiles', 'Les pièces jointes n’ont pas pu être envoyées. Réessayez, ou retirez-les.', 'The attachments could not be uploaded. Try again, or remove them.');
  K('err.wait', 'Un instant avant un nouvel envoi.', 'Please wait a moment before sending again.');
  K('err.tooMany', '5 fichiers au maximum.', 'Up to 5 files.');
  K('err.tooBig', '« {name} » dépasse 5 Mo.', '“{name}” is larger than 5 MB.');
  K('err.type', '« {name} » : format non accepté. Utilisez une photo, un PDF, un fichier Word ou Excel.', '“{name}”: file type not accepted. Use a photo, a PDF, or a Word or Excel file.');
  K('err.login', 'Adresse e-mail ou mot de passe incorrect.', 'Incorrect email or password.');
  K('err.confirm', 'Confirmez d’abord votre adresse e-mail avec le message que nous vous avons envoyé.', 'Please confirm your email address first, using the message we sent you.');
  K('err.exists', 'Un compte existe déjà avec cette adresse e-mail. Connectez-vous.', 'An account already exists with this email address. Please sign in.');
  K('err.pass', 'Le mot de passe doit contenir au moins 8 caractères.', 'The password must be at least 8 characters.');
  K('err.passEmpty', 'Entrez votre mot de passe.', 'Enter your password.');
  K('err.rate', 'Trop de tentatives. Patientez quelques instants puis réessayez.', 'Too many attempts. Wait a few moments, then try again.');
  K('err.rating', 'Choisissez une note de 1 à 5 étoiles.', 'Choose a rating from 1 to 5 stars.');
  K('err.review', 'Écrivez un avis d’au moins 10 caractères.', 'Write a review of at least 10 characters.');
  K('err.load', 'Impossible de charger vos informations. Réessayez plus tard.', 'Could not load your information. Please try again later.');

  /* ----- espace client ----- */
  K('acct.title', 'Mon compte', 'My account');
  K('acct.open', 'Mon compte', 'My account');
  K('acct.mine', 'Mon espace client', 'My customer area');
  K('acct.demo', 'Aperçu : l’espace client fonctionne dès que la base de données Supabase est connectée (voir LISEZMOI).', 'Preview: the customer area works as soon as the Supabase database is connected (see the README).');
  K('acct.demoMsg', 'Aperçu : connectez la base de données pour activer les comptes.', 'Preview: connect the database to enable accounts.');
  K('acct.login', 'Connexion', 'Sign in');
  K('acct.register', 'Créer un compte', 'Create account');
  K('acct.pass', 'Mot de passe', 'Password');
  K('acct.passHint', '8 caractères au minimum.', 'At least 8 characters.');
  K('acct.showPass', 'Afficher le mot de passe', 'Show password');
  K('acct.hidePass', 'Masquer le mot de passe', 'Hide password');
  K('acct.loginBtn', 'Se connecter', 'Sign in');
  K('acct.registerBtn', 'Créer mon compte', 'Create my account');
  K('acct.forgot', 'Mot de passe oublié', 'Forgot password');
  K('acct.back', 'Retour', 'Back');
  K('acct.resetHint', 'Entrez votre adresse e-mail : nous vous envoyons un lien pour choisir un nouveau mot de passe.', 'Enter your email address: we will send you a link to choose a new password.');
  K('acct.resetBtn', 'Envoyer le lien', 'Send the link');
  K('acct.resetSent', 'Si un compte existe avec cette adresse, un lien vient d’être envoyé. Pensez à regarder dans les courriers indésirables.', 'If an account exists with this address, a link has just been sent. Remember to check your spam folder.');
  K('acct.newPass', 'Nouveau mot de passe', 'New password');
  K('acct.newPassHint', 'Choisissez un nouveau mot de passe pour votre compte.', 'Choose a new password for your account.');
  K('acct.saveBtn', 'Enregistrer', 'Save');
  K('acct.passSaved', 'Mot de passe enregistré.', 'Password saved.');
  K('acct.checkMail', 'Compte créé. Ouvrez le message que nous vous avons envoyé pour confirmer votre adresse e-mail, puis connectez-vous.', 'Account created. Open the message we sent you to confirm your email address, then sign in.');
  K('acct.welcome', 'Bienvenue.', 'Welcome.');
  K('acct.bye', 'Vous êtes déconnecté.', 'You are signed out.');
  K('acct.logout', 'Se déconnecter', 'Sign out');
  K('acct.quotes', 'Mes demandes de devis', 'My quote requests');
  K('acct.appts', 'Mes rendez-vous', 'My appointments');
  K('acct.orders', 'Mes commandes', 'My orders');
  K('acct.loading', 'Chargement…', 'Loading…');
  K('acct.noQuotes', 'Aucune demande de devis pour le moment.', 'No quote requests yet.');
  K('acct.noAppts', 'Aucun rendez-vous pour le moment.', 'No appointments yet.');
  K('acct.noOrders', 'Aucune commande pour le moment.', 'No orders yet.');
  K('acct.cancel', 'Annuler', 'Cancel');
  K('acct.cancelled', 'Rendez-vous annulé.', 'Appointment cancelled.');
  K('acct.nItems.one', '{n} article', '{n} item');
  K('acct.nItems.many', '{n} articles', '{n} items');
  K('acct.review', 'Laisser un avis', 'Leave a review');
  K('acct.rating', 'Note', 'Rating');
  K('acct.stars1', '1 sur 5', '1 out of 5');
  K('acct.stars2', '2 sur 5', '2 out of 5');
  K('acct.stars3', '3 sur 5', '3 out of 5');
  K('acct.stars4', '4 sur 5', '4 out of 5');
  K('acct.stars5', '5 sur 5', '5 out of 5');
  K('acct.reviewText', 'Votre avis', 'Your review');
  K('acct.reviewHint', 'Votre avis est publié après vérification par l’équipe.', 'Your review is published after it has been checked by the team.');
  K('acct.reviewBtn', 'Envoyer mon avis', 'Send my review');
  K('acct.reviewSent', 'Merci. Votre avis sera publié après vérification.', 'Thank you. Your review will be published after it has been checked.');

  /* ----- statuts affichés dans l’espace client ----- */
  K('st.new', 'Nouveau', 'New');
  K('st.pending', 'En attente', 'Pending');
  K('st.processing', 'En cours', 'In progress');
  K('st.confirmed', 'Confirmé', 'Confirmed');
  K('st.done', 'Terminé', 'Done');
  K('st.ready', 'Prêt', 'Ready');
  K('st.shipped', 'Expédié', 'Shipped');
  K('st.delivered', 'Livré', 'Delivered');
  K('st.paid', 'Payé', 'Paid');
  K('st.cancelled', 'Annulé', 'Cancelled');

  /* ----- fond animé ----- */
  K('bg.pause', 'Mettre l’animation en pause', 'Pause the animation');
  K('bg.play', 'Relancer l’animation', 'Resume the animation');

  window.__K2 = { fr: fr, en: en };
})();
/* ==========================================================================
   Dav Intertenement : textes du site (3/3), onglets, accueil « Qui sommes-nous » et « Notre secteur »
   Même principe : la 2e ligne est le français, la 3e l’anglais.
   ========================================================================== */
(function () {
  'use strict';
  var fr = {}, en = {};
  function K(k, a, b) { fr[k] = a; en[k] = b; }

  /* ----- onglets ----- */
  K('nav.home', 'Accueil', 'Home');
  K('q.browse', 'Parcourir tous les services', 'Browse all services');

  /* ----- accueil : qui sommes-nous ----- */
  K('about.eyebrow', 'Qui sommes-nous', 'Who we are');
  K('about.title', 'Dav Intertenement, votre partenaire informatique à Kinshasa', 'Dav Intertenement, your IT partner in Kinshasa');
  K('about.p1', 'Dav Intertenement est une entreprise informatique basée à Kinshasa. Nous accompagnons les particuliers, les entreprises, les écoles, les ONG et les administrations dans tous les domaines de l’informatique : du site web à la vidéosurveillance, du Wi-Fi à l’énergie de secours, de la formation à la maintenance.',
    'Dav Intertenement is an IT company based in Kinshasa. We support individuals, businesses, schools, NGOs and public bodies in every area of IT: from websites to video surveillance, from Wi-Fi to backup power, from training to maintenance.');
  K('about.p2', 'Notre idée est simple : un seul interlocuteur pour tout ce qui touche à l’informatique, du premier conseil au suivi après la livraison, avec des solutions pensées pour la réalité du terrain.',
    'Our idea is simple: one point of contact for everything IT, from the first piece of advice to follow-up after delivery, with solutions designed for real-life conditions.');
  K('about.ctaContact', 'Nous contacter', 'Contact us');
  K('about.forTitle', 'Nous accompagnons', 'We work with');
  K('about.for1', 'Particuliers', 'Individuals');
  K('about.for2', 'Entreprises et PME', 'Businesses and SMEs');
  K('about.for3', 'Écoles et universités', 'Schools and universities');
  K('about.for4', 'ONG et associations', 'NGOs and associations');
  K('about.for5', 'Administrations et collectivités', 'Public bodies and local authorities');

  /* ----- accueil : notre secteur ----- */
  K('field.eyebrow', 'Notre secteur', 'Our field');
  K('field.title', 'L’informatique, bien plus que des ordinateurs', 'IT is much more than computers');
  K('field.lead', 'Aujourd’hui, presque toute activité repose sur des outils numériques. Nous intervenons sur les six grands piliers du secteur, pour qu’ils fonctionnent bien ensemble.',
    'Almost every activity now relies on digital tools. We work across the six main pillars of the field, so that they work well together.');
  K('pillar.meta', '{d} domaines · {s} services', '{d} areas · {s} services');

  /* ----- accueil : explorer ----- */
  K('explore.title', 'Explorez le site à votre rythme', 'Explore the site at your own pace');
  K('explore.lead', 'Chaque rubrique s’ouvre dans son propre onglet : touchez celle qui vous intéresse.', 'Each section opens in its own tab: tap the one you are interested in.');
  K('go.services', 'Tous les domaines et leurs services, à ajouter à votre demande', 'Every area and its services, ready to add to your request');
  K('go.sectors', 'Les besoins courants de votre secteur d’activité', 'The common needs of your line of business');
  K('go.shop', 'Ordinateurs, réseau, caméras, énergie : demandez le prix', 'Computers, networking, cameras, power: ask for the price');
  K('go.quote', 'Décrivez votre projet, nous revenons avec une proposition', 'Describe your project and we come back with a proposal');
  K('go.appointment', 'Choisissez une date et un créneau libre', 'Pick a date and a free time slot');
  K('go.faq', 'Les réponses aux questions les plus fréquentes', 'Answers to the most common questions');
  K('go.contact', 'WhatsApp, appel, e-mail ou message', 'WhatsApp, phone, e-mail or message');

  window.__K3 = { fr: fr, en: en };
})();
/* Fusion des trois parties : window.DAV_I18N = { fr: {...}, en: {...} } */
(function () {
  'use strict';
  var parts = [window.__K1, window.__K2, window.__K3], out = { fr: {}, en: {} };
  ['fr', 'en'].forEach(function (l) {
    parts.forEach(function (p) {
      var k;
      if (p && p[l]) for (k in p[l]) out[l][k] = p[l][k];
    });
  });
  window.DAV_I18N = out;
  window.__K1 = window.__K2 = window.__K3 = undefined;
})();
