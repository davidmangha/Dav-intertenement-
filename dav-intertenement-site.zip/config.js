/* ==========================================================================
   DAV INTERTENEMENT : réglages du site
   Tout ce que tu peux changer sans toucher au reste du code est ici.
   - Les textes français utilisent l’apostrophe typographique ’ (pas ').
   - Après modification, enregistre le fichier et renvoie le ZIP sur Netlify
     ou Cloudflare Pages.
   ========================================================================== */
window.DAV_CONFIG = {

  brand: {
    name: "Dav Intertenement",
    city: "Kinshasa",
    country: { fr: "RDC", en: "DR Congo" },
    /* Ton logo = deux fichiers du dossier img. Pour le changer, remplace ces fichiers (garde les mêmes noms)
       ou écris ici le nom d’un autre fichier. Si un fichier manque, le site affiche un petit logo de secours. */
    logo: "img/logo-mark.webp",       /* petit logo : en-tête et pied de page (fond transparent) */
    emblem: "img/logo-emblem.webp"    /* grand logo : plaque « Qui sommes-nous » de l’accueil (fond transparent) */
  },

  /* Contacts affichés sur tout le site */
  contact: {
    /* Numéro utilisé par les boutons WhatsApp : chiffres seulement, indicatif inclus, sans + */
    whatsapp: "242069577009",
    phones: [
      { display: "+242 06 957 7009", tel: "+242069577009", wa: "242069577009" },
      { display: "+243 84 834 6872", tel: "+243848346872", wa: "243848346872" }
    ],
    email: "Davintertenement4@gmail.com",
    /* Adresse physique : laisse vide tant que tu n’en veux pas (la ligne et l’option « au bureau » restent cachées) */
    address: { fr: "", en: "" },
    /* Horaires d’ouverture affichés (texte libre), vide = caché. Ex. { fr: "Lundi au samedi, 8 h à 17 h", en: "Monday to Saturday, 8 am to 5 pm" } */
    hours: { fr: "", en: "" }
  },

  /* Réseaux sociaux : colle l’adresse complète (https://...). Vide = icône cachée.
     Ceux de ton logo sont déjà là : vérifie-les en cliquant dessus (LinkedIn surtout : page entreprise ou profil ?). */
  social: {
    facebook: "https://www.facebook.com/dav.intertenement",
    instagram: "https://www.instagram.com/dav_intertenement",
    linkedin: "https://www.linkedin.com/company/dav-intertenement",
    tiktok: "", youtube: "", x: ""
  },

  /* Base de données Supabase (voir LISEZMOI.txt). Vide = le site fonctionne en mode WhatsApp uniquement. */
  supabase: { url: "", anonKey: "" },

  /* Fond animé : mets false pour couper un effet (utile si tes clients ont des téléphones très lents) */
  effects: {
    network: true,   /* réseau animé qui relie les icônes de tous les domaines (accueil) */
    glow: true,      /* halos de couleur qui bougent doucement (accueil) */
    cards: true,     /* illustrations de l’accueil qui changent toutes seules */
    ambient: true    /* lueurs douces qui bougent derrière toute la page */
  },

  /* Boutique */
  shop: {
    /* Taux du dollar en francs congolais pour afficher un montant approximatif en FC. 0 = caché. Ex. 2800 */
    cdfRate: 0,
    deliveryNote: { fr: "", en: "" }
  },

  /* Prise de rendez-vous */
  appointment: {
    daysAhead: 14,              /* nombre de jours proposés */
    closedWeekdays: [0],        /* 0 = dimanche, 1 = lundi ... 6 = samedi */
    start: "08:00",             /* premier créneau */
    end: "17:00",               /* fin du dernier créneau */
    slotMinutes: 60,            /* durée d’un créneau */
    types: ["onsite", "phone", "video"]   /* onsite = visite chez vous, phone = appel, video = appel vidéo, office = au bureau (exige une adresse ci-dessus) */
  },

  /* Images. Le site est livré avec des images réalistes (rendus 3D d’appareils) dans le dossier img/ :
     p-<produit>.webp pour la boutique et s-<domaine>.webp pour les domaines. bundled: false = on revient aux petits dessins vectoriels.
     Tes propres photos : mets le fichier dans le même dossier que index.html et écris son nom ci-dessous.
     Si une image est renseignée, elle remplace l’image livrée avec le site. */
  images: {
    bundled: true,
    hero: "",
    /* Diaporama de tes photos en fond de l’accueil, ex. ["photo1.jpg", "photo2.jpg"]. Vide = pas de diaporama. */
    heroSlides: [],
    domains: { /* web: "photo-web.jpg", network: "photo-reseau.jpg" */ },
    products: { /* "p-laptop-156": "portable.jpg" */ },
    projects: {}
  },

  /* Réalisations : ajoute uniquement des projets réels. La section reste cachée tant que la liste est vide.
     Modèle : { title: { fr: "…", en: "…" }, domain: "web", text: { fr: "…", en: "…" }, image: "", link: "", year: "2026" } */
  projects: [],

  /* Témoignages : ajoute uniquement de vrais retours clients. Caché tant que la liste est vide.
     Modèle : { name: "Prénom Nom", role: "Fonction, entreprise", text: { fr: "…", en: "…" } } */
  testimonials: [],

  /* Adresse publique du site (utilisée par Google pour te présenter). Quand tu branches ton propre nom de domaine,
     remplace-la ici, et remplace aussi « davintertenementrdc.netlify.app » dans les 2 lignes og:image / twitter:image de index.html. */
  siteUrl: "https://davintertenementrdc.netlify.app"
};
